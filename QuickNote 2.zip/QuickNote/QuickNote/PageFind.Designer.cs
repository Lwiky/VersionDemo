namespace GLTc.QuickNote
{
    partial class PageFind
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbTips = new System.Windows.Forms.Label();
            this.tbFindText = new System.Windows.Forms.TextBox();
            this.btnFind = new System.Windows.Forms.Button();
            this.cbMatchCase = new System.Windows.Forms.CheckBox();
            this.gbDirection = new System.Windows.Forms.GroupBox();
            this.tbDown = new System.Windows.Forms.RadioButton();
            this.rbUp = new System.Windows.Forms.RadioButton();
            this.btnCancel = new System.Windows.Forms.Button();
            this.gbDirection.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbTips
            // 
            this.lbTips.AutoSize = true;
            this.lbTips.Location = new System.Drawing.Point(1, 9);
            this.lbTips.Name = "lbTips";
            this.lbTips.Size = new System.Drawing.Size(59, 13);
            this.lbTips.TabIndex = 2;
            this.lbTips.Text = "Find What:";
            // 
            // tbFindText
            // 
            this.tbFindText.Location = new System.Drawing.Point(66, 6);
            this.tbFindText.Name = "tbFindText";
            this.tbFindText.Size = new System.Drawing.Size(197, 20);
            this.tbFindText.TabIndex = 0;
            this.tbFindText.TextChanged += new System.EventHandler(this.tbFindText_TextChanged);
            this.tbFindText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbFindText_KeyDown);
            // 
            // btnFind
            // 
            this.btnFind.Enabled = false;
            this.btnFind.Location = new System.Drawing.Point(269, 4);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(75, 23);
            this.btnFind.TabIndex = 1;
            this.btnFind.Text = "&Find Next";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // cbMatchCase
            // 
            this.cbMatchCase.AutoSize = true;
            this.cbMatchCase.Location = new System.Drawing.Point(4, 68);
            this.cbMatchCase.Name = "cbMatchCase";
            this.cbMatchCase.Size = new System.Drawing.Size(82, 17);
            this.cbMatchCase.TabIndex = 3;
            this.cbMatchCase.Text = "Match &case";
            this.cbMatchCase.UseVisualStyleBackColor = true;
            // 
            // gbDirection
            // 
            this.gbDirection.Controls.Add(this.tbDown);
            this.gbDirection.Controls.Add(this.rbUp);
            this.gbDirection.Location = new System.Drawing.Point(145, 34);
            this.gbDirection.Name = "gbDirection";
            this.gbDirection.Size = new System.Drawing.Size(118, 51);
            this.gbDirection.TabIndex = 4;
            this.gbDirection.TabStop = false;
            this.gbDirection.Text = "Direction";
            // 
            // tbDown
            // 
            this.tbDown.AutoSize = true;
            this.tbDown.Checked = true;
            this.tbDown.Location = new System.Drawing.Point(51, 28);
            this.tbDown.Name = "tbDown";
            this.tbDown.Size = new System.Drawing.Size(53, 17);
            this.tbDown.TabIndex = 1;
            this.tbDown.TabStop = true;
            this.tbDown.Text = "Down";
            this.tbDown.UseVisualStyleBackColor = true;
            // 
            // rbUp
            // 
            this.rbUp.AutoSize = true;
            this.rbUp.Location = new System.Drawing.Point(6, 28);
            this.rbUp.Name = "rbUp";
            this.rbUp.Size = new System.Drawing.Size(39, 17);
            this.rbUp.TabIndex = 0;
            this.rbUp.Text = "Up";
            this.rbUp.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.AutoSize = true;
            this.btnCancel.Location = new System.Drawing.Point(269, 33);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // PageFind
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(355, 97);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.gbDirection);
            this.Controls.Add(this.cbMatchCase);
            this.Controls.Add(this.btnFind);
            this.Controls.Add(this.tbFindText);
            this.Controls.Add(this.lbTips);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PageFind";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Find";
            this.TopMost = true;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.PageFind_FormClosed);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PageFind_FormClosing);
            this.gbDirection.ResumeLayout(false);
            this.gbDirection.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbTips;
        private System.Windows.Forms.TextBox tbFindText;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.CheckBox cbMatchCase;
        private System.Windows.Forms.GroupBox gbDirection;
        private System.Windows.Forms.RadioButton tbDown;
        private System.Windows.Forms.RadioButton rbUp;
        private System.Windows.Forms.Button btnCancel;
    }
}