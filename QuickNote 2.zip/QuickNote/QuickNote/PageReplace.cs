using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GLTc.QuickNote.Command;
namespace GLTc.QuickNote
{
    public partial class PageReplace : Form
    {

        private int FindPosition;

        #region StartFindPosition
        /// <summary>
        /// the start position of the order select
        /// </summary>
        private int startFindPosition;
        public int StartFindPosition
        {
            get
            {
                if (this.SelectedRichtextBox.SelectedText != string.Empty)
                {
                    startFindPosition = this.SelectedRichtextBox.SelectionStart + 1;

                }
                else
                {
                    startFindPosition = this.SelectedRichtextBox.SelectionStart;
                }

                return startFindPosition;
            }

        }
        #endregion

        #region StartReverseFindPosition
        /// <summary>
        /// the start position of the disorder select
        /// </summary>
        private int startReverseFindPosition;
        public int StartReverseFindPosition
        {
            get
            {
                if (this.SelectedRichtextBox.SelectedText != string.Empty)
                {
                    startReverseFindPosition = this.SelectedRichtextBox.SelectionStart - 1;

                }
                else
                {
                    startReverseFindPosition = this.SelectedRichtextBox.SelectionStart;
                }

                return startReverseFindPosition;
            }

        }
        #endregion

        #region CurrentContextOperator
        private ContextOperator currentContextOperator;

        public ContextOperator CurrentContextOperator
        {
            get { return currentContextOperator; }
            set { currentContextOperator = value; }
        }
        #endregion

        #region SelectedRichtextBox
        private RichTextBox SelectedRichtextBox
        {
            get
            {
                return this.CurrentContextOperator.SelectedRichTextBox;
            }
        }
        #endregion 

        #region PageReplace
        /// <summary>
        /// singalton PageReplace window
        /// </summary>
        private static PageReplace SingaltonPageReplace;
        #endregion 

        #region Private Constructor 
        /// <summary>
        /// private Constructor
        /// </summary>
        /// <param name="COP"></param>
        private PageReplace(ContextOperator COP)
        {
            this.CurrentContextOperator = COP;
            InitializeComponent();
        }
        #endregion 

        #region Override CreateParams
        /// <summary>
        /// hide the form from alt-tab
        /// </summary>
        protected override CreateParams CreateParams
        {
            get
            {
                // Turn on WS_EX_TOOLWINDOW style bit
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x80;
                return cp;
            }
        }
        #endregion

        #region CreatePageReplace
        /// <summary>
        /// Singalton PageReplace   
        /// </summary>
        /// <returns></returns>
        public static PageReplace CreatePageReplace(ContextOperator COP)
        {
            if (SingaltonPageReplace == null)
            {
                SingaltonPageReplace = new PageReplace(COP);
            }

            return SingaltonPageReplace;
        }
        #endregion 

        #region FindNextString
        /// <summary>
        /// find the next target string
        /// </summary>
        private int FindNextString()
        {
            string findStr = this.tbFind.Text.Trim();
            RichTextBoxFinds matchCase = this.chbMatchCase.Checked ? RichTextBoxFinds.MatchCase : RichTextBoxFinds.None;

            // select in order
            int selectStart = StartFindPosition;
            FindPosition = this.SelectedRichtextBox.Find(findStr, selectStart, matchCase);

            if (FindPosition != -1)
            {
                this.SelectedRichtextBox.Select(FindPosition, this.tbFind.Text.Trim().Length);
                //make the the find string in richtextbox selected
                SelectedRichtextBox.ScrollToCaret();
            }

            return FindPosition;
        }
        #endregion 

        #region btnFindNext_Click
        private void btnFindNext_Click(object sender, EventArgs e)
        {
           int findpostion =  FindNextString();
           if (findpostion == -1)
             {

                 MessageBox.Show(string.Format("Can not find '{0}'!", this.tbFind.Text.Trim()));
            }

        }
        #endregion 

        #region btnReplace_Click
        /// <summary>
        /// Replace function 
        /// if selectText = findstring ,then replace
        /// otherwise findNext
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReplace_Click(object sender, EventArgs e)
        {
            string findStr = this.tbFind.Text;
            string replaceStr = this.tbReplace.Text;
            string selectText = this.SelectedRichtextBox.SelectedText;
            bool isReplace = this.chbMatchCase.Checked ? selectText == findStr :selectText.ToLower()== findStr.ToLower();
            if (!isReplace)
            {
                int findpostion = FindNextString();
                if (findpostion == -1)
                {

                    MessageBox.Show(string.Format("Can not find '{0}'!", findStr));
                }

            }
            else
            {
                int selectStart = this.SelectedRichtextBox.SelectionStart;
                this.SelectedRichtextBox.SelectedText = replaceStr;
                this.SelectedRichtextBox.Select(selectStart, replaceStr.Length);
            }

        }
        #endregion

        #region btnReplaceAll_Click
        /// <summary>
        /// Replace all string
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReplaceAll_Click(object sender, EventArgs e)
        {
            int iscanfind = 0;
            this.SelectedRichtextBox.SelectionStart = 0;
            while (iscanfind != -1)
            {
                iscanfind = FindNextString();
                if (iscanfind != -1)
                this.SelectedRichtextBox.SelectedText = this.tbReplace.Text;
            }
            this.SelectedRichtextBox.SelectionStart = 0;

        }
        #endregion 

        #region btnCancel_Click
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion 

        #region PageReplace_FormClosed
        /// <summary>
        /// clear the static class when close the replace window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PageReplace_FormClosed(object sender, FormClosedEventArgs e)
        {
            SingaltonPageReplace = null;
        }
        #endregion 

        /// <summary>
        /// press esc key , close form
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape) this.Close();
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void tbFind_TextChanged(object sender, EventArgs e)
        {
            if (this.tbFind.Text.Trim() != string.Empty)
            {
                this.btnFindNext.Enabled = true;
                this.btnReplace.Enabled = true;
                this.btnReplaceAll.Enabled = true;

            }
            else
            {
                this.btnFindNext.Enabled = false;
                this.btnReplace.Enabled = false;
                this.btnReplaceAll.Enabled = false;

            }
        }

        private void PageReplace_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }



    }

}