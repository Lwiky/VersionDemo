using System;
using System.Collections.Generic;
using System.Text;

namespace GLTc.QuickNote.CustomControl
{
    public interface ILanguageToolBar
    {
        void ShowToolBar();
        void CloseToolBar();
    }
}
