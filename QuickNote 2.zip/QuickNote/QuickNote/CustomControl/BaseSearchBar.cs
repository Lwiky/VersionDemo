using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace GLTc.QuickNote.CustomControl
{
    public abstract class BaseSearchBar:UserControl
    {


        private bool focused;

        public new virtual bool Focused
        {
            get { return focused; }

        }
	
        #region GetSearchToolbarID
        /// <summary>
        /// get the searchtoobar id
        /// </summary>
        /// <param name="ContextID"></param>
        /// <returns></returns>
        public static string GetSearchToolbarID(string ContextID)
        {
            return "STB" + ContextID;

        }
        #endregion 

    }
}
