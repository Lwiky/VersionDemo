using System;
using System.Collections.Specialized;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Printing;
using System.ComponentModel;
using System.Collections;


namespace GLTc.QuickNote.CustomControl
{
    public class CustomTabControl :TabControl
    {
        private TabPage drag_tab;

        /// <summary>
        /// tips line for drag item of Tabpage
        /// </summary>
        private Rectangle PreviouRectangle;
        private bool IsPreviouRectangleInvaliable;

        private bool IsDragTapPage;

        private Point PreviousPoint;

        /// <summary>
        /// Constractor
        /// </summary>
        public CustomTabControl(): base()
        {
            InitializeComponent();
            this.AllowDrop = true;
 
        }

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        }
        #endregion

        #region OnDragOver
        protected override void OnDragOver(System.Windows.Forms.DragEventArgs e)
        {
            base.OnDragOver(e);

            Point pt = new Point(e.X, e.Y);
            //We need client coordinates.
            pt = PointToClient(pt);
            drag_tab = null;
            //Get the tab we are hovering over.
            TabPage hover_tab = GetTabPageByTab(pt);

            //Make sure we are on a tab.
            if (hover_tab != null)
            {
                //Make sure there is a TabPage being dragged.
                if (e.Data.GetDataPresent(typeof(TabPage)))
                {

                    drag_tab = (TabPage)e.Data.GetData(typeof(TabPage));
                    e.Effect = DragDropEffects.Move;
                    Rectangle hoverRect = this.GetTabRect(FindIndex(hover_tab));
                    Rectangle dragRect = this.GetTabRect(FindIndex(drag_tab));
                    if (hoverRect != PreviouRectangle)
                    {
                        this.Invalidate(PreviouRectangle);
                    }
                    if (hover_tab != drag_tab)
                    {
                        if (IsDragAction(FindIndex(hover_tab), FindIndex(drag_tab), pt))
                        {
                            this.PaintNewPositionOfDraggedItem(hoverRect, dragRect);
                        }
                        else
                        {
                            this.Invalidate(PreviouRectangle);
                        }
                    }
                    this.PreviouRectangle = hoverRect;

                }
            }
            else
            {
                e.Effect = DragDropEffects.All;
            }
        }
        #endregion 

        #region OnMouseDown
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button == MouseButtons.Left && e.Clicks == 1)
            {
                IsDragTapPage = true;
                PreviousPoint = new Point(e.X, e.Y);
            }

        }


        #endregion 

        #region OnMouseMove
        protected override void OnMouseMove(MouseEventArgs e)
        {
            //if the mouse move distance more 2 pix than PreviousPoint of mourse down , then drag the item
            if (IsDragTapPage && (Math.Abs(e.X - PreviousPoint.X) > 2 || Math.Abs(e.Y - PreviousPoint.Y) >2))
            {

                Point pt = new Point(e.X, e.Y);
                TabPage tp = GetTabPageByTab(pt);

                if (tp != null)
                {
                    DoDragDrop(tp, DragDropEffects.Move);
                }
                IsDragTapPage = false;
            }
            base.OnMouseMove(e);

            //refresh the invalide region of previous tabpage
            if (!this.ClientRectangle.Contains(PointToClient(e.Location)) && IsPreviouRectangleInvaliable )
            {
                this.Invalidate(PreviouRectangle);
                IsPreviouRectangleInvaliable = false;
            }
        }
        #endregion 

        #region OnDragDrop
        protected override void OnDragDrop(DragEventArgs drgevent)
        {
            base.OnDragDrop(drgevent);
            Point p = this.PointToClient(new Point(drgevent.X, drgevent.Y));

            TabPage hover_tab = GetTabPageByTab(p);

            int item_drag_index = FindIndex(drag_tab);
            int drop_location_index = FindIndex(hover_tab);



            //Don't do anything if we are hovering over ourself.
            if (item_drag_index != drop_location_index)
            {
                if (IsDragAction(FindIndex(hover_tab), FindIndex(drag_tab), p))
                {
                    ArrayList pages = new ArrayList();

                    //Put all tab pages into an array.
                    for (int i = 0; i < TabPages.Count; i++)
                    {
                        //Except the one we are dragging.
                        if (i != item_drag_index)
                            pages.Add(TabPages[i]);
                    }

                    //Now put the one we are dragging it at the proper location.
                    pages.Insert(drop_location_index, drag_tab);

                    //Make them all go away for a nanosec.
                    TabPages.Clear();

                    //Add them all back in.
                    TabPages.AddRange((TabPage[])pages.ToArray(typeof(TabPage)));

                    //Make sure the drag tab is selected.
                    SelectedTab = drag_tab;

                    //release drag_tab;
                    drag_tab = null;
                }
            }
        }
        #endregion 

        #region GetTabPageByTab
        /// <summary>
        /// Finds the TabPage whose tab is contains the given point.
        /// </summary>
        /// <param name="pt">The point (given in client coordinates) to look for a TabPage.</param>
        /// <returns>The TabPage whose tab is at the given point (null if there isn't one).</returns>
        private TabPage GetTabPageByTab(Point pt)
        {
            TabPage tp = null;

            for (int i = 0; i < TabPages.Count; i++)
            {
                if (GetTabRect(i).Contains(pt))
                {
                    tp = TabPages[i];
                    break;
                }
            }

            return tp;
        }
        #endregion 

        #region FindIndex
        /// <summary>
        /// Loops over all the TabPages to find the index of the given TabPage.
        /// </summary>
        /// <param name="page">The TabPage we want the index for.</param>
        /// <returns>The index of the given TabPage(-1 if it isn't found.)</returns>
        private int FindIndex(TabPage page)
        {
            for (int i = 0; i < TabPages.Count; i++)
            {
                if (TabPages[i] == page)
                    return i;
            }

            return -1;
        }
        #endregion 

        #region PaintNewPositionOfDraggedItem
        private void PaintNewPositionOfDraggedItem(Rectangle hoverRect , Rectangle dragRect)
        {

            using (Graphics g = this.CreateGraphics())
            {
               
                Pen tipsPen = new Pen(Brushes.Blue, 2);
                if (dragRect.X > hoverRect.X)
                {
                    //if the you want to drag the tabpage to its fore direction 
                    g.DrawLine(tipsPen, new Point(hoverRect.Location.X+1, hoverRect.Location.Y), 
                        new Point(hoverRect.Location.X+1, hoverRect.Location.Y + hoverRect.Height-1));
                }
                else
                {
                    //if you want to drag the tabpage to back direction
                    g.DrawLine(tipsPen, new Point(hoverRect.Location.X + hoverRect.Width-3, hoverRect.Location.Y), 
                        new Point(hoverRect.Location.X + hoverRect.Width-3, hoverRect.Location.Y + hoverRect.Height-1));
                }
                this.IsPreviouRectangleInvaliable = true;

            }


        }
        #endregion 

        #region IsDragAction
        /// <summary>
        /// if the point is external the half of hover tab, the move effect will be enable
        /// </summary>
        /// <param name="hoverItemIndex"></param>
        /// <param name="hoverPoint"></param>
        /// <returns></returns>
        private bool IsDragAction(int hoverItemIndex,int dragItemIndex, Point hoverPoint)
        {
            bool isDragActionEnable = false;
            Rectangle hoverRect = this.GetTabRect(hoverItemIndex);
           
            if (hoverItemIndex < dragItemIndex)
            {
                hoverRect = new Rectangle(hoverRect.X, hoverRect.Y, hoverRect.Width / 2, hoverRect.Height);

            }
            else if (hoverItemIndex > dragItemIndex)
            {
                hoverRect = new Rectangle(hoverRect.X + hoverRect.Width / 2, hoverRect.Y, hoverRect.Width / 2, hoverRect.Height);
            }
            if (hoverRect.Contains(hoverPoint))
            {
                isDragActionEnable = true;
            }
            return isDragActionEnable;

        }
        #endregion 


    }
}
