using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;
using GLTc.NoteLib;
namespace GLTc.QuickNote.Command
{
    public class TreeNodeOperator
    {

        private const string TreeViewDataTableName = "ContextTree";
        private const string ContextInfoTableName = "ContextInfo";

        /// <summary>
        /// context tree Id
        /// </summary>
        public string ContextTreeID;

        private AccessDatabase ADB = new AccessDatabase();
        /// <summary>
        /// the original Node name 
        /// </summary>
        private string OriginalNodeName;
        /// <summary>
        /// the orginal Index string for judging whether quicknote need to update the value;
        /// </summary>
        private string OriginalIndexString;

        private string FullPath;
        public TreeNodeOperator(string TreeNodeID,string NodeFullPath)
        {
            this.ContextTreeID = TreeNodeID;
            this.FullPath = NodeFullPath;
 
        }
        /// <summary>
        /// get the treenode information
        /// </summary>
        /// <returns></returns>
        public TreeNodeInfo GetTreeNodeInfo()
        {
            string sqlText = string.Format(@"select CI.IndexString ,CI.CreateTime as CT,CI.UpdateTime as UT, CT.* FROM ContextTree AS CT  Left Join ContextInfo AS CI
                                             on CI.ContextInfoID =  CT.ContextTreeID
                                                where CT.ContextTreeID = '{0}'",this.ContextTreeID);

            DataSet ds = this.ADB.ExecuteDataSet(sqlText);
            DataRow dr = ds.Tables[0].Rows[0];
            string nodeName = dr["NodeName"].ToString();
            this.OriginalNodeName = nodeName;
            int    nodeType = Convert.ToInt32(dr["NodeTypeID"].ToString());
            string IndexInfo = dr["IndexString"].ToString();
            this.OriginalIndexString = IndexInfo;
            string createdDate = dr["CT"].ToString();
            string updatedDate = dr["UT"] == null ? "" : dr["UT"].ToString();
            if (nodeType != 2)
            {
                updatedDate = dr["UpdateTime"] == null ? "" : dr["UpdateTime"].ToString();
            }
            TreeNodeInfo currNodeInfo = new TreeNodeInfo(this.ContextTreeID, nodeName, nodeType, FullPath
                                        , IndexInfo, createdDate, updatedDate);

            return currNodeInfo;

 
        }

        /// <summary>
        /// Update the treenode information
        /// </summary>
        /// <param name="changedTreeNodeInfo">changed treenode object</param>
        public bool UpDateTreeNodeInfo(TreeNodeInfo changedTreeNodeInfo)
        {
            bool IsUpdate = false;
            if (this.OriginalNodeName == changedTreeNodeInfo.NodeName && this.OriginalIndexString == changedTreeNodeInfo.IndexInfo)
            {
                return IsUpdate;
            }
            string updateNodeSqlText = string.Format("Select * From {0} where ContextTreeID = '{1}' ", TreeViewDataTableName,changedTreeNodeInfo.ContextTreeID);
            string updateContextSqlText = string.Format("Select * From {0} where ContextInfoID = '{1}' ", ContextInfoTableName, changedTreeNodeInfo.ContextTreeID);
            using (OleDbConnection connection = AccessDatabase.CreateConnnection())
            {

                connection.Open();
                DataSet contextTreeDS = new DataSet();
                DataSet contextInfoDS = new DataSet();
                OleDbTransaction updatetransaction = connection.BeginTransaction();
                // create two adapter and commandbuilder to insert to records in one transaction
                OleDbDataAdapter nodeAdpter = new OleDbDataAdapter();
                OleDbDataAdapter contextAdapter = new OleDbDataAdapter();
                nodeAdpter.SelectCommand = new OleDbCommand(updateNodeSqlText, connection, updatetransaction);
                contextAdapter.SelectCommand = new OleDbCommand(updateContextSqlText, connection, updatetransaction);
                OleDbCommandBuilder nodeBuilder = new OleDbCommandBuilder(nodeAdpter);
                OleDbCommandBuilder contextBuilder = new OleDbCommandBuilder(contextAdapter);

                nodeAdpter.Fill(contextTreeDS);
                contextAdapter.Fill(contextInfoDS);


                try
                {
                    // add transaction in transation 
                    nodeAdpter.UpdateCommand = nodeBuilder.GetUpdateCommand();
                    contextAdapter.UpdateCommand = contextBuilder.GetUpdateCommand();

                    nodeAdpter.UpdateCommand.Transaction = updatetransaction;
                    contextAdapter.UpdateCommand.Transaction = updatetransaction;

                    //add new row in contextTreeDS and contextInfoDS;

                    //update to tree table
                    DataRow dr = contextTreeDS.Tables[0].Rows[0];
                    dr["NodeName"] = changedTreeNodeInfo.NodeName;
                    dr["UpdateTime"] = DateTime.Now;

                    //update contextinfo table
                    if (contextInfoDS.Tables[0].Rows.Count > 0)
                    {
                        DataRow drcontext = contextInfoDS.Tables[0].Rows[0];
                        drcontext["IndexString"] = changedTreeNodeInfo.IndexInfo;
                        drcontext["UpdateTime"] = DateTime.Now;
                    }

                    //update the two records
                    nodeAdpter.Update(contextTreeDS);
                    contextAdapter.Update(contextInfoDS);
                    //commit the change
                    updatetransaction.Commit();
                    IsUpdate = true;

                }
                catch (Exception ex)
                {
                    updatetransaction.Rollback();
                    throw (ex);
                }


            }

            return IsUpdate;
 
        }

 

    }
}
