using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using GLTc.QuickNote.CustomControl;
namespace GLTc.QuickNote.Command.ViewSourceCode
{
    public class ViewSourceInFormat
    {
        private TabPage selectedTabPage;
        public TabPage SelectedTabPage
        {
            get { return selectedTabPage; }
            set 
            {
                selectedTabPage = value;
            }
        }
	
        #region SelectedRichTextBox
        /// <summary>
        /// the selected RichTextbox
        /// </summary>
        public CustomRichTextBox  SelectedRichTextBox
        {
            get
            {
                CustomRichTextBox  rtb = null;
                TabPage selectedPage = this.SelectedTabPage;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        string tabpagePannelID =ContextOperator.GetSplitContainerName(cbi.ContextInfoID);
                        string selectedRichTextBoxId = ContextOperator.ConstructRichTextBoxName(cbi.ContextInfoID);
                        Control[] ctrls = selectedPage.Controls.Find(selectedRichTextBoxId, true);
                        if (ctrls.Length > 0)
                        {
                            rtb = (CustomRichTextBox)ctrls[0];
                        }
                    }
                }

                return rtb;
                
            }

        }
        #endregion 

        #region SelectedSplitContainerInTabPage
        /// <summary>
        /// the selected splitContainer in the Tappage
        /// </summary>
        public SplitContainer SelectedSplitContainerInTabPage
        {
            get
            {
                SplitContainer selectedSplitContainer = null;
                TabPage selectedPage = this.SelectedTabPage;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        string tabpagePannelID = ContextOperator.GetSplitContainerName(cbi.ContextInfoID);

                        selectedSplitContainer = (SplitContainer)selectedPage.Controls[tabpagePannelID];
                    }
                }

                return selectedSplitContainer;

            }
        }
        #endregion 

        #region SelectContextSplitControl
        public SplitContainer SelectContextSplitControl
        {
            get
            {
                SplitContainer contextSplitControl = null;
                if (this.SelectedTabPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)SelectedTabPage.Tag;
                    string contextsplicontrolId = ContextOperator.GetContextSplitContainerName(cbi.ContextInfoID);
                    Control[] ctrls = this.SelectedTabPage.Controls.Find(contextsplicontrolId, true);
                    if (ctrls.Length > 0)
                    {
                        contextSplitControl = (SplitContainer)ctrls[0];
                    }
                }
                return contextSplitControl;

            }

        }
        #endregion 

        /// <summary>
        /// Current languageViewer type
        /// </summary>
        private LanguageViewer CurrentLangeViewer ;

        #region ViewSourceCode
        /// <summary>
        /// view source code in custom format
        /// </summary>
        /// <param name="customFactory">language factory defined by user</param>
        /// <param name="SelectedTabPage">current tab page</param>
        public  void ViewSourceCode(LanguageViewerFactory customFactory,TabPage SelectedTabPage,UserControl IToobar)
        {
            
            LanguageViewer lv = customFactory.GetLanguageViewer(SelectedTabPage);
            lv.ViewSourceCode();
            // if the toolbar is valible for this program language , add it and show it
            if (IToobar != null)
            {
                this.SelectedSplitContainerInTabPage.Panel2.Controls.Add(IToobar);
                IToobar.Dock = DockStyle.Fill;
                this.SelectedSplitContainerInTabPage.SplitterDistance = this.SelectedSplitContainerInTabPage.Width - 150;
                ((ILanguageToolBar)IToobar).ShowToolBar();
            }

        }
        #endregion

        #region ViewSourceCode
        /// <summary>
        /// view source code in custom format
        /// </summary>
        /// <param name="customFactory">language factory defined by user</param>
        /// <param name="SelectedTabPage">current tab page</param>
        public void ViewSourceCode(LanguageViewerFactory customFactory, TabPage SelectedTabPage, UserControl IToobar,  bool IsNewLanguage)
        {
            
            CurrentLangeViewer = customFactory.GetLanguageViewer(SelectedTabPage);
            CurrentLangeViewer.ViewSourceCode();
            // if new language ,clear the right tool bar
            if (IsNewLanguage && this.SelectedSplitContainerInTabPage.Panel2.Controls.Count > 0)
            {
                this.SelectedSplitContainerInTabPage.Panel2.Controls.Clear();
                this.SelectedSplitContainerInTabPage.Panel2Collapsed = true;
            }
            // if the toolbar is valible for this program language , add it and show it
            if (IToobar != null)
            {
                this.SelectedSplitContainerInTabPage.Panel2.Controls.Add(IToobar);
                IToobar.Dock = DockStyle.Fill;
                this.SelectedSplitContainerInTabPage.SplitterDistance = this.SelectedSplitContainerInTabPage.Width - 150;
                ((ILanguageToolBar)IToobar).ShowToolBar();
            }

        }
        #endregion 

        #region ViewSourceCodeWithSearchBar
        /// <summary>
        /// view source code in custom format with the search bar
        /// </summary>
        public void ViewSourceCodeWithSearchBar(LanguageViewerFactory customFactory, TabPage SelectedTabPage,UserControl SearchBar, UserControl IToobar, bool IsNewLanguage)
        {
            this.SelectedTabPage = SelectedTabPage;
            //UserControl SearchBar = new SearchToolBar(this.SelectedRichTextBox,"CLP",CurrentLangeViewer);
             //create searchbar
            ContextBaseInfo cbi = (ContextBaseInfo)this.SelectedTabPage.Tag;
            string searchbarName =BaseSearchBar.GetSearchToolbarID(cbi.ContextInfoID);
            if (this.SelectedTabPage.Controls.Find(searchbarName, true).Length != 0)
            {
                this.SelectContextSplitControl.Panel1.Controls.Clear();
                this.SelectContextSplitControl.Panel1Collapsed = true;
            }

            this.SelectContextSplitControl.SplitterDistance = SearchBar.Height;
            //this.SelectContextSplitControl.Panel1MinSize = SearchBar.Height;
            this.SelectContextSplitControl.Panel1.Controls.Add(SearchBar);
            this.SelectContextSplitControl.Panel1Collapsed = false;
            SearchBar.Name = searchbarName;
            SearchBar.Dock = DockStyle.Fill;

            this.ViewSourceCode(customFactory, SelectedTabPage, IToobar, IsNewLanguage);
        }
        #endregion 
    }
}
