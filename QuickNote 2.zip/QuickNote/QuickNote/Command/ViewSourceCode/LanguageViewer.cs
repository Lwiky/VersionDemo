using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using GLTc.QuickNote.CustomControl;

namespace GLTc.QuickNote.Command.ViewSourceCode
{
     public abstract class LanguageViewer
    {



         /// <summary>
         /// the right selected table page
         /// </summary>
         public abstract TabPage SelectedTabPage
         {
             get;
             set;
         }
         /// <summary>
         /// Select richtextbox
         /// </summary>
         public abstract CustomRichTextBox SelectedRichTextBox
         {
             get;
         }

         /// <summary>
         /// Source Code with Comment
         /// </summary>
         public string OriganlSourceCode;


         /// <summary>
         /// view source by custom rule
         /// </summary>
         public abstract void ViewSourceCode();


         #region GetRichTextBoxName
         /// <summary>
         /// get the rich text box name
         /// </summary>
         /// <param name="ContextInfoId"></param>
         /// <returns></returns>
         public string GetRichTextBoxName(string ContextInfoId)
         {
             return "RTB" + ContextInfoId;

         }
         #endregion 
         
         #region ShowOriganalSource
         /// <summary>
         /// Show the comment
         /// </summary>
         public virtual void ShowOriganalSource()
         {
             if (!string.IsNullOrEmpty(this.OriganlSourceCode))
             {
                 this.SelectedRichTextBox.Rtf = this.OriganlSourceCode;
             }
         }
         #endregion

         #region HideCommentOfSource
         /// <summary>
         /// Hidden the Comment
         /// </summary>
         public virtual void HideCommentOfSource(CustomRichTextBox SelectRichtextBox)
         {

         }
         #endregion 

    }
}
