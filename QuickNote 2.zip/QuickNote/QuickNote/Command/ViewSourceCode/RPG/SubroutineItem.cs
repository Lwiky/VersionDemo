using System;
using System.Collections.Generic;
using System.Text;

namespace GLTc.QuickNote.Command.ViewSourceCode.RPG
{
   public  class SubroutineItem
    {
       public string SubroutineName;
       public string SubRoutineBegainFullName;
       public string SubroutineBody;
       public SubroutineItem(string subroutineName ,string subRoutineBegainFullName)
       {
           this.SubroutineName = subroutineName;
           this.SubRoutineBegainFullName = subRoutineBegainFullName;
           this.SubroutineBody = SubroutineName;
       }

       public SubroutineItem(string subroutineName, string subRoutineBegainFullName, string subroutineBodyText)
       {
           this.SubroutineName = subroutineName;
           this.SubRoutineBegainFullName = subRoutineBegainFullName;
           this.SubroutineBody = subroutineBodyText;
       }
       

       
    }
}
