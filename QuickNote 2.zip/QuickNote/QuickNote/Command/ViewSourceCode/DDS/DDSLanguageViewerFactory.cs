using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using GLTc.QuickNote.CustomControl;

namespace GLTc.QuickNote.Command.ViewSourceCode.DDS
{
    public class DDSLanguageViewerFactory : LanguageViewerFactory
    {
        public override LanguageViewer GetLanguageViewer(TabPage SelectTabPage)
        {
            return new DDSLanguageViewer(SelectTabPage);
        }
    }
}
