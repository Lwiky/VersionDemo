using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Windows.Forms;
using GLTc.QuickNote.CustomControl;
using System.Runtime.InteropServices;
using System.Configuration;

namespace GLTc.QuickNote.Command.ViewSourceCode.DDS
{
    public class DDSLanguageViewer : LanguageViewer
    {
        #region Constructor
        public DDSLanguageViewer(TabPage SelectTabPage)
        {
            this.SelectedTabPage = SelectTabPage;

        }

        #endregion 

        #region SelectedTabPage
        private TabPage selectedTabPage;
        /// <summary>
        /// the selected Tabpage  which is the parent control of richtextbox
        /// </summary>
        public override TabPage SelectedTabPage
        {

            get
            {
                return selectedTabPage;
            }
            set 
            {
                selectedTabPage = value;
            }
        }
        #endregion 

        #region SelectedToolBar
        /// <summary>
        /// the selected RPGTool in the Tappage
        /// </summary>
        public ILanguageToolBar SelectedToolBar
        {
            get
            {
                ILanguageToolBar currentlanguageTool = null;
                TabPage selectedPage = this.SelectedTabPage;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)SelectedTabPage.Tag;
                    if (cbi != null)
                    {
                        string tabpagePannelID = ContextOperator.GetSplitContainerName(cbi.ContextInfoID);
                        string selectedtoolId = ContextOperator.GetRPGToolName(cbi.ContextInfoID);
                        currentlanguageTool = (ILanguageToolBar)(((SplitContainer)selectedPage.Controls[tabpagePannelID]).Panel2.Controls[selectedtoolId]);
                    }
                }

                return currentlanguageTool;

            }
        }
        #endregion 

        #region SelectedRichTextBox

        private CustomRichTextBox selectedRichTextBox;

        /// <summary>
        /// Current source code container
        /// </summary>
        public override CustomRichTextBox SelectedRichTextBox
        {
            get
            {
                if (selectedRichTextBox == null)
                {
                    if (SelectedTabPage != null)
                    {
                        ContextBaseInfo cbi = (ContextBaseInfo)SelectedTabPage.Tag;
                        if (cbi != null)
                        {
                            string tabpagePannelID = ContextOperator.GetSplitContainerName(cbi.ContextInfoID);
                            string selectedRichTextBoxId = this.GetRichTextBoxName(cbi.ContextInfoID);
                            Control[] ctrls = SelectedTabPage.Controls.Find(selectedRichTextBoxId, true);
                            if (ctrls.Length > 0)
                            {
                                selectedRichTextBox = (CustomRichTextBox)ctrls[0];
                            }

                        }
                    }
                }

                return selectedRichTextBox;
            }
        }
    #endregion 

                
        #region SelectedSearchToolBar
        /// <summary>
        /// Selected RPG search toolbar
        /// </summary>
        public SearchToolBar SelectedSearchToolBar
        {
            get
            {
                SearchToolBar SearchToolbar = null;
                if (this.SelectedTabPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)SelectedTabPage.Tag;
                    string searchtoolbarID = SearchToolBar.GetSearchToolbarID(cbi.ContextInfoID);
                    Control[] ctrls = this.SelectedTabPage.Controls.Find(searchtoolbarID, true);
                    SearchToolbar = (SearchToolBar)ctrls[0];
                }
                return SearchToolbar;
            }
        }
        #endregion 
                
        /// <summary>
        /// RPG format language
        /// </summary>
        private FormatLanguage FormatDDSLanguage;

        #region ViewSourceCode
        /// <summary>
        /// view source code by RPG format
        /// </summary>
        public override void ViewSourceCode()
        {

            //change the font to counter new and size to 11
            this.SelectedRichTextBox.Font = new Font("Courier New", 11);
            this.SelectedRichTextBox.TextColor = RtfColor.Black;
            this.SelectedRichTextBox.WordWrap = false;
            //highlist code color
            FormatDDSLanguage = new FormatLanguage(this.SelectedRichTextBox, "DDS");
            FormatDDSLanguage.HighLightByRegularExpressRule();
            //add event of searchbar
            this.SelectedSearchToolBar.ShowAllSourceEvent += new ShowWholeSource(SelectedRPGSearchToolBar_ShowAllSourceEvent);
            this.SelectedSearchToolBar.HideSourceCommentEvent += new HideSourceComment(SelectedRPGSearchToolBar_HideSourceCommentEvent);
            

        }
        #endregion 

        public override void HideCommentOfSource(CustomRichTextBox SourceRichtexbox)
        {

            if (string.IsNullOrEmpty(this.OriganlSourceCode))
            {
                this.OriganlSourceCode = SourceRichtexbox.Rtf;
                FormatDDSLanguage.LoadXmlConfiguration();
            }
            string commentRegstr = @"(\\cf\d[\s]{0,7}" + FormatDDSLanguage.GetCommentRegularExpress() + ")+";
            Regex commentReg = new Regex(commentRegstr);
            SourceRichtexbox.Rtf = commentReg.Replace(SourceRichtexbox.Rtf, "");

        }


        #region ShowandHideCommentofSource
        void SelectedRPGSearchToolBar_HideSourceCommentEvent()
        {
            this.HideCommentOfSource(this.SelectedRichTextBox);
        }

        void SelectedRPGSearchToolBar_ShowAllSourceEvent()
        {

            this.ShowOriganalSource();
        }
        #endregion 

    }
}
