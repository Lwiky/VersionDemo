using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Collections;
using System.Data;
using System.Data.OleDb;
using System.Threading;
using ADOX;
using GLTc.NoteLib;

namespace GLTc.QuickNote.Command.TransferData
{
    public class CopyData
    {

        private const string TreeViewDataTableName = "ContextTree";
        private const string ContextInfoTableName = "ContextInfo";
        private const string CopyTableName = "CopyTempTable";

        /// <summary>
        /// Hashtable for older ContextTreeID and New ContextTreeID
        /// </summary>
        private Hashtable HTNewContextID = new Hashtable();

        /// <summary>
        /// Import tips window
        /// </summary>
        private ExportImportTips EIT = new ExportImportTips();


        /// <summary>
        /// Create Copy table sql Clause
        /// </summary>
        private string sqlCreateCopyTableClause = @"Create Table  CopyTempTable 
                                                ( CopyID   varchar(36) primary key)";
        /// <summary>
        /// the access databse
        /// </summary>
        private AccessDatabase ADB = new AccessDatabase();
      
        #region Constuctor

        public CopyData()
        {

        }
        #endregion 

        #region PasteNodeData
        /// <summary>
        /// Import Data to CurrentDataBase
        /// </summary>
        /// <param name="ParentID"></param>
        public void PasteNodeData(string FromNodeID, string ToNodeID)
        {

            Thread CopyTipsThread = new Thread(new ThreadStart(new ControlExportInportTipWindow(this.ShowImportWindow)));
            CopyTipsThread.Start();
            Thread.Sleep(2);
            //Create CopyData Table if it is not exist;
            this.CreateCopyTable();
            this.InsertContextIdIntoCopyTable(FromNodeID);
            //Copy data to current database file
            this.TransferData(ToNodeID);
            this.EIT.BeginInvoke(new ControlExportInportTipWindow(this.CloseImportWindow));


        }
        #endregion

        #region ShowImportWindow
        /// <summary>
        /// show import tips windows
        /// </summary>
        private void ShowImportWindow()
        {
            this.EIT.ShowDialog();

        }
        #endregion

        #region CloseImportWindow
        /// <summary>
        /// Close import tips windows
        /// </summary>
        private void CloseImportWindow()
        {
            this.EIT.Close();
        }
        #endregion

        #region CreateCopyTable
        /// <summary>
        /// Create CopyTable
        /// </summary>
        private void CreateCopyTable()
        {
            DataTable tableInfo = GetAllTablesInDataBase();
            DataRow[] drs = tableInfo.Select(string.Format("Table_Name = '{0}'", CopyTableName));
            if (drs.Length <= 0)
            {
                this.ADB.ExecuteNonQuery(sqlCreateCopyTableClause);
            }

        }
        #endregion 

        #region InsertContextIdIntoCopyTable
        /// <summary>
        /// Insert Exporting Data to ExportTable 
        /// </summary>
        /// <param name="ParentID">ParentID</param>
        private  void InsertContextIdIntoCopyTable(string ParentID)
        {
            //Delete All record in Exporttable
            string DeleteSqlText = string.Format("Delete From {0}  ", CopyTableName);
            this.ADB.ExecuteNonQuery(DeleteSqlText);

            //All Tree Nodes 
            string NodeSqlText = string.Format("Select ContextTreeID,ParentID From {0}  ", TreeViewDataTableName);
            DataSet NodeDs = this.ADB.ExecuteDataSet(NodeSqlText);

            //Get the Copy DataTable
            string sqlText = string.Format("Select * from {0} ", CopyTableName);
            DataSet ds = this.ADB.ExecuteDataSet(sqlText, CopyTableName);

            //Insert Data  to Export DataTable

            InsertContextIdIntoCopyTable(ParentID, NodeDs.Tables[0], ds.Tables[0]);
            this.ADB.UpdateDataSet(ds);





        }
        #endregion

        #region InsertContextIdIntoCopyTable
        /// <summary>
        /// recursive insert data to Export datatable 
        /// </summary>
        /// <param name="ParentID"></param>
        /// <param name="NodeTable"></param>
        /// <param name="ExportTable"></param>
        private void InsertContextIdIntoCopyTable(string ParentID, DataTable NodeTable, DataTable CopyTable)
        {
            DataRow[] childrendrs = NodeTable.Select(string.Format("ParentID = '{0}'", ParentID));
            DataRow[] parentdrs = NodeTable.Select(string.Format("ContextTreeId = '{0}'", ParentID));

            //all  current row
            if (parentdrs.Length > 0)
            {
                DataRow dr = CopyTable.NewRow();
                dr[0] = parentdrs[0]["ContextTreeId"].ToString();
                CopyTable.Rows.Add(dr);

            }

            foreach (DataRow dr in childrendrs)
            {
                InsertContextIdIntoCopyTable(dr["ContextTreeId"].ToString(), NodeTable, CopyTable);
            }

        }
        #endregion 

        #region GetAllTablesInDataBase
        /// <summary>
        /// get all the table in access database
        /// </summary>
        /// <returns></returns>
        private DataTable GetAllTablesInDataBase()
        {
            DataTable schemaTable = null;
            using (OleDbConnection connection = AccessDatabase.CreateConnnection())
            {
                connection.Open();
                schemaTable = connection.GetOleDbSchemaTable(
                   OleDbSchemaGuid.Tables,
                   new object[] { null, null, null, "TABLE" });

            }
            return schemaTable;

        }
        #endregion 
        
        #region TransferData
        /// <summary>
        /// Transfer import data to current database
        /// </summary>
        private void TransferData(string ParentID)
        {
            string contextTreeSqlClause = string.Format(@"Select * from  ContextTree where ContextTreeId = ''");

            string contextInfoSqlClause = string.Format(@"Select * from  ContextInfo where ContextInfoID = ''");

            //string pasteContextTreeSqlClause = "Select * from ContextTree where ContextTreeId in (select CopyID from CopyTempTable)";
            string pasteContextTreeSqlClause = "Select ContextTree.* from CopyTempTable LEFT JOIN ContextTree on CopyTempTable.CopyID = ContextTree.ContextTreeId ";
            string pasteContextInfoSqlClause = "Select * from ContextInfo where ContextInfoID in (select CopyID from CopyTempTable)";

            //load Context tree
            LoadDataToContextTreeTable(pasteContextTreeSqlClause, "ContextTree", contextTreeSqlClause, ParentID);

            //load Context Info
            LoadDataToContextInfo(pasteContextInfoSqlClause, "ContextInfo", contextInfoSqlClause);

        }
        #endregion

        #region LoadDataToContextTreeTable

        /// <summary>
        ///  import data to Context Tree table
        /// </summary>
        /// <param name="ImportsqlText"></param>
        /// <param name="contextTreeTableName"></param>
        /// <param name="DestinationSqlText"></param>
        private void LoadDataToContextTreeTable(string PastesqlText, string contextTreeTableName, string DestinationSqlText, string ParentId)
        {
            //create new Id and update row's parentid
            DataSet PasteDs = this.ADB.ExecuteDataSet(PastesqlText);
            DataSet DestinationDs = this.ADB.ExecuteDataSet(DestinationSqlText, contextTreeTableName);
            foreach (DataRow dr in PasteDs.Tables[0].Rows)
            {

                DataRow newdr = DestinationDs.Tables[0].NewRow();
                foreach (DataColumn dc in DestinationDs.Tables[0].Columns)
                {
                    string columnName = dc.ToString().ToLower();
                    if (columnName != "contexttreeid")
                    {
                        if (columnName != "parentid")
                        {
                            newdr[columnName] = dr[columnName];
                        }
                        else
                        {
                            string olderparentId = dr[columnName].ToString();
                            if (this.HTNewContextID[olderparentId] != null)
                            {
                                //the nodes after the first node
                                string newparentId = this.HTNewContextID[olderparentId].ToString();
                                newdr[columnName] = newparentId;
                            }
                            else
                            {
                                //the first node 
                                newdr[columnName] = ParentId;
                            }

                        }

                    }
                    else
                    {
                        // for the tree loop forwar sequence
                        //so the root will appear first
                        string OldId = dr[columnName].ToString();
                        string newID = Guid.NewGuid().ToString();
                        newdr[columnName] = newID;
                        this.HTNewContextID.Add(OldId, newID);
                    }

                }
                DestinationDs.Tables[0].Rows.Add(newdr);
            }
            this.ADB.UpdateDataSet(DestinationDs);

        }
        #endregion

        #region LoadDataToContextInfo
        /// <summary>
        /// load data to Context info table
        /// </summary>
        /// <param name="sqlText"></param>
        /// <param name="TableName"></param>
        /// <param name="DestinationSqlText"></param>
        private void LoadDataToContextInfo(string PastesqlText, string ContextInfoTableName, string DestinationSqlText)
        {
            //update new Id to ContextInfo
            DataSet pasteDs = this.ADB.ExecuteDataSet(PastesqlText);
            DataSet DestinationDs = this.ADB.ExecuteDataSet(DestinationSqlText, ContextInfoTableName);
            foreach (DataRow dr in pasteDs.Tables[0].Rows)
            {

                DataRow newdr = DestinationDs.Tables[0].NewRow();
                for (int i = 0; i < pasteDs.Tables[0].Columns.Count; i++)
                {
                    if (i != 0)
                    {
                        newdr[i] = dr[i];
                    }
                    else
                    {
                        string oldContextInfoId = dr[i].ToString();
                        newdr[i] = this.HTNewContextID[oldContextInfoId].ToString();
                    }

                }
                DestinationDs.Tables[0].Rows.Add(newdr);
            }
            this.ADB.UpdateDataSet(DestinationDs);

        }
        #endregion 
    }
}
