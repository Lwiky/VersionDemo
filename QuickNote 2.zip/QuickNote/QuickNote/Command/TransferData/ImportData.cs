using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Collections;
using System.Threading;
using System.Data;
using System.Data.OleDb;
using ADOX;
using GLTc.NoteLib;

namespace GLTc.QuickNote.Command.TransferData
{
    public delegate void ControlExportInportTipWindow();
    /// <summary>
    /// Import data to current DataBase
    /// </summary>
    public class ImportData
    {

        /// <summary>
        /// Hashtable for older ContextTreeID and New ContextTreeID
        /// </summary>
        private Hashtable HTNewContextID = new Hashtable();

        /// <summary>
        /// the access databse
        /// </summary>
        private AccessDatabase ADB = new AccessDatabase();

        /// <summary>
        /// the Import database Operator
        /// </summary>
        private AccessDatabase ImportADB;

        /// <summary>
        /// Import tips window
        /// </summary>
        private ExportImportTips EIT = new ExportImportTips();

        /// <summary>
        /// current quicknote full path
        /// </summary>
        private string CurrentBaseDirectory = AppDomain.CurrentDomain.BaseDirectory;
        /// <summary>
        /// export directoryName
        /// </summary>
        private const string ExportDirectoryName = "ExportData";


        #region ExportDirectoryFullName
        /// <summary>
        /// Current Export Directory Full Path 
        /// </summary>
        private string ExportDirectoryFullName
        {
            get
            {
                return CurrentBaseDirectory + ExportDirectoryName;
            }
        }
        #endregion 

        private string ConStr = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Jet OLEDB:Engine Type=5";

        private string ImportFileName;
        /// <summary>
        /// Export connection string 
        /// </summary>
        private string ImportConnnectionString
        {
            get
            {
                return string.Format(ConStr, ImportFileName);
            }
        }

        #region ImportData
        /// <summary>
        /// Constructor
        /// </summary>
        public ImportData()
        {

        }
        #endregion 

        #region ImportDataToCurrentDataBase
        /// <summary>
        /// Import Data to CurrentDataBase
        /// </summary>
        /// <param name="ParentID"></param>
        public bool ImportDataToCurrentDataBase(string ParentID)
        {
            //open the import file
           bool IsOpen = this.OpenImportFile();
           if (IsOpen)
           {
               Thread ImportTipsThread = new Thread(new ThreadStart(new ControlExportInportTipWindow(this.ShowImportWindow)));
               ImportTipsThread.Start();
               //instance the ImportDataAccess
               this.ImportADB = new AccessDatabase(this.ImportFileName);
               //import data to current database file
               this.TransferData(ParentID);
               this.EIT.BeginInvoke(new ControlExportInportTipWindow(this.CloseImportWindow));

           }
           return IsOpen;

        }
        #endregion 

        #region ShowImportWindow
        /// <summary>
        /// show import tips windows
        /// </summary>
        private void ShowImportWindow()
        {
            this.EIT.ShowDialog();

        }
        #endregion 

        #region CloseImportWindow
        /// <summary>
        /// Close import tips windows
        /// </summary>
        private void CloseImportWindow()
        {
            this.EIT.Close();
        }
        #endregion 

        #region OpenImportFile
        /// <summary>
        /// open the import database file
        /// </summary>
        private bool  OpenImportFile()
        {
            bool IsOpen = false;
            OpenFileDialog openFileDialog = new OpenFileDialog();
            this.CreatDefaultExportDirectory();
            openFileDialog.InitialDirectory = ExportDirectoryFullName;
            openFileDialog.Filter = "Access Files(*.mdb)|*.mdb";
            openFileDialog.Title = "Import From";
            openFileDialog.RestoreDirectory = true;
            openFileDialog.FilterIndex = 0;
            if (openFileDialog.ShowDialog() == DialogResult.OK )
            {
                  
                   this.ImportFileName = openFileDialog.FileName;
                   IsOpen = true;
          
            }
            return IsOpen;
        }
        #endregion 

        #region TransferData
        /// <summary>
        /// Transfer import data to current database
        /// </summary>
        private void TransferData(string ParentID)
        {
            string contextTreeSqlClause = string.Format(@"Select * from  ContextTree where ContextTreeId = ''");

            string contextInfoSqlClause = string.Format(@"Select * from  ContextInfo where ContextInfoID = ''");

            string importContextTreeSqlClause = "Select * from ContextTree";
            string importContextInfoSqlClause = "Select * from ContextInfo";

            //load Context tree
            LoadDataToContextTreeTable(importContextTreeSqlClause, "ContextTree", contextTreeSqlClause, ParentID);

            //load Context Info
            LoadDataToContextInfo(importContextInfoSqlClause, "ContextInfo", contextInfoSqlClause);

        }
        #endregion 

        #region LoadDataToContextTreeTable

        /// <summary>
        ///  import data to Context Tree table
        /// </summary>
        /// <param name="ImportsqlText"></param>
        /// <param name="contextTreeTableName"></param>
        /// <param name="DestinationSqlText"></param>
        private void LoadDataToContextTreeTable(string ImportsqlText, string contextTreeTableName, string DestinationSqlText,string ParentId)
        {
            //create new Id and update row's parentid
            DataSet importDs = this.ImportADB.ExecuteDataSet(ImportsqlText);
            DataSet DestinationDs = this.ADB.ExecuteDataSet(DestinationSqlText, contextTreeTableName);
            foreach (DataRow dr in importDs.Tables[0].Rows)
            {

                DataRow newdr = DestinationDs.Tables[0].NewRow();
                foreach (DataColumn dc in DestinationDs.Tables[0].Columns )
                {
                    string columnName = dc.ToString().ToLower();
                    if (columnName != "contexttreeid")
                    {
                        if (columnName != "parentid")
                        {
                            newdr[columnName] = dr[columnName];
                        }
                        else 
                        {
                            string olderparentId = dr[columnName].ToString();
                            if (this.HTNewContextID[olderparentId] != null)
                            {
                                //the nodes after the first node
                                string newparentId = this.HTNewContextID[olderparentId].ToString();
                                newdr[columnName] = newparentId;
                            }
                            else
                            {
                                //the first node 
                                newdr[columnName] = ParentId;
                            }
                            
                        }
                        
                    }
                    else
                    {
                        // for the tree loop forwar sequence
                        //so the root will appear first
                        string OldId = dr[columnName].ToString();
                        string newID = Guid.NewGuid().ToString();
                        newdr[columnName] = newID;
                        this.HTNewContextID.Add(OldId,newID);
                    }

                }
                DestinationDs.Tables[0].Rows.Add(newdr);
            }
            this.ADB.UpdateDataSet(DestinationDs);

        }
        #endregion 

        #region LoadDataToContextInfo
        /// <summary>
        /// load data to Context info table
        /// </summary>
        /// <param name="sqlText"></param>
        /// <param name="TableName"></param>
        /// <param name="DestinationSqlText"></param>
        private void LoadDataToContextInfo(string ImportsqlText, string ContextInfoTableName, string DestinationSqlText)
        {
            //update new Id to ContextInfo
            DataSet importDs = this.ImportADB.ExecuteDataSet(ImportsqlText);
            DataSet DestinationDs = this.ADB.ExecuteDataSet(DestinationSqlText,ContextInfoTableName);
            foreach (DataRow dr in importDs.Tables[0].Rows)
            {

                DataRow newdr = DestinationDs.Tables[0].NewRow();
                for (int i = 0; i < importDs.Tables[0].Columns.Count; i++)
                {
                    if (i != 0)
                    {
                        newdr[i] = dr[i];
                    }
                    else
                    {
                        string oldContextInfoId = dr[i].ToString();
                        newdr[i] = this.HTNewContextID[oldContextInfoId].ToString();
                    }

                }
                DestinationDs.Tables[0].Rows.Add(newdr);
            }
            this.ADB.UpdateDataSet(DestinationDs);

        }
        #endregion 

        #region CreatDefaultExportDirectory
        /// <summary>
        /// Create default exportDirectory
        /// </summary>
        private void CreatDefaultExportDirectory()
        {
            if (!Directory.Exists(ExportDirectoryFullName))
            {
                Directory.CreateDirectory(ExportDirectoryFullName);
            }
        }
        #endregion 
    }
}
