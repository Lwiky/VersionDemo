using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace GLTc.QuickNote.Command
{
    
    public enum  NodeOperator {Copy,Cut};
    /// <summary>
    /// Design for copy and cut operator  for treeNOde operator
    /// </summary>
    public static class TreeNodeProcessedInfo
    {
        public static TreeNode ProcessedTreeNode;

        public static NodeOperator ProcessedOperator;

    }
}
