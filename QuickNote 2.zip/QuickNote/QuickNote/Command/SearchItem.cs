using System;
using System.Collections.Generic;
using System.Text;

namespace GLTc.QuickNote.Command
{
    public class SearchItem
    {
        public string ContextID;
        public string ShowText;

        public SearchItem(string contextID, string NodeItemText)
        {
            this.ContextID = contextID;
            this.ShowText = NodeItemText;
        }

        public override string ToString()
        {
            return ShowText;
        }
    }
}
