﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("QuickNote3.0")]
[assembly: AssemblyDescription("Get your information as quickly as possible,\r\n "+
                                "\r\nSave your time as much as possible!\r\n"+
                              "\r\nSupport Team:" +
                               "\r\nWiky W N LI/HSDC/HSBC"+
                             "\r\nZhi Qiang LIANG/HSDC/HSBC"+
                             "\r\nLyfok Y F LIN/HSDC/HSBC" +
                            "\r\nSenber S B CHEN/HSDC/HSBC"+
                           "\r\nBenny Y K XU/HSDC/HSBC")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("HSBC GLTc ")]
[assembly: AssemblyProduct("QuickNote3.0")]
[assembly: AssemblyCopyright("Copyright © 2008-2009 Wiky Gary")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("b6ed044c-7af8-48de-9708-b18c9342bb0b")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("3.0.*")]
//[assembly: AssemblyFileVersion("2.0SP3")]
[assembly: NeutralResourcesLanguageAttribute("en-US")]
