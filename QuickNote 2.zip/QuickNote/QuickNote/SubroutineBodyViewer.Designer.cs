namespace GLTc.QuickNote
{
    partial class SubroutineBodyViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TCSubroutine = new System.Windows.Forms.TableLayoutPanel();
            this.CRTBSubroutine = new GLTc.QuickNote.CustomControl.CustomRichTextBox();
            this.TCSubroutine.SuspendLayout();
            this.SuspendLayout();
            // 
            // TCSubroutine
            // 
            this.TCSubroutine.ColumnCount = 1;
            this.TCSubroutine.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TCSubroutine.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.TCSubroutine.Controls.Add(this.CRTBSubroutine, 0, 1);
            this.TCSubroutine.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TCSubroutine.Location = new System.Drawing.Point(0, 0);
            this.TCSubroutine.Name = "TCSubroutine";
            this.TCSubroutine.RowCount = 2;
            this.TCSubroutine.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.TCSubroutine.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TCSubroutine.Size = new System.Drawing.Size(549, 293);
            this.TCSubroutine.TabIndex = 0;
            // 
            // CRTBSubroutine
            // 
            this.CRTBSubroutine.AllowDrop = true;
            this.CRTBSubroutine.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CRTBSubroutine.EnableAutoDragDrop = true;
            this.CRTBSubroutine.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.CRTBSubroutine.HideSelection = false;
            this.CRTBSubroutine.HiglightColor = GLTc.QuickNote.CustomControl.RtfColor.White;
            this.CRTBSubroutine.Location = new System.Drawing.Point(3, 28);
            this.CRTBSubroutine.Name = "CRTBSubroutine";
            this.CRTBSubroutine.Size = new System.Drawing.Size(543, 262);
            this.CRTBSubroutine.TabIndex = 0;
            this.CRTBSubroutine.Text = "";
            this.CRTBSubroutine.TextColor = GLTc.QuickNote.CustomControl.RtfColor.Black;
            this.CRTBSubroutine.WordWrap = false;
            // 
            // SubroutineBodyViewer
            // 
            this.ClientSize = new System.Drawing.Size(549, 293);
            this.Controls.Add(this.TCSubroutine);
            this.Name = "SubroutineBodyViewer";
            this.Text = "SubroutineBody";
            this.TCSubroutine.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel TCSubroutine;
        private GLTc.QuickNote.CustomControl.CustomRichTextBox CRTBSubroutine;
    }
}