using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GLTc.QuickNote.CustomControl;
using GLTc.QuickNote.Command.ViewSourceCode;

namespace GLTc.QuickNote
{
    public partial class SubroutineBodyViewer : Form
    {
        public SubroutineBodyViewer(LanguageViewer CurrLangeViewer)
        {
            InitializeComponent();
            IntialSearchBar(CurrLangeViewer);

        }

        private void IntialSearchBar(LanguageViewer CurrLangeViewer)
        {
            //add the search tool bar
            SearchToolBar stb = new SearchToolBar(this.CRTBSubroutine, "RPG", CurrLangeViewer);
            stb.Dock = DockStyle.Fill;
            this.TCSubroutine.Controls.Add(stb, 0, 0);

        }



        /// <summary>
        /// set the subroutine body in the richtextbox
        /// </summary>
        /// <param name="Subroutine"></param>
        public void SetCurrentSubroutineBody(string Subroutine)
        {
            this.CRTBSubroutine.Text = Subroutine;
        }

    }
}