using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Data.Common;
namespace GLTc.NoteLib
{
    /// <summary>
    /// Access Data Access Class
    /// </summary>
    public class AccessDatabase : IDisposable
    {

        /// <summary>
        /// AccessDatabase base  Connection String
        /// </summary>
        private const string SqlConnectStr = @"PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA Source={0}";
        /// <summary>
        /// database Name
        /// </summary>
        public  static string DataBaseName = "NoteDataBase.MDB";

        /// <summary>
        ///  store the recent AccessAdapter in memory
        /// </summary>
        private OleDbDataAdapter AccessAdapter = null;

        private string currentDataBasePath;
        /// <summary>
        /// current access database file path
        /// </summary>
        public string CurrentDataBasePath
        {
            get
            {
                return currentDataBasePath;
            }
            set
            {
                currentDataBasePath = value;
            }

        }


        #region ConnectString
        /// <summary>
        /// Access database connection string
        /// </summary>
        private string ConnectString
        {
            get
            {
                string ConnectStr;
                if (string.IsNullOrEmpty(CurrentDataBasePath))
                {
                    if (DataBaseName.ToLower() != "NoteDataBase.MDB".ToLower())
                    {
                        ConnectStr = string.Format(SqlConnectStr, DataBaseName);
                    }
                    else
                    {
                        ConnectStr = string.Format(SqlConnectStr, AppDomain.CurrentDomain.BaseDirectory + DataBaseName);
                    }
                }
                else
                {
                    ConnectStr = string.Format(SqlConnectStr, CurrentDataBasePath);
                }
                

                return ConnectStr;
            }


        }
        #endregion

        #region ConnectString
        /// <summary>
        /// Access database connection string
        /// </summary>
        private static string ConnectionString
        {
            get
            {
                string ConnectStr;

                    if (DataBaseName.ToLower() != "NoteDataBase.MDB".ToLower())
                    {
                        ConnectStr = string.Format(SqlConnectStr, DataBaseName);
                    }
                    else
                    {
                        ConnectStr = string.Format(SqlConnectStr, AppDomain.CurrentDomain.BaseDirectory + DataBaseName);
                    }
 


                return ConnectStr;
            }


        }
        #endregion


        #region  Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public AccessDatabase()
        {

        }
        /// <summary>
        /// database file name
        /// </summary>
        /// <param name="databaseFileName"></param>
        public AccessDatabase(string databaseFileName)
        {
            this.CurrentDataBasePath = databaseFileName;
 
        }
        #endregion


        /// <summary>
        /// Create a connnection 
        /// </summary>
        /// <returns></returns>
        public static OleDbConnection CreateConnnection()
        {
           
            return new OleDbConnection(ConnectionString);

        }
        /// <summary>
        /// Create a connection
        /// </summary>
        /// <param name="ConnectStr"></param>
        /// <returns></returns>
        public static OleDbConnection CreateConnnection(string ConnectStr)
        {
            return new OleDbConnection(ConnectStr);
        }

        #region ExecuteNonQuery
        /// <summary>
        /// Execute a SQL  statement 
        /// </summary>
        /// <returns>the number of rows affected</returns>
        public int ExecuteNonQuery(string SqlText)
        {
            int rowsEffected = 0;
            using (OleDbConnection OleCon = new OleDbConnection(ConnectString))
            {
                OleDbCommand OleCMD = new OleDbCommand(SqlText, OleCon);
                OleCon.Open();
                rowsEffected = OleCMD.ExecuteNonQuery();
                return rowsEffected;
            }


        }
        #endregion

        #region ExecuteReader
        /// <summary>
        /// Build a DataReader from the certain SqlText
        /// </summary>
        /// <returns>DataReader</returns>
        public OleDbDataReader ExecuteReader(string SqlText)
        {
            OleDbDataReader AccessReader = null;
            using (OleDbConnection OleCon = new OleDbConnection(ConnectString))
            {
                OleDbCommand OleCMD = new OleDbCommand(SqlText, OleCon);
                OleCon.Open();
                AccessReader = OleCMD.ExecuteReader();
                return AccessReader;
            }

        }
        #endregion

        #region ExecuteDataSet
        /// <summary>
        /// Get a Dataset with the sqlText
        /// </summary>
        /// <param name="SqlText">sql Clause</param>
        /// <param name="TableName">TableName</param>
        /// <returns>the dataset  come from the sql clause</returns>
        public DataSet ExecuteDataSet(string SqlText, string TableName)
        {
            DataSet CertainDS = new DataSet();
            using (OleDbConnection OleCon = new OleDbConnection(ConnectString))
            {
                OleDbCommand OleCMD = new OleDbCommand(SqlText, OleCon);
                this.AccessAdapter = new OleDbDataAdapter(OleCMD);
                OleDbCommandBuilder builder = new OleDbCommandBuilder(this.AccessAdapter);
                OleCon.Open();

                OleDbCommand insertcommand = builder.GetInsertCommand();
                OleDbCommand deleteCommand = builder.GetDeleteCommand();
                OleDbCommand updateCommand = builder.GetUpdateCommand();


                this.AccessAdapter.Fill(CertainDS);
                this.AccessAdapter.TableMappings.Add(CertainDS.Tables[0].TableName, TableName);
                CertainDS.Tables[0].TableName = TableName;
                return CertainDS;
            }


        }
        /// <summary>
        /// Get a Dataset with the sqlText
        /// </summary>
        /// <param name="SqlText">sql Clause</param>
        /// <returns>the dataset  come from the sql clause</returns>
        public DataSet ExecuteDataSet(string SqlText)
        {
            DataSet CertainDS = new DataSet();
            using (OleDbConnection OleCon = new OleDbConnection(ConnectString))
            {
                OleCon.Open();
                OleDbCommand OleCMD = new OleDbCommand(SqlText, OleCon);
                this.AccessAdapter = null;
                this.AccessAdapter = new OleDbDataAdapter(OleCMD);
                this.AccessAdapter.Fill(CertainDS);
                //this.AccessAdapter.Dispose();
                return CertainDS;
            }


        }

        #endregion

        #region ExecuteScalar
        /// <summary>
        /// Excute the query 
        /// </summary>
        /// <param name="SqlText">sql Clause</param>
        /// <returns>the first column of first r</returns>
        public object ExecuteScalar(string SqlText)
        {
            object scalarobj = null;
            using (OleDbConnection OleCon = new OleDbConnection(ConnectString))
            {
                OleDbCommand OleCMD = new OleDbCommand(SqlText, OleCon);
                OleCon.Open();
                scalarobj = OleCMD.ExecuteScalar();
                return scalarobj;
            }

        }
        #endregion

        #region UpdateDataSet

        /// <summary>
        /// update teh dataset to Access database
        /// </summary>
        /// <param name="ds">the dataSet produce by ExecuteDataSet</param>
        /// <param name="TableName">the table which will be update</param>
        /// <returns></returns>
        public int UpdateDataSet(DataSet ds, string TableName)
        {
            int affectedrows = 0;
            using (OleDbConnection OleCon = new OleDbConnection(ConnectString))
            {

                
                this.AccessAdapter.SelectCommand.Connection = OleCon;
                this.AccessAdapter.SelectCommand.Connection.Open();
                affectedrows += this.AccessAdapter.Update(ds);
                this.AccessAdapter.SelectCommand.Connection.Close();

            }


            return affectedrows;
        }

        /// <summary>
        ///  update teh dataset to Access database
        /// </summary>
        /// <param name="ds">ds</param>
        /// <returns></returns>
        public int UpdateDataSet(DataSet ds)
        {
            int affectedrows = 0;

            this.AccessAdapter.SelectCommand.Connection.ConnectionString = ConnectString;
            using (this.AccessAdapter.SelectCommand.Connection = new OleDbConnection(ConnectString))
            {
                
                this.AccessAdapter.SelectCommand.Connection.Open();
                affectedrows += this.AccessAdapter.Update(ds);

            }
            this.AccessAdapter.Dispose();
            return affectedrows;
        }
        #endregion


        #region IDisposable Members
        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            this.AccessAdapter.Dispose();
        }

        #endregion
    }
}
