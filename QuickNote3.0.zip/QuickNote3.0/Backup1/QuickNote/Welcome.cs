using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;

namespace GLTc.QuickNote
{
    public partial class Welcome : Form
    {
        #region AssemblyProductName
        public string AssemblyProductName
        {
            get
            {
                // Get all Product attributes on this assembly
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyProductAttribute), false);
                // If there aren't any Product attributes, return an empty string
                if (attributes.Length == 0)
                    return "";
                // If there is a Product attribute, return its value
                return ((AssemblyProductAttribute)attributes[0]).Product;
            }
        }
        #endregion 

        private string ServicePackageVersion
        {
            get
            {
                return QuickNote.Properties.Settings.Default.ServicePackage;
            }
        }

        private static Font TitleFont = new Font("Times New Roman", 24, FontStyle.Bold);
        private static Font SPFont = new Font("Times New Roman", 10, FontStyle.Bold);
        public Welcome()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Draw the rectangle on the welcome picture
        /// </summary>
        /// <param name="g"></param>
        private void DrawRectangleOnPicture(Graphics g)
        {
            Rectangle rct = new Rectangle(new Point(0, 0), new Size(420, 218));
            g.DrawRectangle(Pens.Black, rct);
        }

        private void DrawProductionTile(Graphics g)
        {

            g.DrawString(this.AssemblyProductName, TitleFont,Brushes.Black,new Point(140,128));
            g.DrawString(ServicePackageVersion, SPFont, Brushes.Red, new Point(328,125));
 
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            CleanTitle(e.Graphics);
            DrawRectangleOnPicture(e.Graphics);
            DrawProductionTile(e.Graphics);
        }

        /// <summary>
        /// temp clean the title
        /// </summary>
        /// <param name="g"></param>
        private void CleanTitle(Graphics g)
        {
            Rectangle rct = new Rectangle(new Point(144, 130), new Size(195, 32));
            g.FillRectangle(Brushes.White, rct);
 
        }
   

    }
}