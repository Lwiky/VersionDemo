using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GLTc.QuickNote
{
    /// <summary>
    /// Confirm message box
    /// </summary>
    public partial class ConfirmBox : Form
    {
        /// <summary>
        /// the title of the message box
        /// </summary>
        public string Title
        {
            set { this.Text = value; }
        }



        /// <summary>
        /// the display message  of the message box
        /// </summary>
        public string MessageInfo
        {
            set { this.lbMessage.Text = value; }
        }

            


        public  ConfirmBox()
        {
            InitializeComponent();
            
        }

        /// <summary>
        /// the constructor of the message box
        /// </summary>
        /// <param name="FormTitle">the title string of the message box</param>
        /// <param name="DisplayMessage">the display message</param>
        public ConfirmBox(string FormTitle , string DisplayMessage):this()
        {
           
            this.Title = FormTitle;
            this.MessageInfo = DisplayMessage;
            this.btnConfirm.DialogResult = DialogResult.OK;
            this.btnCancel.DialogResult = DialogResult.Cancel;
 
        }
    }
}