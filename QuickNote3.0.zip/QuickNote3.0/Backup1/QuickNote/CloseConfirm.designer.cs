namespace GLTc.QuickNote
{
    partial class CloseConfirm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TblOCLoseConfirm = new System.Windows.Forms.TableLayoutPanel();
            this.lbDeletePrompt = new System.Windows.Forms.Label();
            this.LBSaveItems = new System.Windows.Forms.ListBox();
            this.tblpButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnYes = new System.Windows.Forms.Button();
            this.btnNo = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.TblOCLoseConfirm.SuspendLayout();
            this.tblpButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // TblOCLoseConfirm
            // 
            this.TblOCLoseConfirm.ColumnCount = 1;
            this.TblOCLoseConfirm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TblOCLoseConfirm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.TblOCLoseConfirm.Controls.Add(this.lbDeletePrompt, 0, 0);
            this.TblOCLoseConfirm.Controls.Add(this.LBSaveItems, 0, 1);
            this.TblOCLoseConfirm.Controls.Add(this.tblpButtons, 0, 2);
            this.TblOCLoseConfirm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TblOCLoseConfirm.Location = new System.Drawing.Point(0, 0);
            this.TblOCLoseConfirm.Name = "TblOCLoseConfirm";
            this.TblOCLoseConfirm.RowCount = 3;
            this.TblOCLoseConfirm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 47F));
            this.TblOCLoseConfirm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 76.53429F));
            this.TblOCLoseConfirm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.4657F));
            this.TblOCLoseConfirm.Size = new System.Drawing.Size(373, 248);
            this.TblOCLoseConfirm.TabIndex = 0;
            // 
            // lbDeletePrompt
            // 
            this.lbDeletePrompt.AutoSize = true;
            this.lbDeletePrompt.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbDeletePrompt.Location = new System.Drawing.Point(3, 34);
            this.lbDeletePrompt.Name = "lbDeletePrompt";
            this.lbDeletePrompt.Size = new System.Drawing.Size(367, 13);
            this.lbDeletePrompt.TabIndex = 0;
            this.lbDeletePrompt.Text = "Save changed  to the following Items?";
            // 
            // LBSaveItems
            // 
            this.LBSaveItems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LBSaveItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBSaveItems.FormattingEnabled = true;
            this.LBSaveItems.ItemHeight = 15;
            this.LBSaveItems.Location = new System.Drawing.Point(3, 50);
            this.LBSaveItems.Name = "LBSaveItems";
            this.LBSaveItems.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.LBSaveItems.Size = new System.Drawing.Size(367, 139);
            this.LBSaveItems.TabIndex = 8;
            // 
            // tblpButtons
            // 
            this.tblpButtons.ColumnCount = 4;
            this.tblpButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tblpButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 82F));
            this.tblpButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.56522F));
            this.tblpButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.43478F));
            this.tblpButtons.Controls.Add(this.btnYes, 1, 0);
            this.tblpButtons.Controls.Add(this.btnNo, 2, 0);
            this.tblpButtons.Controls.Add(this.btnCancel, 3, 0);
            this.tblpButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpButtons.Location = new System.Drawing.Point(3, 203);
            this.tblpButtons.Name = "tblpButtons";
            this.tblpButtons.RowCount = 1;
            this.tblpButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblpButtons.Size = new System.Drawing.Size(367, 42);
            this.tblpButtons.TabIndex = 3;
            // 
            // btnYes
            // 
            this.btnYes.Location = new System.Drawing.Point(104, 3);
            this.btnYes.Name = "btnYes";
            this.btnYes.Size = new System.Drawing.Size(75, 23);
            this.btnYes.TabIndex = 0;
            this.btnYes.Text = "Yes";
            this.btnYes.UseVisualStyleBackColor = true;
            this.btnYes.Click += new System.EventHandler(this.btnYes_Click);
            // 
            // btnNo
            // 
            this.btnNo.Location = new System.Drawing.Point(186, 3);
            this.btnNo.Name = "btnNo";
            this.btnNo.Size = new System.Drawing.Size(75, 23);
            this.btnNo.TabIndex = 1;
            this.btnNo.Text = "No";
            this.btnNo.UseVisualStyleBackColor = true;
            this.btnNo.Click += new System.EventHandler(this.btnNo_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(268, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // CloseConfirm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 248);
            this.Controls.Add(this.TblOCLoseConfirm);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CloseConfirm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "QuickNote";
            this.TopMost = true;
            this.TblOCLoseConfirm.ResumeLayout(false);
            this.TblOCLoseConfirm.PerformLayout();
            this.tblpButtons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel TblOCLoseConfirm;
        private System.Windows.Forms.Label lbDeletePrompt;
        private System.Windows.Forms.ListBox LBSaveItems;
        private System.Windows.Forms.TableLayoutPanel tblpButtons;
        private System.Windows.Forms.Button btnYes;
        private System.Windows.Forms.Button btnNo;
        private System.Windows.Forms.Button btnCancel;
    }
}