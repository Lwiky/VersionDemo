namespace GLTc.QuickNote
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.STSBar = new System.Windows.Forms.StatusStrip();
            this.STSPath = new System.Windows.Forms.ToolStripStatusLabel();
            this.TSSLLine = new System.Windows.Forms.ToolStripStatusLabel();
            this.TSSLLineNum = new System.Windows.Forms.ToolStripStatusLabel();
            this.TSSLColumnNum = new System.Windows.Forms.ToolStripStatusLabel();
            this.TSSBSave = new System.Windows.Forms.ToolStripStatusLabel();
            this.SCMainForm = new System.Windows.Forms.SplitContainer();
            this.TBLeftWindow = new System.Windows.Forms.TabControl();
            this.TPOutline = new System.Windows.Forms.TabPage();
            this.TVOutline = new System.Windows.Forms.TreeView();
            this.ImgLTree = new System.Windows.Forms.ImageList(this.components);
            this.TPIndex = new System.Windows.Forms.TabPage();
            this.IndexTableLayOut = new System.Windows.Forms.TableLayoutPanel();
            this.TPIndexCondition = new System.Windows.Forms.TextBox();
            this.TpIndexTips = new System.Windows.Forms.Label();
            this.TPIndexListBox = new System.Windows.Forms.ListBox();
            this.TPSearch = new System.Windows.Forms.TabPage();
            this.SearchTableLayOut = new System.Windows.Forms.TableLayoutPanel();
            this.TPSearchCondition = new System.Windows.Forms.TextBox();
            this.TPSearchTips = new System.Windows.Forms.Label();
            this.TPSearchListBox = new System.Windows.Forms.ListBox();
            this.LBSearchResultTips = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.TPSearchListbar = new System.Windows.Forms.Button();
            this.MSTopMenu = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMINew = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIClose = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMISave = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMISaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMISaveAll = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIExit = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.findToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.replaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rPGSearchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ViewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DocumentMapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rPGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cLPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dDSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.InsertToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertPictureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.boldToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.italicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.underlineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bulletToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.WordWrapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.standardBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formatingBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutQuickNoteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TbStandbar = new System.Windows.Forms.ToolStrip();
            this.TSBNewPage = new System.Windows.Forms.ToolStripButton();
            this.TSBSave = new System.Windows.Forms.ToolStripButton();
            this.TSBSaveAll = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.STBCut = new System.Windows.Forms.ToolStripButton();
            this.STBCopy = new System.Windows.Forms.ToolStripButton();
            this.STBPaste = new System.Windows.Forms.ToolStripButton();
            this.TSBFormatPainter = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.TSBUndo = new System.Windows.Forms.ToolStripButton();
            this.TSBRedo = new System.Windows.Forms.ToolStripButton();
            this.TSBMap = new System.Windows.Forms.ToolStripButton();
            this.TSCBWidth = new System.Windows.Forms.ToolStripComboBox();
            this.TSFormat = new System.Windows.Forms.ToolStrip();
            this.TSCBFont = new System.Windows.Forms.ToolStripComboBox();
            this.TSCBSize = new System.Windows.Forms.ToolStripComboBox();
            this.TSBBlod = new System.Windows.Forms.ToolStripButton();
            this.TSBItalic = new System.Windows.Forms.ToolStripButton();
            this.TSBUnderline = new System.Windows.Forms.ToolStripButton();
            this.TSBAlignLeft = new System.Windows.Forms.ToolStripButton();
            this.TSBAlignCenter = new System.Windows.Forms.ToolStripButton();
            this.TSBAlignRight = new System.Windows.Forms.ToolStripButton();
            this.TSBBullet = new System.Windows.Forms.ToolStripButton();
            this.TSBDecreaseIndent = new System.Windows.Forms.ToolStripButton();
            this.TSBIncreaseIndent = new System.Windows.Forms.ToolStripButton();
            this.TSSBBackColor = new System.Windows.Forms.ToolStripSplitButton();
            this.TSSBTextColor = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.TSBFunctionToolBar = new System.Windows.Forms.ToolStripButton();
            this.TVSectionContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TSMIAddPage = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIAddFolder = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TSMIExport = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIImport = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.TSMITVCut = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMITVCopy = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMITVPaste = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMITVDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIRename = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.TSMIProperties = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.TVPageContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TSMIPageOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIPageCut = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIPageCopy = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIPageDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIPageRename = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.TSMIPageProperties = new System.Windows.Forms.ToolStripMenuItem();
            this.TBContextContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TSMIContextSave = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIContextRefresh = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIContextClose = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIContextLeaveThis = new System.Windows.Forms.ToolStripMenuItem();
            this.NIQuickNote = new System.Windows.Forms.NotifyIcon(this.components);
            this.NIContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TSMIShowForm = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIExist = new System.Windows.Forms.ToolStripMenuItem();
            this.TSPLNoteIcon = new System.Windows.Forms.ToolStripSeparator();
            this.TSMIHideWhenMinimize = new System.Windows.Forms.ToolStripMenuItem();
            this.RTBContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TSMICut = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMICopy = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIPaste = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TSMISelectALL = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TSMIFont = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIBullet = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIAddIndex = new System.Windows.Forms.ToolStripMenuItem();
            this.ContextFontDialog = new System.Windows.Forms.FontDialog();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.TBContext = new GLTc.QuickNote.CustomControl.CustomTabControl();
            this.TbStart = new System.Windows.Forms.TabPage();
            this.tabelLayoutStartPage = new System.Windows.Forms.TableLayoutPanel();
            this.LbStartPage = new System.Windows.Forms.Label();
            this.LbStartPageSlogan = new System.Windows.Forms.Label();
            this.lbCopyRight = new System.Windows.Forms.Label();
            this.toolStripContainer1.BottomToolStripPanel.SuspendLayout();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.STSBar.SuspendLayout();
            this.SCMainForm.Panel1.SuspendLayout();
            this.SCMainForm.Panel2.SuspendLayout();
            this.SCMainForm.SuspendLayout();
            this.TBLeftWindow.SuspendLayout();
            this.TPOutline.SuspendLayout();
            this.TPIndex.SuspendLayout();
            this.IndexTableLayOut.SuspendLayout();
            this.TPSearch.SuspendLayout();
            this.SearchTableLayOut.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.MSTopMenu.SuspendLayout();
            this.TbStandbar.SuspendLayout();
            this.TSFormat.SuspendLayout();
            this.TVSectionContextMenu.SuspendLayout();
            this.TVPageContextMenu.SuspendLayout();
            this.TBContextContextMenu.SuspendLayout();
            this.NIContextMenu.SuspendLayout();
            this.RTBContextMenu.SuspendLayout();
            this.TBContext.SuspendLayout();
            this.TbStart.SuspendLayout();
            this.tabelLayoutStartPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.BottomToolStripPanel
            // 
            this.toolStripContainer1.BottomToolStripPanel.Controls.Add(this.STSBar);
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.SCMainForm);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(809, 530);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(809, 601);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.MSTopMenu);
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.TbStandbar);
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.TSFormat);
            // 
            // STSBar
            // 
            this.STSBar.Dock = System.Windows.Forms.DockStyle.None;
            this.STSBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.STSPath,
            this.TSSLLine,
            this.TSSLLineNum,
            this.TSSLColumnNum,
            this.TSSBSave});
            this.STSBar.Location = new System.Drawing.Point(0, 0);
            this.STSBar.Name = "STSBar";
            this.STSBar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.STSBar.Size = new System.Drawing.Size(809, 22);
            this.STSBar.TabIndex = 0;
            // 
            // STSPath
            // 
            this.STSPath.Name = "STSPath";
            this.STSPath.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.STSPath.Size = new System.Drawing.Size(38, 17);
            this.STSPath.Text = "Ready";
            this.STSPath.ToolTipText = "QuickNotePath";
            // 
            // TSSLLine
            // 
            this.TSSLLine.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.TSSLLine.Name = "TSSLLine";
            this.TSSLLine.Size = new System.Drawing.Size(0, 17);
            // 
            // TSSLLineNum
            // 
            this.TSSLLineNum.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.TSSLLineNum.Margin = new System.Windows.Forms.Padding(300, 3, 30, 2);
            this.TSSLLineNum.Name = "TSSLLineNum";
            this.TSSLLineNum.Padding = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.TSSLLineNum.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TSSLLineNum.RightToLeftAutoMirrorImage = true;
            this.TSSLLineNum.Size = new System.Drawing.Size(27, 17);
            this.TSSLLineNum.Text = "Line";
            this.TSSLLineNum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TSSLColumnNum
            // 
            this.TSSLColumnNum.Name = "TSSLColumnNum";
            this.TSSLColumnNum.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TSSLColumnNum.RightToLeftAutoMirrorImage = true;
            this.TSSLColumnNum.Size = new System.Drawing.Size(42, 17);
            this.TSSLColumnNum.Text = "Column";
            // 
            // TSSBSave
            // 
            this.TSSBSave.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.TSSBSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSSBSave.Image = global::GLTc.QuickNote.Properties.Resources.Save;
            this.TSSBSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSSBSave.Margin = new System.Windows.Forms.Padding(50, 3, 0, 2);
            this.TSSBSave.MergeAction = System.Windows.Forms.MergeAction.Insert;
            this.TSSBSave.Name = "TSSBSave";
            this.TSSBSave.Size = new System.Drawing.Size(16, 17);
            this.TSSBSave.Text = "Saving";
            this.TSSBSave.Visible = false;
            // 
            // SCMainForm
            // 
            this.SCMainForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SCMainForm.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.SCMainForm.Location = new System.Drawing.Point(0, 0);
            this.SCMainForm.Name = "SCMainForm";
            // 
            // SCMainForm.Panel1
            // 
            this.SCMainForm.Panel1.Controls.Add(this.TBLeftWindow);
            this.SCMainForm.Panel1MinSize = 0;
            // 
            // SCMainForm.Panel2
            // 
            this.SCMainForm.Panel2.Controls.Add(this.TBContext);
            this.SCMainForm.Size = new System.Drawing.Size(809, 530);
            this.SCMainForm.SplitterDistance = 209;
            this.SCMainForm.SplitterWidth = 2;
            this.SCMainForm.TabIndex = 0;
            // 
            // TBLeftWindow
            // 
            this.TBLeftWindow.Controls.Add(this.TPOutline);
            this.TBLeftWindow.Controls.Add(this.TPIndex);
            this.TBLeftWindow.Controls.Add(this.TPSearch);
            this.TBLeftWindow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TBLeftWindow.Location = new System.Drawing.Point(0, 0);
            this.TBLeftWindow.Name = "TBLeftWindow";
            this.TBLeftWindow.SelectedIndex = 0;
            this.TBLeftWindow.Size = new System.Drawing.Size(209, 530);
            this.TBLeftWindow.TabIndex = 0;
            // 
            // TPOutline
            // 
            this.TPOutline.Controls.Add(this.TVOutline);
            this.TPOutline.Location = new System.Drawing.Point(4, 22);
            this.TPOutline.Name = "TPOutline";
            this.TPOutline.Padding = new System.Windows.Forms.Padding(3);
            this.TPOutline.Size = new System.Drawing.Size(201, 504);
            this.TPOutline.TabIndex = 0;
            this.TPOutline.Text = "Outline";
            this.TPOutline.UseVisualStyleBackColor = true;
            // 
            // TVOutline
            // 
            this.TVOutline.AllowDrop = true;
            this.TVOutline.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVOutline.HideSelection = false;
            this.TVOutline.ImageIndex = 0;
            this.TVOutline.ImageList = this.ImgLTree;
            this.TVOutline.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.TVOutline.ItemHeight = 17;
            this.TVOutline.LabelEdit = true;
            this.TVOutline.Location = new System.Drawing.Point(3, 3);
            this.TVOutline.Name = "TVOutline";
            this.TVOutline.SelectedImageIndex = 0;
            this.TVOutline.ShowNodeToolTips = true;
            this.TVOutline.Size = new System.Drawing.Size(195, 498);
            this.TVOutline.TabIndex = 0;
            this.TVOutline.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVOutline_MouseDoubleClick);
            this.TVOutline.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.TVOutline_AfterLabelEdit);
            this.TVOutline.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.TVOutline_AfterSelect);
            this.TVOutline.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.TVOutline_NodeMouseClick);
            this.TVOutline.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TVOutline_KeyDown);
            // 
            // ImgLTree
            // 
            this.ImgLTree.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImgLTree.ImageStream")));
            this.ImgLTree.TransparentColor = System.Drawing.Color.Magenta;
            this.ImgLTree.Images.SetKeyName(0, "QuickNoteClose");
            this.ImgLTree.Images.SetKeyName(1, "QuickNoteOpen");
            this.ImgLTree.Images.SetKeyName(2, "FloderClose");
            this.ImgLTree.Images.SetKeyName(3, "FolderOpen");
            this.ImgLTree.Images.SetKeyName(4, "Page");
            this.ImgLTree.Images.SetKeyName(5, "QuickNoteCloseCut");
            this.ImgLTree.Images.SetKeyName(6, "QuickNoteOpenCut");
            this.ImgLTree.Images.SetKeyName(7, "FolderCloseCut");
            this.ImgLTree.Images.SetKeyName(8, "FolderOpenCut");
            this.ImgLTree.Images.SetKeyName(9, "PageCut");
            // 
            // TPIndex
            // 
            this.TPIndex.Controls.Add(this.IndexTableLayOut);
            this.TPIndex.Location = new System.Drawing.Point(4, 22);
            this.TPIndex.Name = "TPIndex";
            this.TPIndex.Padding = new System.Windows.Forms.Padding(3);
            this.TPIndex.Size = new System.Drawing.Size(201, 504);
            this.TPIndex.TabIndex = 1;
            this.TPIndex.Text = "Index";
            this.TPIndex.UseVisualStyleBackColor = true;
            // 
            // IndexTableLayOut
            // 
            this.IndexTableLayOut.ColumnCount = 1;
            this.IndexTableLayOut.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.IndexTableLayOut.Controls.Add(this.TPIndexCondition, 0, 1);
            this.IndexTableLayOut.Controls.Add(this.TpIndexTips, 0, 0);
            this.IndexTableLayOut.Controls.Add(this.TPIndexListBox, 0, 2);
            this.IndexTableLayOut.Dock = System.Windows.Forms.DockStyle.Fill;
            this.IndexTableLayOut.Location = new System.Drawing.Point(3, 3);
            this.IndexTableLayOut.Name = "IndexTableLayOut";
            this.IndexTableLayOut.RowCount = 3;
            this.IndexTableLayOut.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.IndexTableLayOut.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.IndexTableLayOut.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.IndexTableLayOut.Size = new System.Drawing.Size(195, 498);
            this.IndexTableLayOut.TabIndex = 1;
            // 
            // TPIndexCondition
            // 
            this.TPIndexCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TPIndexCondition.Location = new System.Drawing.Point(3, 18);
            this.TPIndexCondition.Name = "TPIndexCondition";
            this.TPIndexCondition.Size = new System.Drawing.Size(189, 20);
            this.TPIndexCondition.TabIndex = 1;
            this.TPIndexCondition.TextChanged += new System.EventHandler(this.TPIndexCondition_TextChanged);
            // 
            // TpIndexTips
            // 
            this.TpIndexTips.AutoSize = true;
            this.TpIndexTips.BackColor = System.Drawing.Color.Silver;
            this.TpIndexTips.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TpIndexTips.Location = new System.Drawing.Point(3, 0);
            this.TpIndexTips.Name = "TpIndexTips";
            this.TpIndexTips.Size = new System.Drawing.Size(189, 15);
            this.TpIndexTips.TabIndex = 0;
            this.TpIndexTips.Text = "Type in  key word to find";
            // 
            // TPIndexListBox
            // 
            this.TPIndexListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TPIndexListBox.FormattingEnabled = true;
            this.TPIndexListBox.Location = new System.Drawing.Point(3, 48);
            this.TPIndexListBox.Name = "TPIndexListBox";
            this.TPIndexListBox.Size = new System.Drawing.Size(189, 446);
            this.TPIndexListBox.TabIndex = 2;
            // 
            // TPSearch
            // 
            this.TPSearch.Controls.Add(this.SearchTableLayOut);
            this.TPSearch.Location = new System.Drawing.Point(4, 22);
            this.TPSearch.Name = "TPSearch";
            this.TPSearch.Size = new System.Drawing.Size(201, 504);
            this.TPSearch.TabIndex = 2;
            this.TPSearch.Text = "Search";
            this.TPSearch.UseVisualStyleBackColor = true;
            // 
            // SearchTableLayOut
            // 
            this.SearchTableLayOut.ColumnCount = 1;
            this.SearchTableLayOut.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.SearchTableLayOut.Controls.Add(this.TPSearchCondition, 0, 1);
            this.SearchTableLayOut.Controls.Add(this.TPSearchTips, 0, 0);
            this.SearchTableLayOut.Controls.Add(this.TPSearchListBox, 0, 4);
            this.SearchTableLayOut.Controls.Add(this.LBSearchResultTips, 0, 3);
            this.SearchTableLayOut.Controls.Add(this.tableLayoutPanel1, 0, 2);
            this.SearchTableLayOut.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SearchTableLayOut.Location = new System.Drawing.Point(0, 0);
            this.SearchTableLayOut.Name = "SearchTableLayOut";
            this.SearchTableLayOut.RowCount = 5;
            this.SearchTableLayOut.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.SearchTableLayOut.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.SearchTableLayOut.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.SearchTableLayOut.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.SearchTableLayOut.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.SearchTableLayOut.Size = new System.Drawing.Size(201, 504);
            this.SearchTableLayOut.TabIndex = 0;
            // 
            // TPSearchCondition
            // 
            this.TPSearchCondition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TPSearchCondition.Location = new System.Drawing.Point(3, 18);
            this.TPSearchCondition.Name = "TPSearchCondition";
            this.TPSearchCondition.Size = new System.Drawing.Size(195, 20);
            this.TPSearchCondition.TabIndex = 0;
            this.TPSearchCondition.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TPSearchCondition_KeyDown);
            // 
            // TPSearchTips
            // 
            this.TPSearchTips.AutoSize = true;
            this.TPSearchTips.BackColor = System.Drawing.Color.Silver;
            this.TPSearchTips.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TPSearchTips.Location = new System.Drawing.Point(3, 0);
            this.TPSearchTips.Name = "TPSearchTips";
            this.TPSearchTips.Size = new System.Drawing.Size(195, 15);
            this.TPSearchTips.TabIndex = 1;
            this.TPSearchTips.Text = "Type in  key word to find";
            // 
            // TPSearchListBox
            // 
            this.TPSearchListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TPSearchListBox.FormattingEnabled = true;
            this.TPSearchListBox.Location = new System.Drawing.Point(3, 103);
            this.TPSearchListBox.Name = "TPSearchListBox";
            this.TPSearchListBox.Size = new System.Drawing.Size(195, 394);
            this.TPSearchListBox.TabIndex = 3;
            // 
            // LBSearchResultTips
            // 
            this.LBSearchResultTips.AutoSize = true;
            this.LBSearchResultTips.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.LBSearchResultTips.Location = new System.Drawing.Point(3, 87);
            this.LBSearchResultTips.Name = "LBSearchResultTips";
            this.LBSearchResultTips.Size = new System.Drawing.Size(195, 13);
            this.LBSearchResultTips.TabIndex = 4;
            this.LBSearchResultTips.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.74627F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.25373F));
            this.tableLayoutPanel1.Controls.Add(this.TPSearchListbar, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 50);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(201, 30);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // TPSearchListbar
            // 
            this.TPSearchListbar.Dock = System.Windows.Forms.DockStyle.Right;
            this.TPSearchListbar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TPSearchListbar.Location = new System.Drawing.Point(123, 3);
            this.TPSearchListbar.Name = "TPSearchListbar";
            this.TPSearchListbar.Size = new System.Drawing.Size(75, 24);
            this.TPSearchListbar.TabIndex = 4;
            this.TPSearchListbar.Text = "List Topics";
            this.TPSearchListbar.UseVisualStyleBackColor = true;
            this.TPSearchListbar.Click += new System.EventHandler(this.TPSearchListbar_Click);
            // 
            // MSTopMenu
            // 
            this.MSTopMenu.Dock = System.Windows.Forms.DockStyle.None;
            this.MSTopMenu.GripMargin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.MSTopMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.ViewToolStripMenuItem,
            this.InsertToolStripMenuItem,
            this.formatToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.MSTopMenu.Location = new System.Drawing.Point(0, 0);
            this.MSTopMenu.Name = "MSTopMenu";
            this.MSTopMenu.ShowItemToolTips = true;
            this.MSTopMenu.Size = new System.Drawing.Size(809, 24);
            this.MSTopMenu.TabIndex = 0;
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMINew,
            this.TSMIOpen,
            this.TSMIClose,
            this.TSMISave,
            this.TSMISaveAs,
            this.TSMISaveAll,
            this.TSMIExit});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // TSMINew
            // 
            this.TSMINew.Image = global::GLTc.QuickNote.Properties.Resources.New;
            this.TSMINew.Name = "TSMINew";
            this.TSMINew.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.TSMINew.Size = new System.Drawing.Size(203, 22);
            this.TSMINew.Text = "&New Page";
            this.TSMINew.Click += new System.EventHandler(this.TSMINew_Click);
            // 
            // TSMIOpen
            // 
            this.TSMIOpen.Image = global::GLTc.QuickNote.Properties.Resources.Open;
            this.TSMIOpen.Name = "TSMIOpen";
            this.TSMIOpen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.TSMIOpen.Size = new System.Drawing.Size(203, 22);
            this.TSMIOpen.Text = "&Open ";
            this.TSMIOpen.Click += new System.EventHandler(this.TSMIOpen_Click);
            // 
            // TSMIClose
            // 
            this.TSMIClose.Name = "TSMIClose";
            this.TSMIClose.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.W)));
            this.TSMIClose.Size = new System.Drawing.Size(203, 22);
            this.TSMIClose.Text = "&Close";
            this.TSMIClose.Click += new System.EventHandler(this.TSMIClose_Click);
            // 
            // TSMISave
            // 
            this.TSMISave.Image = global::GLTc.QuickNote.Properties.Resources.Save;
            this.TSMISave.Name = "TSMISave";
            this.TSMISave.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.TSMISave.Size = new System.Drawing.Size(203, 22);
            this.TSMISave.Text = "&Save Current Page";
            this.TSMISave.Click += new System.EventHandler(this.TSMISave_Click);
            // 
            // TSMISaveAs
            // 
            this.TSMISaveAs.Name = "TSMISaveAs";
            this.TSMISaveAs.Size = new System.Drawing.Size(203, 22);
            this.TSMISaveAs.Text = "S&ave Current Page As";
            this.TSMISaveAs.Click += new System.EventHandler(this.TSMISaveAs_Click);
            // 
            // TSMISaveAll
            // 
            this.TSMISaveAll.Image = global::GLTc.QuickNote.Properties.Resources.SaveAll;
            this.TSMISaveAll.Name = "TSMISaveAll";
            this.TSMISaveAll.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.S)));
            this.TSMISaveAll.Size = new System.Drawing.Size(203, 22);
            this.TSMISaveAll.Text = "Save All";
            this.TSMISaveAll.Click += new System.EventHandler(this.TSMISaveAll_Click);
            // 
            // TSMIExit
            // 
            this.TSMIExit.Name = "TSMIExit";
            this.TSMIExit.Size = new System.Drawing.Size(203, 22);
            this.TSMIExit.Text = "&Exit";
            this.TSMIExit.Click += new System.EventHandler(this.TSMIExit_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem,
            this.redoToolStripMenuItem,
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.findToolStripMenuItem,
            this.replaceToolStripMenuItem,
            this.rPGSearchToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.editToolStripMenuItem.Text = "&Edit";
            // 
            // undoToolStripMenuItem
            // 
            this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            this.undoToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.undoToolStripMenuItem.Text = "&Undo";
            this.undoToolStripMenuItem.Click += new System.EventHandler(this.undoToolStripMenuItem_Click);
            // 
            // redoToolStripMenuItem
            // 
            this.redoToolStripMenuItem.Name = "redoToolStripMenuItem";
            this.redoToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.redoToolStripMenuItem.Text = "&Redo";
            this.redoToolStripMenuItem.Click += new System.EventHandler(this.redoToolStripMenuItem_Click);
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.cutToolStripMenuItem.Text = "&Cut";
            this.cutToolStripMenuItem.Click += new System.EventHandler(this.cutToolStripMenuItem_Click);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.copyToolStripMenuItem.Text = "&Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.pasteToolStripMenuItem.Text = "&Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.pasteToolStripMenuItem_Click);
            // 
            // findToolStripMenuItem
            // 
            this.findToolStripMenuItem.Image = global::GLTc.QuickNote.Properties.Resources.Find;
            this.findToolStripMenuItem.Name = "findToolStripMenuItem";
            this.findToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.findToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.findToolStripMenuItem.Text = "&Find";
            this.findToolStripMenuItem.Click += new System.EventHandler(this.findToolStripMenuItem_Click);
            // 
            // replaceToolStripMenuItem
            // 
            this.replaceToolStripMenuItem.Name = "replaceToolStripMenuItem";
            this.replaceToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.replaceToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.replaceToolStripMenuItem.Text = "Replace";
            this.replaceToolStripMenuItem.Click += new System.EventHandler(this.replaceToolStripMenuItem_Click);
            // 
            // rPGSearchToolStripMenuItem
            // 
            this.rPGSearchToolStripMenuItem.Enabled = false;
            this.rPGSearchToolStripMenuItem.Name = "rPGSearchToolStripMenuItem";
            this.rPGSearchToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F10;
            this.rPGSearchToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.rPGSearchToolStripMenuItem.Text = "RPG Search";
            this.rPGSearchToolStripMenuItem.Click += new System.EventHandler(this.rPGSearchToolStripMenuItem_Click);
            // 
            // ViewToolStripMenuItem
            // 
            this.ViewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DocumentMapToolStripMenuItem,
            this.viewAsToolStripMenuItem});
            this.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem";
            this.ViewToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.ViewToolStripMenuItem.Text = "&View";
            // 
            // DocumentMapToolStripMenuItem
            // 
            this.DocumentMapToolStripMenuItem.Image = global::GLTc.QuickNote.Properties.Resources.Map;
            this.DocumentMapToolStripMenuItem.Name = "DocumentMapToolStripMenuItem";
            this.DocumentMapToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.DocumentMapToolStripMenuItem.Text = "&Document Map";
            this.DocumentMapToolStripMenuItem.Click += new System.EventHandler(this.DocumentMapToolStripMenuItem_Click);
            // 
            // viewAsToolStripMenuItem
            // 
            this.viewAsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rPGToolStripMenuItem,
            this.cLPToolStripMenuItem,
            this.dDSToolStripMenuItem});
            this.viewAsToolStripMenuItem.Name = "viewAsToolStripMenuItem";
            this.viewAsToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.viewAsToolStripMenuItem.Text = "View &As";
            // 
            // rPGToolStripMenuItem
            // 
            this.rPGToolStripMenuItem.Name = "rPGToolStripMenuItem";
            this.rPGToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.rPGToolStripMenuItem.Text = "RPG";
            this.rPGToolStripMenuItem.Click += new System.EventHandler(this.rPGToolStripMenuItem_Click);
            // 
            // cLPToolStripMenuItem
            // 
            this.cLPToolStripMenuItem.Name = "cLPToolStripMenuItem";
            this.cLPToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.cLPToolStripMenuItem.Text = "CLP";
            this.cLPToolStripMenuItem.Click += new System.EventHandler(this.cLPToolStripMenuItem_Click);
            // 
            // dDSToolStripMenuItem
            // 
            this.dDSToolStripMenuItem.Name = "dDSToolStripMenuItem";
            this.dDSToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.dDSToolStripMenuItem.Text = "DDS";
            this.dDSToolStripMenuItem.Click += new System.EventHandler(this.dDSToolStripMenuItem_Click);
            // 
            // InsertToolStripMenuItem
            // 
            this.InsertToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.insertPictureToolStripMenuItem});
            this.InsertToolStripMenuItem.Name = "InsertToolStripMenuItem";
            this.InsertToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.InsertToolStripMenuItem.Text = "&Insert";
            // 
            // insertPictureToolStripMenuItem
            // 
            this.insertPictureToolStripMenuItem.Name = "insertPictureToolStripMenuItem";
            this.insertPictureToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.insertPictureToolStripMenuItem.Text = "&Picture";
            this.insertPictureToolStripMenuItem.Click += new System.EventHandler(this.insertPictureToolStripMenuItem_Click);
            // 
            // formatToolStripMenuItem
            // 
            this.formatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fontToolStripMenuItem,
            this.boldToolStripMenuItem,
            this.italicToolStripMenuItem,
            this.underlineToolStripMenuItem,
            this.bulletToolStripMenuItem,
            this.selectAllToolStripMenuItem,
            this.WordWrapToolStripMenuItem});
            this.formatToolStripMenuItem.Name = "formatToolStripMenuItem";
            this.formatToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.formatToolStripMenuItem.Text = "F&ormat";
            this.formatToolStripMenuItem.DropDownOpening += new System.EventHandler(this.formatToolStripMenuItem_DropDownOpening);
            // 
            // fontToolStripMenuItem
            // 
            this.fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            this.fontToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.fontToolStripMenuItem.Text = "&Font";
            // 
            // boldToolStripMenuItem
            // 
            this.boldToolStripMenuItem.Name = "boldToolStripMenuItem";
            this.boldToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.boldToolStripMenuItem.Text = "&Bold";
            // 
            // italicToolStripMenuItem
            // 
            this.italicToolStripMenuItem.Name = "italicToolStripMenuItem";
            this.italicToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.italicToolStripMenuItem.Text = "&Italic";
            // 
            // underlineToolStripMenuItem
            // 
            this.underlineToolStripMenuItem.Name = "underlineToolStripMenuItem";
            this.underlineToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.underlineToolStripMenuItem.Text = "&Underline";
            // 
            // bulletToolStripMenuItem
            // 
            this.bulletToolStripMenuItem.Name = "bulletToolStripMenuItem";
            this.bulletToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.bulletToolStripMenuItem.Text = "&bullet";
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.selectAllToolStripMenuItem.Text = "&Select All";
            this.selectAllToolStripMenuItem.Click += new System.EventHandler(this.selectAllToolStripMenuItem_Click);
            // 
            // WordWrapToolStripMenuItem
            // 
            this.WordWrapToolStripMenuItem.Checked = true;
            this.WordWrapToolStripMenuItem.CheckOnClick = true;
            this.WordWrapToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.WordWrapToolStripMenuItem.Name = "WordWrapToolStripMenuItem";
            this.WordWrapToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.WordWrapToolStripMenuItem.Text = "WordWrap";
            this.WordWrapToolStripMenuItem.Click += new System.EventHandler(this.WordWrapToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.standardBarToolStripMenuItem,
            this.formatingBarToolStripMenuItem,
            this.statusBarToolStripMenuItem,
            this.optionsToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.toolsToolStripMenuItem.Text = "&Tools";
            // 
            // standardBarToolStripMenuItem
            // 
            this.standardBarToolStripMenuItem.Checked = true;
            this.standardBarToolStripMenuItem.CheckOnClick = true;
            this.standardBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.standardBarToolStripMenuItem.Name = "standardBarToolStripMenuItem";
            this.standardBarToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.standardBarToolStripMenuItem.Text = "&Standard  Bar";
            this.standardBarToolStripMenuItem.Click += new System.EventHandler(this.standardBarToolStripMenuItem_Click);
            // 
            // formatingBarToolStripMenuItem
            // 
            this.formatingBarToolStripMenuItem.Checked = true;
            this.formatingBarToolStripMenuItem.CheckOnClick = true;
            this.formatingBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.formatingBarToolStripMenuItem.Name = "formatingBarToolStripMenuItem";
            this.formatingBarToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.formatingBarToolStripMenuItem.Text = "&Formating Bar";
            this.formatingBarToolStripMenuItem.Click += new System.EventHandler(this.formatingBarToolStripMenuItem_Click);
            // 
            // statusBarToolStripMenuItem
            // 
            this.statusBarToolStripMenuItem.Checked = true;
            this.statusBarToolStripMenuItem.CheckOnClick = true;
            this.statusBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.statusBarToolStripMenuItem.Name = "statusBarToolStripMenuItem";
            this.statusBarToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.statusBarToolStripMenuItem.Text = "&Status Bar";
            this.statusBarToolStripMenuItem.Click += new System.EventHandler(this.statusBarToolStripMenuItem_Click);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.optionsToolStripMenuItem.Text = "Options";
            this.optionsToolStripMenuItem.Click += new System.EventHandler(this.optionsToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutQuickNoteToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutQuickNoteToolStripMenuItem
            // 
            this.aboutQuickNoteToolStripMenuItem.Name = "aboutQuickNoteToolStripMenuItem";
            this.aboutQuickNoteToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.aboutQuickNoteToolStripMenuItem.Text = "&About QuickNote";
            this.aboutQuickNoteToolStripMenuItem.Click += new System.EventHandler(this.aboutQuickNoteToolStripMenuItem_Click);
            // 
            // TbStandbar
            // 
            this.TbStandbar.Dock = System.Windows.Forms.DockStyle.None;
            this.TbStandbar.GripMargin = new System.Windows.Forms.Padding(0, 2, 2, 2);
            this.TbStandbar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSBNewPage,
            this.TSBSave,
            this.TSBSaveAll,
            this.toolStripSeparator,
            this.STBCut,
            this.STBCopy,
            this.STBPaste,
            this.TSBFormatPainter,
            this.toolStripSeparator4,
            this.TSBUndo,
            this.TSBRedo,
            this.TSBMap,
            this.TSCBWidth});
            this.TbStandbar.Location = new System.Drawing.Point(3, 24);
            this.TbStandbar.Name = "TbStandbar";
            this.TbStandbar.Size = new System.Drawing.Size(324, 25);
            this.TbStandbar.TabIndex = 1;
            // 
            // TSBNewPage
            // 
            this.TSBNewPage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBNewPage.Image = global::GLTc.QuickNote.Properties.Resources.New;
            this.TSBNewPage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBNewPage.Name = "TSBNewPage";
            this.TSBNewPage.Size = new System.Drawing.Size(23, 22);
            this.TSBNewPage.Text = "&New";
            // 
            // TSBSave
            // 
            this.TSBSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBSave.Image = ((System.Drawing.Image)(resources.GetObject("TSBSave.Image")));
            this.TSBSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBSave.Name = "TSBSave";
            this.TSBSave.Size = new System.Drawing.Size(23, 22);
            this.TSBSave.Text = "&Save(Ctrl+S)";
            this.TSBSave.Click += new System.EventHandler(this.TSMISave_Click);
            // 
            // TSBSaveAll
            // 
            this.TSBSaveAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBSaveAll.Image = global::GLTc.QuickNote.Properties.Resources.SaveAll;
            this.TSBSaveAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBSaveAll.Name = "TSBSaveAll";
            this.TSBSaveAll.Size = new System.Drawing.Size(23, 22);
            this.TSBSaveAll.Text = "&Save ALL(Ctrl+Shift+S)";
            this.TSBSaveAll.Click += new System.EventHandler(this.TSMISaveAll_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // STBCut
            // 
            this.STBCut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.STBCut.Image = ((System.Drawing.Image)(resources.GetObject("STBCut.Image")));
            this.STBCut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.STBCut.Name = "STBCut";
            this.STBCut.Size = new System.Drawing.Size(23, 22);
            this.STBCut.Text = "C&ut (Ctrl+X)";
            // 
            // STBCopy
            // 
            this.STBCopy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.STBCopy.Image = ((System.Drawing.Image)(resources.GetObject("STBCopy.Image")));
            this.STBCopy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.STBCopy.Name = "STBCopy";
            this.STBCopy.Size = new System.Drawing.Size(23, 22);
            this.STBCopy.Text = "&Copy(Ctrl+C)";
            // 
            // STBPaste
            // 
            this.STBPaste.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.STBPaste.Image = ((System.Drawing.Image)(resources.GetObject("STBPaste.Image")));
            this.STBPaste.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.STBPaste.Name = "STBPaste";
            this.STBPaste.Size = new System.Drawing.Size(23, 22);
            this.STBPaste.Text = "&Paste(Ctrl+V)";
            // 
            // TSBFormatPainter
            // 
            this.TSBFormatPainter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBFormatPainter.Image = global::GLTc.QuickNote.Properties.Resources.FormatPrinter;
            this.TSBFormatPainter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBFormatPainter.Name = "TSBFormatPainter";
            this.TSBFormatPainter.Size = new System.Drawing.Size(23, 22);
            this.TSBFormatPainter.Text = "Format  painter";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // TSBUndo
            // 
            this.TSBUndo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBUndo.Image = global::GLTc.QuickNote.Properties.Resources.Undo;
            this.TSBUndo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBUndo.Name = "TSBUndo";
            this.TSBUndo.Size = new System.Drawing.Size(23, 22);
            this.TSBUndo.Text = "Undo";
            // 
            // TSBRedo
            // 
            this.TSBRedo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBRedo.Image = global::GLTc.QuickNote.Properties.Resources.Redo;
            this.TSBRedo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBRedo.Name = "TSBRedo";
            this.TSBRedo.Size = new System.Drawing.Size(23, 22);
            this.TSBRedo.Text = "Redo";
            // 
            // TSBMap
            // 
            this.TSBMap.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBMap.Image = global::GLTc.QuickNote.Properties.Resources.Map;
            this.TSBMap.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBMap.Name = "TSBMap";
            this.TSBMap.Size = new System.Drawing.Size(23, 22);
            this.TSBMap.Text = "Outline";
            // 
            // TSCBWidth
            // 
            this.TSCBWidth.AutoSize = false;
            this.TSCBWidth.Name = "TSCBWidth";
            this.TSCBWidth.Size = new System.Drawing.Size(70, 21);
            this.TSCBWidth.Text = "100%";
            // 
            // TSFormat
            // 
            this.TSFormat.Dock = System.Windows.Forms.DockStyle.None;
            this.TSFormat.GripMargin = new System.Windows.Forms.Padding(0, 2, 2, 2);
            this.TSFormat.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSCBFont,
            this.TSCBSize,
            this.TSBBlod,
            this.TSBItalic,
            this.TSBUnderline,
            this.TSBAlignLeft,
            this.TSBAlignCenter,
            this.TSBAlignRight,
            this.TSBBullet,
            this.TSBDecreaseIndent,
            this.TSBIncreaseIndent,
            this.TSSBBackColor,
            this.TSSBTextColor,
            this.toolStripSeparator8,
            this.TSBFunctionToolBar});
            this.TSFormat.Location = new System.Drawing.Point(327, 24);
            this.TSFormat.Name = "TSFormat";
            this.TSFormat.Size = new System.Drawing.Size(474, 25);
            this.TSFormat.TabIndex = 2;
            // 
            // TSCBFont
            // 
            this.TSCBFont.DropDownWidth = 100;
            this.TSCBFont.Name = "TSCBFont";
            this.TSCBFont.Size = new System.Drawing.Size(120, 25);
            // 
            // TSCBSize
            // 
            this.TSCBSize.AutoSize = false;
            this.TSCBSize.Name = "TSCBSize";
            this.TSCBSize.Size = new System.Drawing.Size(40, 21);
            // 
            // TSBBlod
            // 
            this.TSBBlod.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBBlod.Image = global::GLTc.QuickNote.Properties.Resources.Blod;
            this.TSBBlod.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBBlod.Name = "TSBBlod";
            this.TSBBlod.Size = new System.Drawing.Size(23, 22);
            this.TSBBlod.Text = "Blod";
            // 
            // TSBItalic
            // 
            this.TSBItalic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBItalic.Image = global::GLTc.QuickNote.Properties.Resources.Italic;
            this.TSBItalic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBItalic.Name = "TSBItalic";
            this.TSBItalic.Size = new System.Drawing.Size(23, 22);
            this.TSBItalic.Text = "Italic";
            // 
            // TSBUnderline
            // 
            this.TSBUnderline.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBUnderline.Image = global::GLTc.QuickNote.Properties.Resources.Underline;
            this.TSBUnderline.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBUnderline.Name = "TSBUnderline";
            this.TSBUnderline.Size = new System.Drawing.Size(23, 22);
            this.TSBUnderline.Text = "Underline";
            // 
            // TSBAlignLeft
            // 
            this.TSBAlignLeft.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBAlignLeft.Image = global::GLTc.QuickNote.Properties.Resources.AlignLeft;
            this.TSBAlignLeft.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBAlignLeft.Name = "TSBAlignLeft";
            this.TSBAlignLeft.Size = new System.Drawing.Size(23, 22);
            this.TSBAlignLeft.Text = "Left";
            // 
            // TSBAlignCenter
            // 
            this.TSBAlignCenter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBAlignCenter.Image = global::GLTc.QuickNote.Properties.Resources.AlsignCenter;
            this.TSBAlignCenter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBAlignCenter.Name = "TSBAlignCenter";
            this.TSBAlignCenter.Size = new System.Drawing.Size(23, 22);
            this.TSBAlignCenter.Text = "Center";
            // 
            // TSBAlignRight
            // 
            this.TSBAlignRight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBAlignRight.Image = global::GLTc.QuickNote.Properties.Resources.AlignRight;
            this.TSBAlignRight.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBAlignRight.Name = "TSBAlignRight";
            this.TSBAlignRight.Size = new System.Drawing.Size(23, 22);
            this.TSBAlignRight.Text = "Right";
            // 
            // TSBBullet
            // 
            this.TSBBullet.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBBullet.Image = global::GLTc.QuickNote.Properties.Resources.Bullet;
            this.TSBBullet.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBBullet.Name = "TSBBullet";
            this.TSBBullet.Size = new System.Drawing.Size(23, 22);
            this.TSBBullet.Text = "bullet";
            // 
            // TSBDecreaseIndent
            // 
            this.TSBDecreaseIndent.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBDecreaseIndent.Image = global::GLTc.QuickNote.Properties.Resources.DecreaseIndent;
            this.TSBDecreaseIndent.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBDecreaseIndent.Name = "TSBDecreaseIndent";
            this.TSBDecreaseIndent.Size = new System.Drawing.Size(23, 22);
            this.TSBDecreaseIndent.Text = "Decrease Indent";
            // 
            // TSBIncreaseIndent
            // 
            this.TSBIncreaseIndent.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBIncreaseIndent.Image = global::GLTc.QuickNote.Properties.Resources.IncreaseIndent;
            this.TSBIncreaseIndent.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBIncreaseIndent.Name = "TSBIncreaseIndent";
            this.TSBIncreaseIndent.Size = new System.Drawing.Size(23, 22);
            this.TSBIncreaseIndent.Text = "Increase Indent";
            // 
            // TSSBBackColor
            // 
            this.TSSBBackColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSSBBackColor.Image = global::GLTc.QuickNote.Properties.Resources.TextBackColor;
            this.TSSBBackColor.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.TSSBBackColor.Name = "TSSBBackColor";
            this.TSSBBackColor.Size = new System.Drawing.Size(32, 22);
            this.TSSBBackColor.Text = "HighLight";
            // 
            // TSSBTextColor
            // 
            this.TSSBTextColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSSBTextColor.Image = global::GLTc.QuickNote.Properties.Resources.TextColor;
            this.TSSBTextColor.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.TSSBTextColor.Name = "TSSBTextColor";
            this.TSSBTextColor.Size = new System.Drawing.Size(32, 22);
            this.TSSBTextColor.Text = "Color";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // TSBFunctionToolBar
            // 
            this.TSBFunctionToolBar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TSBFunctionToolBar.Image = global::GLTc.QuickNote.Properties.Resources.ToolBox;
            this.TSBFunctionToolBar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBFunctionToolBar.Name = "TSBFunctionToolBar";
            this.TSBFunctionToolBar.Size = new System.Drawing.Size(23, 22);
            this.TSBFunctionToolBar.Text = "Function Bar";
            this.TSBFunctionToolBar.ToolTipText = "Function bar";
            // 
            // TVSectionContextMenu
            // 
            this.TVSectionContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMIAddPage,
            this.TSMIAddFolder,
            this.toolStripSeparator1,
            this.TSMIExport,
            this.TSMIImport,
            this.toolStripSeparator5,
            this.TSMITVCut,
            this.TSMITVCopy,
            this.TSMITVPaste,
            this.TSMITVDelete,
            this.TSMIRename,
            this.toolStripSeparator6,
            this.TSMIProperties});
            this.TVSectionContextMenu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.TVSectionContextMenu.Name = "TVSectionContextMenu";
            this.TVSectionContextMenu.Size = new System.Drawing.Size(129, 242);
            this.TVSectionContextMenu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.TVSectionContextMenu_ItemClicked);
            this.TVSectionContextMenu.Opening += new System.ComponentModel.CancelEventHandler(this.TVSectionContextMenu_Opening);
            // 
            // TSMIAddPage
            // 
            this.TSMIAddPage.Image = global::GLTc.QuickNote.Properties.Resources.New;
            this.TSMIAddPage.Name = "TSMIAddPage";
            this.TSMIAddPage.Size = new System.Drawing.Size(128, 22);
            this.TSMIAddPage.Text = "New Page";
            // 
            // TSMIAddFolder
            // 
            this.TSMIAddFolder.Image = global::GLTc.QuickNote.Properties.Resources.NewFolderHS;
            this.TSMIAddFolder.Name = "TSMIAddFolder";
            this.TSMIAddFolder.Size = new System.Drawing.Size(128, 22);
            this.TSMIAddFolder.Text = "New Folder";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(125, 6);
            // 
            // TSMIExport
            // 
            this.TSMIExport.ImageTransparentColor = System.Drawing.Color.Fuchsia;
            this.TSMIExport.Name = "TSMIExport";
            this.TSMIExport.Size = new System.Drawing.Size(128, 22);
            this.TSMIExport.Text = "Export";
            // 
            // TSMIImport
            // 
            this.TSMIImport.Name = "TSMIImport";
            this.TSMIImport.Size = new System.Drawing.Size(128, 22);
            this.TSMIImport.Text = "Import";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(125, 6);
            // 
            // TSMITVCut
            // 
            this.TSMITVCut.Image = global::GLTc.QuickNote.Properties.Resources.Cut;
            this.TSMITVCut.Name = "TSMITVCut";
            this.TSMITVCut.Size = new System.Drawing.Size(128, 22);
            this.TSMITVCut.Text = "Cut";
            // 
            // TSMITVCopy
            // 
            this.TSMITVCopy.Image = global::GLTc.QuickNote.Properties.Resources.Copy;
            this.TSMITVCopy.Name = "TSMITVCopy";
            this.TSMITVCopy.Size = new System.Drawing.Size(128, 22);
            this.TSMITVCopy.Text = "Copy";
            // 
            // TSMITVPaste
            // 
            this.TSMITVPaste.Enabled = false;
            this.TSMITVPaste.Image = global::GLTc.QuickNote.Properties.Resources.Paste;
            this.TSMITVPaste.Name = "TSMITVPaste";
            this.TSMITVPaste.Size = new System.Drawing.Size(128, 22);
            this.TSMITVPaste.Text = "Paste";
            // 
            // TSMITVDelete
            // 
            this.TSMITVDelete.Image = global::GLTc.QuickNote.Properties.Resources.Delete;
            this.TSMITVDelete.Name = "TSMITVDelete";
            this.TSMITVDelete.Size = new System.Drawing.Size(128, 22);
            this.TSMITVDelete.Text = "Delete";
            // 
            // TSMIRename
            // 
            this.TSMIRename.Name = "TSMIRename";
            this.TSMIRename.Size = new System.Drawing.Size(128, 22);
            this.TSMIRename.Text = "Rename";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(125, 6);
            // 
            // TSMIProperties
            // 
            this.TSMIProperties.Name = "TSMIProperties";
            this.TSMIProperties.Size = new System.Drawing.Size(128, 22);
            this.TSMIProperties.Text = "Properties";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(131, 22);
            this.toolStripMenuItem2.Text = "New  Folder";
            // 
            // TVPageContextMenu
            // 
            this.TVPageContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMIPageOpen,
            this.TSMIPageCut,
            this.TSMIPageCopy,
            this.TSMIPageDelete,
            this.TSMIPageRename,
            this.toolStripSeparator7,
            this.TSMIPageProperties});
            this.TVPageContextMenu.Name = "TVPageContextMenu";
            this.TVPageContextMenu.Size = new System.Drawing.Size(124, 142);
            this.TVPageContextMenu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.TVPageContextMenu_ItemClicked);
            // 
            // TSMIPageOpen
            // 
            this.TSMIPageOpen.Image = global::GLTc.QuickNote.Properties.Resources.OpenDocument;
            this.TSMIPageOpen.Name = "TSMIPageOpen";
            this.TSMIPageOpen.Size = new System.Drawing.Size(123, 22);
            this.TSMIPageOpen.Text = "Open";
            // 
            // TSMIPageCut
            // 
            this.TSMIPageCut.Image = global::GLTc.QuickNote.Properties.Resources.Cut;
            this.TSMIPageCut.Name = "TSMIPageCut";
            this.TSMIPageCut.Size = new System.Drawing.Size(123, 22);
            this.TSMIPageCut.Text = "Cut";
            // 
            // TSMIPageCopy
            // 
            this.TSMIPageCopy.Image = global::GLTc.QuickNote.Properties.Resources.Copy;
            this.TSMIPageCopy.Name = "TSMIPageCopy";
            this.TSMIPageCopy.Size = new System.Drawing.Size(123, 22);
            this.TSMIPageCopy.Text = "Copy";
            // 
            // TSMIPageDelete
            // 
            this.TSMIPageDelete.Image = global::GLTc.QuickNote.Properties.Resources.Delete;
            this.TSMIPageDelete.Name = "TSMIPageDelete";
            this.TSMIPageDelete.Size = new System.Drawing.Size(123, 22);
            this.TSMIPageDelete.Text = "Delete";
            // 
            // TSMIPageRename
            // 
            this.TSMIPageRename.Name = "TSMIPageRename";
            this.TSMIPageRename.Size = new System.Drawing.Size(123, 22);
            this.TSMIPageRename.Text = "Rename";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(120, 6);
            // 
            // TSMIPageProperties
            // 
            this.TSMIPageProperties.Name = "TSMIPageProperties";
            this.TSMIPageProperties.Size = new System.Drawing.Size(123, 22);
            this.TSMIPageProperties.Text = "Properties";
            // 
            // TBContextContextMenu
            // 
            this.TBContextContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMIContextSave,
            this.TSMIContextRefresh,
            this.TSMIContextClose,
            this.TSMIContextLeaveThis});
            this.TBContextContextMenu.Name = "TBContextContextMenu";
            this.TBContextContextMenu.Size = new System.Drawing.Size(159, 92);
            this.TBContextContextMenu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.TBContextContextMenu_ItemClicked);
            // 
            // TSMIContextSave
            // 
            this.TSMIContextSave.Image = global::GLTc.QuickNote.Properties.Resources.Save;
            this.TSMIContextSave.Name = "TSMIContextSave";
            this.TSMIContextSave.Size = new System.Drawing.Size(158, 22);
            this.TSMIContextSave.Text = "Save";
            // 
            // TSMIContextRefresh
            // 
            this.TSMIContextRefresh.Image = global::GLTc.QuickNote.Properties.Resources.Refresh;
            this.TSMIContextRefresh.ImageTransparentColor = System.Drawing.Color.Fuchsia;
            this.TSMIContextRefresh.Name = "TSMIContextRefresh";
            this.TSMIContextRefresh.Size = new System.Drawing.Size(158, 22);
            this.TSMIContextRefresh.Text = "Refresh";
            // 
            // TSMIContextClose
            // 
            this.TSMIContextClose.Name = "TSMIContextClose";
            this.TSMIContextClose.Size = new System.Drawing.Size(158, 22);
            this.TSMIContextClose.Text = "Close";
            // 
            // TSMIContextLeaveThis
            // 
            this.TSMIContextLeaveThis.Name = "TSMIContextLeaveThis";
            this.TSMIContextLeaveThis.Size = new System.Drawing.Size(158, 22);
            this.TSMIContextLeaveThis.Text = "Close All  But This";
            // 
            // NIQuickNote
            // 
            this.NIQuickNote.ContextMenuStrip = this.NIContextMenu;
            this.NIQuickNote.Icon = ((System.Drawing.Icon)(resources.GetObject("NIQuickNote.Icon")));
            this.NIQuickNote.Text = "QuickNote";
            this.NIQuickNote.Visible = true;
            this.NIQuickNote.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.NIQuickNote_MouseDoubleClick);
            // 
            // NIContextMenu
            // 
            this.NIContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMIShowForm,
            this.TSMIExist,
            this.TSPLNoteIcon,
            this.TSMIHideWhenMinimize});
            this.NIContextMenu.Name = "NIContextMenu";
            this.NIContextMenu.Size = new System.Drawing.Size(169, 98);
            this.NIContextMenu.Opening += new System.ComponentModel.CancelEventHandler(this.NIContextMenu_Opening);
            // 
            // TSMIShowForm
            // 
            this.TSMIShowForm.Name = "TSMIShowForm";
            this.TSMIShowForm.Size = new System.Drawing.Size(168, 22);
            this.TSMIShowForm.Text = "Show";
            this.TSMIShowForm.Click += new System.EventHandler(this.TSMIShowForm_Click);
            // 
            // TSMIExist
            // 
            this.TSMIExist.Name = "TSMIExist";
            this.TSMIExist.Size = new System.Drawing.Size(168, 22);
            this.TSMIExist.Text = "Exit ";
            this.TSMIExist.Click += new System.EventHandler(this.TSMIExist_Click);
            // 
            // TSPLNoteIcon
            // 
            this.TSPLNoteIcon.Name = "TSPLNoteIcon";
            this.TSPLNoteIcon.Size = new System.Drawing.Size(165, 6);
            // 
            // TSMIHideWhenMinimize
            // 
            this.TSMIHideWhenMinimize.Checked = true;
            this.TSMIHideWhenMinimize.CheckOnClick = true;
            this.TSMIHideWhenMinimize.CheckState = System.Windows.Forms.CheckState.Checked;
            this.TSMIHideWhenMinimize.Name = "TSMIHideWhenMinimize";
            this.TSMIHideWhenMinimize.Size = new System.Drawing.Size(168, 22);
            this.TSMIHideWhenMinimize.Text = "Hide When Minimize";
            this.TSMIHideWhenMinimize.Click += new System.EventHandler(this.TSMIHideWhenMinimize_Click);
            // 
            // RTBContextMenu
            // 
            this.RTBContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMICut,
            this.TSMICopy,
            this.TSMIPaste,
            this.toolStripSeparator2,
            this.TSMISelectALL,
            this.toolStripSeparator3,
            this.TSMIFont,
            this.TSMIBullet,
            this.TSMIAddIndex});
            this.RTBContextMenu.Name = "RTBContextMenu";
            this.RTBContextMenu.Size = new System.Drawing.Size(125, 170);
            this.RTBContextMenu.Opening += new System.ComponentModel.CancelEventHandler(this.RTBContextMenu_Opening);
            // 
            // TSMICut
            // 
            this.TSMICut.Name = "TSMICut";
            this.TSMICut.Size = new System.Drawing.Size(124, 22);
            this.TSMICut.Text = "Cut";
            this.TSMICut.Click += new System.EventHandler(this.cutToolStripMenuItem_Click);
            // 
            // TSMICopy
            // 
            this.TSMICopy.Name = "TSMICopy";
            this.TSMICopy.Size = new System.Drawing.Size(124, 22);
            this.TSMICopy.Text = "Copy";
            this.TSMICopy.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // TSMIPaste
            // 
            this.TSMIPaste.Name = "TSMIPaste";
            this.TSMIPaste.Size = new System.Drawing.Size(124, 22);
            this.TSMIPaste.Text = "Paste";
            this.TSMIPaste.Click += new System.EventHandler(this.pasteToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(121, 6);
            // 
            // TSMISelectALL
            // 
            this.TSMISelectALL.Name = "TSMISelectALL";
            this.TSMISelectALL.Size = new System.Drawing.Size(124, 22);
            this.TSMISelectALL.Text = "Select All";
            this.TSMISelectALL.Click += new System.EventHandler(this.selectAllToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(121, 6);
            // 
            // TSMIFont
            // 
            this.TSMIFont.Name = "TSMIFont";
            this.TSMIFont.Size = new System.Drawing.Size(124, 22);
            this.TSMIFont.Text = "Font";
            this.TSMIFont.Click += new System.EventHandler(this.TSMIFont_Click);
            // 
            // TSMIBullet
            // 
            this.TSMIBullet.Name = "TSMIBullet";
            this.TSMIBullet.Size = new System.Drawing.Size(124, 22);
            this.TSMIBullet.Text = "Bullet";
            this.TSMIBullet.Click += new System.EventHandler(this.TSMIBullet_Click);
            // 
            // TSMIAddIndex
            // 
            this.TSMIAddIndex.Name = "TSMIAddIndex";
            this.TSMIAddIndex.Size = new System.Drawing.Size(124, 22);
            this.TSMIAddIndex.Text = "Add Index";
            this.TSMIAddIndex.Click += new System.EventHandler(this.TSMIAddIndex_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Image = global::GLTc.QuickNote.Properties.Resources.New;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(131, 22);
            this.toolStripMenuItem3.Text = "Add Page";
            // 
            // TBContext
            // 
            this.TBContext.AllowDrop = true;
            this.TBContext.Controls.Add(this.TbStart);
            this.TBContext.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TBContext.Location = new System.Drawing.Point(0, 0);
            this.TBContext.Margin = new System.Windows.Forms.Padding(0);
            this.TBContext.Name = "TBContext";
            this.TBContext.SelectedIndex = 0;
            this.TBContext.ShowToolTips = true;
            this.TBContext.Size = new System.Drawing.Size(598, 530);
            this.TBContext.TabIndex = 0;
            this.TBContext.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TBContext_MouseDoubleClick);
            this.TBContext.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TBContext_MouseUp);
            // 
            // TbStart
            // 
            this.TbStart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.TbStart.Controls.Add(this.tabelLayoutStartPage);
            this.TbStart.Location = new System.Drawing.Point(4, 22);
            this.TbStart.Name = "TbStart";
            this.TbStart.Size = new System.Drawing.Size(590, 504);
            this.TbStart.TabIndex = 0;
            this.TbStart.Text = "Start Page";
            this.TbStart.ToolTipText = "Start Page";
            this.TbStart.UseVisualStyleBackColor = true;
            // 
            // tabelLayoutStartPage
            // 
            this.tabelLayoutStartPage.BackColor = System.Drawing.Color.Transparent;
            this.tabelLayoutStartPage.ColumnCount = 1;
            this.tabelLayoutStartPage.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tabelLayoutStartPage.Controls.Add(this.LbStartPage, 0, 1);
            this.tabelLayoutStartPage.Controls.Add(this.LbStartPageSlogan, 0, 0);
            this.tabelLayoutStartPage.Controls.Add(this.lbCopyRight, 0, 2);
            this.tabelLayoutStartPage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabelLayoutStartPage.Location = new System.Drawing.Point(0, 0);
            this.tabelLayoutStartPage.Margin = new System.Windows.Forms.Padding(0);
            this.tabelLayoutStartPage.Name = "tabelLayoutStartPage";
            this.tabelLayoutStartPage.RowCount = 3;
            this.tabelLayoutStartPage.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tabelLayoutStartPage.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tabelLayoutStartPage.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.tabelLayoutStartPage.Size = new System.Drawing.Size(590, 504);
            this.tabelLayoutStartPage.TabIndex = 0;
            this.tabelLayoutStartPage.Paint += new System.Windows.Forms.PaintEventHandler(this.tabelLayoutStartPage_Paint);
            // 
            // LbStartPage
            // 
            this.LbStartPage.AutoSize = true;
            this.LbStartPage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LbStartPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LbStartPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbStartPage.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.LbStartPage.Location = new System.Drawing.Point(0, 60);
            this.LbStartPage.Margin = new System.Windows.Forms.Padding(0);
            this.LbStartPage.Name = "LbStartPage";
            this.LbStartPage.Size = new System.Drawing.Size(590, 348);
            this.LbStartPage.TabIndex = 0;
            this.LbStartPage.Text = "QuickNote";
            this.LbStartPage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LbStartPageSlogan
            // 
            this.LbStartPageSlogan.AutoSize = true;
            this.LbStartPageSlogan.Dock = System.Windows.Forms.DockStyle.Right;
            this.LbStartPageSlogan.Font = new System.Drawing.Font("Mangal", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbStartPageSlogan.Location = new System.Drawing.Point(587, 0);
            this.LbStartPageSlogan.Name = "LbStartPageSlogan";
            this.LbStartPageSlogan.Size = new System.Drawing.Size(0, 60);
            this.LbStartPageSlogan.TabIndex = 3;
            this.LbStartPageSlogan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbCopyRight
            // 
            this.lbCopyRight.AutoSize = true;
            this.lbCopyRight.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbCopyRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCopyRight.Location = new System.Drawing.Point(3, 408);
            this.lbCopyRight.Name = "lbCopyRight";
            this.lbCopyRight.Size = new System.Drawing.Size(584, 17);
            this.lbCopyRight.TabIndex = 4;
            this.lbCopyRight.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 601);
            this.Controls.Add(this.toolStripContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MSTopMenu;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QuickNote";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Resize += new System.EventHandler(this.MainForm_Resize);
            this.toolStripContainer1.BottomToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.BottomToolStripPanel.PerformLayout();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.STSBar.ResumeLayout(false);
            this.STSBar.PerformLayout();
            this.SCMainForm.Panel1.ResumeLayout(false);
            this.SCMainForm.Panel2.ResumeLayout(false);
            this.SCMainForm.ResumeLayout(false);
            this.TBLeftWindow.ResumeLayout(false);
            this.TPOutline.ResumeLayout(false);
            this.TPIndex.ResumeLayout(false);
            this.IndexTableLayOut.ResumeLayout(false);
            this.IndexTableLayOut.PerformLayout();
            this.TPSearch.ResumeLayout(false);
            this.SearchTableLayOut.ResumeLayout(false);
            this.SearchTableLayOut.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.MSTopMenu.ResumeLayout(false);
            this.MSTopMenu.PerformLayout();
            this.TbStandbar.ResumeLayout(false);
            this.TbStandbar.PerformLayout();
            this.TSFormat.ResumeLayout(false);
            this.TSFormat.PerformLayout();
            this.TVSectionContextMenu.ResumeLayout(false);
            this.TVPageContextMenu.ResumeLayout(false);
            this.TBContextContextMenu.ResumeLayout(false);
            this.NIContextMenu.ResumeLayout(false);
            this.RTBContextMenu.ResumeLayout(false);
            this.TBContext.ResumeLayout(false);
            this.TbStart.ResumeLayout(false);
            this.tabelLayoutStartPage.ResumeLayout(false);
            this.tabelLayoutStartPage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.MenuStrip MSTopMenu;
        private System.Windows.Forms.ToolStrip TbStandbar;
        private System.Windows.Forms.SplitContainer SCMainForm;
        private System.Windows.Forms.TabControl TBLeftWindow;
        private System.Windows.Forms.TabPage TPOutline;
        private System.Windows.Forms.TabPage TPIndex;
        private GLTc.QuickNote.CustomControl.CustomTabControl TBContext;
        private System.Windows.Forms.TabPage TbStart;
        private System.Windows.Forms.ToolStrip TSFormat;
        private System.Windows.Forms.TabPage TPSearch;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TSMINew;
        private System.Windows.Forms.ToolStripMenuItem TSMIOpen;
        private System.Windows.Forms.ToolStripMenuItem TSMIClose;
        private System.Windows.Forms.ToolStripMenuItem TSMISave;
        private System.Windows.Forms.ToolStripMenuItem TSMISaveAs;
        private System.Windows.Forms.ToolStripMenuItem TSMISaveAll;
        private System.Windows.Forms.ToolStripMenuItem TSMIExit;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem findToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ViewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DocumentMapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem boldToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem italicToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem underlineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bulletToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem standardBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formatingBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statusBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutQuickNoteToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton TSBNewPage;
        private System.Windows.Forms.ToolStripButton TSBSave;
        private System.Windows.Forms.ToolStripButton TSBSaveAll;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton STBCut;
        private System.Windows.Forms.ToolStripButton STBCopy;
        private System.Windows.Forms.ToolStripButton STBPaste;
        private System.Windows.Forms.ToolStripButton TSBFormatPainter;
        private System.Windows.Forms.ToolStripComboBox TSCBWidth;
        private System.Windows.Forms.ToolStripComboBox TSCBFont;
        private System.Windows.Forms.ToolStripComboBox TSCBSize;
        private System.Windows.Forms.ToolStripButton TSBBlod;
        private System.Windows.Forms.ToolStripButton TSBItalic;
        private System.Windows.Forms.ToolStripButton TSBUnderline;
        private System.Windows.Forms.ToolStripButton TSBAlignLeft;
        private System.Windows.Forms.ToolStripButton TSBAlignCenter;
        private System.Windows.Forms.ToolStripButton TSBAlignRight;
        private System.Windows.Forms.ToolStripButton TSBBullet;
        private System.Windows.Forms.ToolStripButton TSBDecreaseIndent;
        private System.Windows.Forms.ToolStripButton TSBIncreaseIndent;
        private System.Windows.Forms.ToolStripButton TSBMap;
        private System.Windows.Forms.StatusStrip STSBar;
        private System.Windows.Forms.TableLayoutPanel IndexTableLayOut;
        private System.Windows.Forms.TextBox TPIndexCondition;
        private System.Windows.Forms.Label TpIndexTips;
        private System.Windows.Forms.TableLayoutPanel SearchTableLayOut;
        private System.Windows.Forms.Label TPSearchTips;
        private System.Windows.Forms.TextBox TPSearchCondition;
        private System.Windows.Forms.TableLayoutPanel tabelLayoutStartPage;
        private System.Windows.Forms.Label LbStartPageSlogan;
        private System.Windows.Forms.Label LbStartPage;
        private System.Windows.Forms.ImageList ImgLTree;
        private System.Windows.Forms.TreeView TVOutline;
        private System.Windows.Forms.ContextMenuStrip TVSectionContextMenu;
        private System.Windows.Forms.ToolStripMenuItem TSMITVDelete;
        private System.Windows.Forms.ToolStripMenuItem TSMIRename;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ContextMenuStrip TVPageContextMenu;
        private System.Windows.Forms.ToolStripMenuItem TSMIPageDelete;
        private System.Windows.Forms.ToolStripMenuItem TSMIPageRename;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem TSMIAddFolder;
        private System.Windows.Forms.ToolStripMenuItem TSMIAddPage;
        private System.Windows.Forms.ContextMenuStrip TBContextContextMenu;
        private System.Windows.Forms.ToolStripMenuItem TSMIContextSave;
        private System.Windows.Forms.ToolStripMenuItem TSMIContextClose;
        private System.Windows.Forms.ToolStripMenuItem TSMIContextLeaveThis;
        private System.Windows.Forms.NotifyIcon NIQuickNote;
        private System.Windows.Forms.ContextMenuStrip NIContextMenu;
        private System.Windows.Forms.ToolStripMenuItem TSMIShowForm;
        private System.Windows.Forms.ToolStripMenuItem TSMIExist;
        private System.Windows.Forms.ContextMenuStrip RTBContextMenu;
        private System.Windows.Forms.ToolStripMenuItem TSMICut;
        private System.Windows.Forms.ToolStripMenuItem TSMICopy;
        private System.Windows.Forms.ToolStripMenuItem TSMIPaste;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem TSMISelectALL;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem TSMIFont;
        private System.Windows.Forms.ToolStripMenuItem TSMIBullet;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton TSBUndo;
        private System.Windows.Forms.ToolStripButton TSBRedo;
        private System.Windows.Forms.FontDialog ContextFontDialog;
        private System.Windows.Forms.ListBox TPSearchListBox;
        private System.Windows.Forms.Label LBSearchResultTips;
        private System.Windows.Forms.ToolStripMenuItem TSMIContextRefresh;
        private System.Windows.Forms.ToolStripMenuItem TSMIPageOpen;
        private System.Windows.Forms.ListBox TPIndexListBox;
        private System.Windows.Forms.ToolStripMenuItem InsertToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertPictureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem WordWrapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TSMIExport;
        private System.Windows.Forms.ToolStripMenuItem TSMIImport;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripStatusLabel TSSLLine;
        private System.Windows.Forms.ToolStripStatusLabel STSPath;
        public System.Windows.Forms.ToolStripStatusLabel TSSLLineNum;
        private System.Windows.Forms.ToolStripStatusLabel TSSLColumnNum;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem TSMIProperties;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem TSMIPageProperties;
        private System.Windows.Forms.ToolStripMenuItem TSMIAddIndex;
        private System.Windows.Forms.ToolStripMenuItem replaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rPGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cLPToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton TSSBBackColor;
        private System.Windows.Forms.ToolStripSplitButton TSSBTextColor;
        private System.Windows.Forms.ToolStripButton TSBFunctionToolBar;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripStatusLabel TSSBSave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button TPSearchListbar;
        private System.Windows.Forms.ToolStripMenuItem TSMITVCut;
        private System.Windows.Forms.ToolStripMenuItem TSMITVCopy;
        private System.Windows.Forms.ToolStripMenuItem TSMITVPaste;
        private System.Windows.Forms.ToolStripMenuItem TSMIPageCut;
        private System.Windows.Forms.ToolStripMenuItem TSMIPageCopy;
        public System.Windows.Forms.Label lbCopyRight;
        private System.Windows.Forms.ToolStripMenuItem rPGSearchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TSMIHideWhenMinimize;
        private System.Windows.Forms.ToolStripSeparator TSPLNoteIcon;
        private System.Windows.Forms.ToolStripMenuItem dDSToolStripMenuItem;
    }
}