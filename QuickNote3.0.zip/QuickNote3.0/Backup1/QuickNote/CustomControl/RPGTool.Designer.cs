namespace GLTc.QuickNote.CustomControl
{
    partial class RPGTool
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RPGTool));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tbSelectedSubroutine = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lbSubroutine = new System.Windows.Forms.Label();
            this.lbSelectedSubroutine = new System.Windows.Forms.Label();
            this.lbSubroutineList = new System.Windows.Forms.Label();
            this.TCSubroutine = new System.Windows.Forms.TabControl();
            this.TPList = new System.Windows.Forms.TabPage();
            this.tvSubroutineList = new System.Windows.Forms.TreeView();
            this.ImgListSubroutine = new System.Windows.Forms.ImageList(this.components);
            this.TPSubroutineFlow = new System.Windows.Forms.TabPage();
            this.tvSubroutineFlow = new System.Windows.Forms.TreeView();
            this.CMSSRFlow = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TSMIGOTO = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIShowSRBody = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.TCSubroutine.SuspendLayout();
            this.TPList.SuspendLayout();
            this.TPSubroutineFlow.SuspendLayout();
            this.CMSSRFlow.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tbSelectedSubroutine, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbSelectedSubroutine, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbSubroutineList, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.TCSubroutine, 0, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(150, 535);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tbSelectedSubroutine
            // 
            this.tbSelectedSubroutine.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tbSelectedSubroutine.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbSelectedSubroutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSelectedSubroutine.Location = new System.Drawing.Point(3, 57);
            this.tbSelectedSubroutine.Name = "tbSelectedSubroutine";
            this.tbSelectedSubroutine.ReadOnly = true;
            this.tbSelectedSubroutine.Size = new System.Drawing.Size(144, 35);
            this.tbSelectedSubroutine.TabIndex = 5;
            this.tbSelectedSubroutine.DoubleClick += new System.EventHandler(this.tbSelectedSubroutine_DoubleClick);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel2.Controls.Add(this.lbSubroutine, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(150, 21);
            this.tableLayoutPanel2.TabIndex = 0;
            this.tableLayoutPanel2.MouseLeave += new System.EventHandler(this.tableLayoutPanel2_MouseLeave);
            this.tableLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel2_Paint);
            this.tableLayoutPanel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.tableLayoutPanel2_MouseMove);
            this.tableLayoutPanel2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tableLayoutPanel2_MouseClick);
            // 
            // lbSubroutine
            // 
            this.lbSubroutine.AutoSize = true;
            this.lbSubroutine.Location = new System.Drawing.Point(1, 1);
            this.lbSubroutine.Margin = new System.Windows.Forms.Padding(1);
            this.lbSubroutine.Name = "lbSubroutine";
            this.lbSubroutine.Size = new System.Drawing.Size(63, 13);
            this.lbSubroutine.TabIndex = 0;
            this.lbSubroutine.Text = "Subroutines";
            // 
            // lbSelectedSubroutine
            // 
            this.lbSelectedSubroutine.AutoSize = true;
            this.lbSelectedSubroutine.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbSelectedSubroutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSelectedSubroutine.Location = new System.Drawing.Point(3, 41);
            this.lbSelectedSubroutine.Name = "lbSelectedSubroutine";
            this.lbSelectedSubroutine.Size = new System.Drawing.Size(144, 13);
            this.lbSelectedSubroutine.TabIndex = 1;
            this.lbSelectedSubroutine.Text = "Selected Subroutine";
            // 
            // lbSubroutineList
            // 
            this.lbSubroutineList.AutoSize = true;
            this.lbSubroutineList.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbSubroutineList.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSubroutineList.Location = new System.Drawing.Point(3, 107);
            this.lbSubroutineList.Name = "lbSubroutineList";
            this.lbSubroutineList.Size = new System.Drawing.Size(144, 13);
            this.lbSubroutineList.TabIndex = 6;
            this.lbSubroutineList.Text = "Subroutine List";
            // 
            // TCSubroutine
            // 
            this.TCSubroutine.Controls.Add(this.TPList);
            this.TCSubroutine.Controls.Add(this.TPSubroutineFlow);
            this.TCSubroutine.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TCSubroutine.Location = new System.Drawing.Point(3, 123);
            this.TCSubroutine.Name = "TCSubroutine";
            this.TCSubroutine.SelectedIndex = 0;
            this.TCSubroutine.Size = new System.Drawing.Size(144, 409);
            this.TCSubroutine.TabIndex = 7;
            // 
            // TPList
            // 
            this.TPList.Controls.Add(this.tvSubroutineList);
            this.TPList.Location = new System.Drawing.Point(4, 22);
            this.TPList.Name = "TPList";
            this.TPList.Padding = new System.Windows.Forms.Padding(3);
            this.TPList.Size = new System.Drawing.Size(136, 383);
            this.TPList.TabIndex = 0;
            this.TPList.Text = "SR List";
            this.TPList.UseVisualStyleBackColor = true;
            // 
            // tvSubroutineList
            // 
            this.tvSubroutineList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvSubroutineList.FullRowSelect = true;
            this.tvSubroutineList.ImageIndex = 0;
            this.tvSubroutineList.ImageList = this.ImgListSubroutine;
            this.tvSubroutineList.Location = new System.Drawing.Point(3, 3);
            this.tvSubroutineList.Name = "tvSubroutineList";
            this.tvSubroutineList.SelectedImageIndex = 0;
            this.tvSubroutineList.ShowLines = false;
            this.tvSubroutineList.ShowNodeToolTips = true;
            this.tvSubroutineList.ShowRootLines = false;
            this.tvSubroutineList.Size = new System.Drawing.Size(130, 377);
            this.tvSubroutineList.TabIndex = 9;
            this.tvSubroutineList.DoubleClick += new System.EventHandler(this.tvSubroutineList_DoubleClick);
            this.tvSubroutineList.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvSubroutineList_NodeMouseClick);
            // 
            // ImgListSubroutine
            // 
            this.ImgListSubroutine.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImgListSubroutine.ImageStream")));
            this.ImgListSubroutine.TransparentColor = System.Drawing.Color.Magenta;
            this.ImgListSubroutine.Images.SetKeyName(0, "VSObject_Structure.bmp");
            // 
            // TPSubroutineFlow
            // 
            this.TPSubroutineFlow.Controls.Add(this.tvSubroutineFlow);
            this.TPSubroutineFlow.Location = new System.Drawing.Point(4, 22);
            this.TPSubroutineFlow.Name = "TPSubroutineFlow";
            this.TPSubroutineFlow.Padding = new System.Windows.Forms.Padding(3);
            this.TPSubroutineFlow.Size = new System.Drawing.Size(136, 383);
            this.TPSubroutineFlow.TabIndex = 1;
            this.TPSubroutineFlow.Text = "SR Flow";
            this.TPSubroutineFlow.UseVisualStyleBackColor = true;
            // 
            // tvSubroutineFlow
            // 
            this.tvSubroutineFlow.ContextMenuStrip = this.CMSSRFlow;
            this.tvSubroutineFlow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvSubroutineFlow.FullRowSelect = true;
            this.tvSubroutineFlow.ImageIndex = 0;
            this.tvSubroutineFlow.ImageList = this.ImgListSubroutine;
            this.tvSubroutineFlow.Location = new System.Drawing.Point(3, 3);
            this.tvSubroutineFlow.Name = "tvSubroutineFlow";
            this.tvSubroutineFlow.SelectedImageIndex = 0;
            this.tvSubroutineFlow.ShowNodeToolTips = true;
            this.tvSubroutineFlow.Size = new System.Drawing.Size(130, 377);
            this.tvSubroutineFlow.TabIndex = 0;
            this.tvSubroutineFlow.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvSubroutineFlow_NodeMouseClick_1);
            // 
            // CMSSRFlow
            // 
            this.CMSSRFlow.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMIGOTO,
            this.TSMIShowSRBody});
            this.CMSSRFlow.Name = "CMSSRFlow";
            this.CMSSRFlow.Size = new System.Drawing.Size(154, 48);
            // 
            // TSMIGOTO
            // 
            this.TSMIGOTO.Name = "TSMIGOTO";
            this.TSMIGOTO.Size = new System.Drawing.Size(153, 22);
            this.TSMIGOTO.Text = "Go to Definition";
            this.TSMIGOTO.Click += new System.EventHandler(this.TSMIGOTO_Click);
            // 
            // TSMIShowSRBody
            // 
            this.TSMIShowSRBody.Image = global::GLTc.QuickNote.Properties.Resources.ShowSRBody;
            this.TSMIShowSRBody.Name = "TSMIShowSRBody";
            this.TSMIShowSRBody.Size = new System.Drawing.Size(153, 22);
            this.TSMIShowSRBody.Text = "Subroutine Body";
            this.TSMIShowSRBody.Click += new System.EventHandler(this.TSMIShowSRBody_Click);
            // 
            // RPGTool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "RPGTool";
            this.Size = new System.Drawing.Size(150, 535);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.TCSubroutine.ResumeLayout(false);
            this.TPList.ResumeLayout(false);
            this.TPSubroutineFlow.ResumeLayout(false);
            this.CMSSRFlow.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lbSubroutine;
        private System.Windows.Forms.TextBox tbSelectedSubroutine;
        private System.Windows.Forms.Label lbSelectedSubroutine;
        private System.Windows.Forms.Label lbSubroutineList;
        private System.Windows.Forms.TabControl TCSubroutine;
        private System.Windows.Forms.TabPage TPList;
        private System.Windows.Forms.TreeView tvSubroutineList;
        private System.Windows.Forms.TabPage TPSubroutineFlow;
        private System.Windows.Forms.TreeView tvSubroutineFlow;
        private System.Windows.Forms.ImageList ImgListSubroutine;
        private System.Windows.Forms.ContextMenuStrip CMSSRFlow;
        private System.Windows.Forms.ToolStripMenuItem TSMIGOTO;
        private System.Windows.Forms.ToolStripMenuItem TSMIShowSRBody;
    }
}
