using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using GLTc.QuickNote.Command;
using GLTc.QuickNote.Command.ViewSourceCode.RPG;
using GLTc.QuickNote.Command.ViewSourceCode;


namespace GLTc.QuickNote.CustomControl
{
    public partial class SearchToolBarRPG : BaseSearchBar
    {

        /// <summary>
        /// the six space of RPG Format 
        /// </summary>
        private  string FormatFormerSpace = "  ";

        #region SelectedRichTextBox
        /// <summary>
        /// the selected RichTextbox
        /// </summary>
        public CustomRichTextBox SelectedRichTextBox;
        #endregion 

        public SearchToolBar CurrentSearchToolbar;

        public override bool Focused
        {
            get
            {
                return this.CurrentSearchToolbar.tbSearch.Focused;
            }

        }


        #region Constructor
        public SearchToolBarRPG(CustomRichTextBox currentRichTextBox,LanguageViewer CurrLanguageViewer)
        {
            
            this.SelectedRichTextBox = currentRichTextBox;
            this.SelectedRichTextBox.SelectionChanged += new EventHandler(SelectedRichTextBox_SelectionChanged);
            InitializeComponent();
            CurrentSearchToolbar = new SearchToolBar(currentRichTextBox, "RPG", CurrLanguageViewer);
            CurrentSearchToolbar.Dock = DockStyle.Fill;
            this.Tbcontainer.Controls.Add(CurrentSearchToolbar, 0, 0);
        }
        public SearchToolBarRPG(CustomRichTextBox currentRichTextBox)
        {

            this.SelectedRichTextBox = currentRichTextBox;
            this.SelectedRichTextBox.SelectionChanged += new EventHandler(SelectedRichTextBox_SelectionChanged);
            InitializeComponent();
            CurrentSearchToolbar = new SearchToolBar(currentRichTextBox, "RPG");
            CurrentSearchToolbar.Dock = DockStyle.Fill;
            this.Tbcontainer.Controls.Add(CurrentSearchToolbar, 0, 0);
        }


        #endregion

        #region SelectedRichTextBox_SelectionChanged
        /// <summary>
        /// Show the Format string
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void SelectedRichTextBox_SelectionChanged(object sender, EventArgs e)
        {
            string SpecName = RPGLanguageViewer.GetSpecName(this.SelectedRichTextBox);
            if (!string.IsNullOrEmpty(SpecName))
            {
                this.SetFormatString(SpecName);
            }
        }
        #endregion 

        #region SearchToolBar_Paint
        private void SearchToolBar_Paint(object sender, PaintEventArgs e)
        {
            Graphics GP = e.Graphics;
            //GP.DrawLine(Pens.Gray, new Point(0, 0), new Point(this.Width-2, 0));
            //GP.DrawLine(Pens.Gray, new Point(0, 0), new Point(0, this.Height));
           // GP.DrawLine(Pens.Gray, new Point(0, this.Height - 1), new Point(this.Width-2, this.Height - 1));
            //GP.DrawLine(Pens.Gray, new Point(this.Width  , 0), new Point(this.Width , this.Height));
        }
        #endregion 



        #region SetFormatString
        /// <summary>
        /// set the RPG format string by Spec
        /// </summary>
        /// <param name="Spec"></param>
        public void SetFormatString(string Spec)
        {
            switch (Spec.ToUpper())
            {
                case "C":
                    this.lbFormatString.Text = FormatFormerSpace+Properties.Settings.Default.RPGCFormat;
                    break;
                case "F":
                    this.lbFormatString.Text = FormatFormerSpace+Properties.Settings.Default.RPGFFormat;
                    break;
                case "D":
                    this.lbFormatString.Text = FormatFormerSpace+Properties.Settings.Default.RPGDFormat;
                    break;
            }

        }
        #endregion 

        #region PlusFormerSPace
        public void PlusFormerSPace()
        {
            if (this.lbFormatString.Text.Trim() != string.Empty)
            {
                this.FormatFormerSpace += " ";
                this.lbFormatString.Text = " " + this.lbFormatString.Text;
            }

        }
        #endregion 

        #region SubtractFormerSpace
        public void SubtractFormerSpace()
        {
            if (this.lbFormatString.Text.Trim() != string.Empty && FormatFormerSpace.Length > 1)
            {
                this.FormatFormerSpace = this.FormatFormerSpace.Substring(0, FormatFormerSpace.Length - 1);
                this.lbFormatString.Text = this.FormatFormerSpace + this.lbFormatString.Text.TrimStart(' ');
            }

        }
        #endregion 

        private void picbPlus_Click(object sender, EventArgs e)
        {
            PlusFormerSPace();
        }

        private void picbSubtract_Click(object sender, EventArgs e)
        {
            SubtractFormerSpace();
        }

        private void picbSubtract_MouseLeave(object sender, EventArgs e)
        {
            ((PictureBox)sender).BorderStyle = BorderStyle.None;
        }



        private void picbSubtract_MouseDown(object sender, MouseEventArgs e)
        {
            ((PictureBox)sender).BorderStyle = BorderStyle.Fixed3D;
        }

        private void picbSubtract_MouseUp(object sender, MouseEventArgs e)
        {
            ((PictureBox)sender).BorderStyle = BorderStyle.None;
        }



 


    }
}
