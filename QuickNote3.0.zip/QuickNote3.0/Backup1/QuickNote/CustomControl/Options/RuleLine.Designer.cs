namespace GLTc.QuickNote.CustomControl.Options
{
    partial class RuleLine
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbRuleLine = new System.Windows.Forms.GroupBox();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.rbSingleLine = new System.Windows.Forms.RadioButton();
            this.rbDoubleLine = new System.Windows.Forms.RadioButton();
            this.rbCrossLine = new System.Windows.Forms.RadioButton();
            this.gbSignature = new System.Windows.Forms.GroupBox();
            this.tbSignature = new System.Windows.Forms.TextBox();
            this.gbRuleLine.SuspendLayout();
            this.gbSignature.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbRuleLine
            // 
            this.gbRuleLine.Controls.Add(this.radioButton4);
            this.gbRuleLine.Controls.Add(this.rbSingleLine);
            this.gbRuleLine.Controls.Add(this.rbDoubleLine);
            this.gbRuleLine.Controls.Add(this.rbCrossLine);
            this.gbRuleLine.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbRuleLine.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.gbRuleLine.Location = new System.Drawing.Point(0, 0);
            this.gbRuleLine.Name = "gbRuleLine";
            this.gbRuleLine.Size = new System.Drawing.Size(274, 98);
            this.gbRuleLine.TabIndex = 0;
            this.gbRuleLine.TabStop = false;
            this.gbRuleLine.Text = "RPG RuleLine Style";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Checked = true;
            this.radioButton4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.radioButton4.Location = new System.Drawing.Point(118, 52);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(57, 18);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "None";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // rbSingleLine
            // 
            this.rbSingleLine.AutoSize = true;
            this.rbSingleLine.Location = new System.Drawing.Point(118, 20);
            this.rbSingleLine.Name = "rbSingleLine";
            this.rbSingleLine.Size = new System.Drawing.Size(74, 17);
            this.rbSingleLine.TabIndex = 2;
            this.rbSingleLine.Text = "SingleLine";
            this.rbSingleLine.UseVisualStyleBackColor = true;
            // 
            // rbDoubleLine
            // 
            this.rbDoubleLine.AutoSize = true;
            this.rbDoubleLine.Location = new System.Drawing.Point(6, 52);
            this.rbDoubleLine.Name = "rbDoubleLine";
            this.rbDoubleLine.Size = new System.Drawing.Size(79, 17);
            this.rbDoubleLine.TabIndex = 1;
            this.rbDoubleLine.Text = "DoubleLine";
            this.rbDoubleLine.UseVisualStyleBackColor = true;
            // 
            // rbCrossLine
            // 
            this.rbCrossLine.AutoSize = true;
            this.rbCrossLine.Location = new System.Drawing.Point(6, 19);
            this.rbCrossLine.Name = "rbCrossLine";
            this.rbCrossLine.Size = new System.Drawing.Size(71, 17);
            this.rbCrossLine.TabIndex = 0;
            this.rbCrossLine.Text = "CrossLine";
            this.rbCrossLine.UseVisualStyleBackColor = true;
            // 
            // gbSignature
            // 
            this.gbSignature.Controls.Add(this.tbSignature);
            this.gbSignature.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gbSignature.Location = new System.Drawing.Point(0, 115);
            this.gbSignature.Name = "gbSignature";
            this.gbSignature.Size = new System.Drawing.Size(274, 84);
            this.gbSignature.TabIndex = 1;
            this.gbSignature.TabStop = false;
            this.gbSignature.Text = "PersonalSignature";
            // 
            // tbSignature
            // 
            this.tbSignature.Location = new System.Drawing.Point(6, 35);
            this.tbSignature.MaxLength = 60;
            this.tbSignature.Name = "tbSignature";
            this.tbSignature.Size = new System.Drawing.Size(249, 20);
            this.tbSignature.TabIndex = 0;
            // 
            // RuleLine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gbSignature);
            this.Controls.Add(this.gbRuleLine);
            this.Name = "RuleLine";
            this.Size = new System.Drawing.Size(274, 199);
            this.gbRuleLine.ResumeLayout(false);
            this.gbRuleLine.PerformLayout();
            this.gbSignature.ResumeLayout(false);
            this.gbSignature.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbRuleLine;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton rbSingleLine;
        private System.Windows.Forms.RadioButton rbDoubleLine;
        private System.Windows.Forms.RadioButton rbCrossLine;
        private System.Windows.Forms.GroupBox gbSignature;
        private System.Windows.Forms.TextBox tbSignature;
    }
}
