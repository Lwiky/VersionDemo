using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using GLTc.QuickNote ;

namespace GLTc.QuickNote.CustomControl.Options
{
    /// <summary>
    /// the rule line style
    /// </summary>
    public enum RuleLineStyle {CrossLine,SingleLine,DoubleLine,None};

    public partial class RuleLine : UserControl,IOption
    {
        private Form mainForm;
        /// <summary>
        /// the main form window
        /// </summary>
        public Form MainForm
        {
            get { return mainForm; }
            set { mainForm = value; }
        }
	

        public RuleLine(Form mainWindow)
        {
            this.MainForm = mainWindow;
            InitializeComponent();

        }

        #region BindRuleLineStyle
        private void BindRuleLineStyle()
        {
            for (int i = 0; i < this.gbRuleLine.Controls.Count; i++)
            {
                if (((RadioButton)this.gbRuleLine.Controls[i]).Text.ToLower() == 
                    Properties.Settings.Default.RuleLineStyle.ToLower())
                {
                    ((RadioButton)this.gbRuleLine.Controls[i]).Select();
                }
                
            }


        }
        #endregion 

        #region LoadSignature
        private void LoadSignature()
        {

            this.tbSignature.Text = Properties.Settings.Default.PersonalSignature;
        }
        #endregion 

        #region ChangeSignature
        /// <summary>
        /// change the signature
        /// </summary>
        private void ChangeSignature()
        {
            this.MainForm.Text = "QuickNote";
            if (!string.IsNullOrEmpty(Properties.Settings.Default.PersonalSignature))
            {
                this.MainForm.Text = "QuickNote" + " - " + Properties.Settings.Default.PersonalSignature;
            }
  
        }
        #endregion 

        #region IOption Members

        public void SaveSettings()
        {

            for (int i = 0; i < this.gbRuleLine.Controls.Count; i++)
            {
                if (((RadioButton)this.gbRuleLine.Controls[i]).Checked)
                {
                    Properties.Settings.Default.RuleLineStyle = ((RadioButton)this.gbRuleLine.Controls[i]).Text;
                    break;
                }

            }
            // save signature
            Properties.Settings.Default.PersonalSignature = this.tbSignature.Text;
            ChangeSignature();
            //Refesh selectedRichtextbox
            RichTextBox selectedRichtextbox = ((GLTc.QuickNote.MainForm)MainForm).CurrentContextOperator.SelectedRichTextBox;
            if (selectedRichtextbox != null)
            {
                selectedRichtextbox.Refresh();
            }
            //save settings
            Properties.Settings.Default.Save();
        }

        public void LoadSettings()
        {
            BindRuleLineStyle();
            LoadSignature();
            
        }

        #endregion




    }
}
