using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace GLTc.QuickNote.CustomControl.Options
{
    interface IOption
    {
         Form MainForm
        {
            get;
            set;
        }

        /// <summary>
        /// save the setting
        /// </summary>
        void SaveSettings();

        /// <summary>
        /// Load the Setting
        /// </summary>
        void LoadSettings();
    }
}
