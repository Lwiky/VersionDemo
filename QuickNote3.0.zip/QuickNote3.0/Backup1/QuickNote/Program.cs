using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Threading;
using System.Configuration;
using GLTc.NoteLib;
namespace GLTc.QuickNote
{
    public static class Program
    {
        public static Welcome WelcomeForm  ;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
       {
          
            //set the database path
           if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["DataBasePath"]))
           {
               AccessDatabase.DataBaseName = ConfigurationManager.AppSettings["DataBasePath"].ToString();
           }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            WelcomeForm = new Welcome();
            Thread welcomeThread = new Thread(new ThreadStart(ShowWelcome));
            welcomeThread.Start();

            // Loop until welcome thread activates.
            while (!welcomeThread.IsAlive) ;
            // Put the main thread to sleep for 1 millisecond to
            // allow the welcome thread to show tips.
            Thread.Sleep(1);

            MainForm MF = new MainForm();
            Application.Run(MF);
            
        }


        /// <summary>
        /// Show welcome form
        /// </summary>
        static void ShowWelcome()
        {
            WelcomeForm.ShowDialog();


        }

    }
}