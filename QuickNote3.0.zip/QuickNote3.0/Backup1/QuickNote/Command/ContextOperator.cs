using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using System.Drawing;
using System.Threading;
using System.Data.Common;
using GLTc.NoteLib;
using GLTc.QuickNote;
using GLTc.QuickNote.CustomControl;
using System.Diagnostics;
using System.Runtime.InteropServices;


namespace GLTc.QuickNote.Command
{
    public delegate void OpenNewRichTextBox(CustomRichTextBox currentSelectedRichTextBox);
    public delegate void SaveTabPageData(TabPage TP);
    public delegate void ShowSaveTip();
    public delegate void ChangeRichtextboxFont(FontStyle newStyle, bool IsAdd);
    public class ContextOperator:BaseOperator
    {
        [DllImport("user32.Dll")]
        private static extern bool GetCaretPos(out Point pos);

        private const string ContextInfoTableName = "ContextInfo";
        private const string TreeViewDataTableName = "ContextTree";
        /// <summary>
        /// rich text box default font
        /// </summary>
        private Font RichTextBoxDefaultFont = new Font("Arial", 10);

        /// <summary>
        ///  the RTF Value when the ContextEmpty
        /// </summary>
        private const string ContextEmptyRTF = "{\\rtf1\\ansi\\ansicpg1252\\deff0\\deflang1033\\uc1 }\r\n";
        #region StartFindPosition
        private int FindPosition;

        #region StartFindPosition
        /// <summary>
        /// the start position of the order select
        /// </summary>
        private int startFindPosition;
        public int StartFindPosition
        {
            get
            {
                if (TransferRichTextBox.SelectedText != string.Empty)
                {
                    startFindPosition = TransferRichTextBox.SelectionStart + 1;

                }
                else
                {
                    startFindPosition = TransferRichTextBox.SelectionStart;
                }

                return startFindPosition;
            }

        }
#endregion

        #endregion 

        /// <summary>
        /// the access databse
        private AccessDatabase ADB = new AccessDatabase();

        public event OpenNewRichTextBox OpenNewRTB;
        /// <summary>
        /// when the function keydown<Ctrl+B> on the richtextbox , change the font of selectionText
        /// </summary>
        public event ChangeRichtextboxFont ChangeContextFont;

        #region IsCurrentRichTextBoxChanged
        private bool IsCurrentRichTextBoxChanged(TabPage TPage)
        {
            bool ischanged = false;
            ContextBaseInfo bi = (ContextBaseInfo)TPage.Tag;
            if (bi != null && bi.IsChanged)
            {
                ischanged = true;
            }
            return ischanged;

        }
        #endregion 
        
        #region IsAllRichtextboxsChanged
        private bool IsAllRichtextboxsChanged()
        {
            bool ischanged = false;
            foreach (TabPage tp in this.RightMainForm.TabPages)
            {
                if (IsCurrentRichTextBoxChanged(tp))
                {
                    ischanged = true;
                    break;
                }
 
            }
            return ischanged;

        }
        #endregion 

        #region SelectedRichTextBox
        /// <summary>
        /// the selected RichTextbox
        /// </summary>
        public CustomRichTextBox  SelectedRichTextBox
        {
            get
            {
                CustomRichTextBox  rtb = null;
                TabPage selectedPage = this.RightMainForm.SelectedTab;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        string tabpagePannelID = GetSplitContainerName(cbi.ContextInfoID);
                        string selectedRichTextBoxId = this.GetRichTextBoxName(cbi.ContextInfoID);
                        Control[] ctrls = selectedPage.Controls.Find(selectedRichTextBoxId, true);
                        if (ctrls.Length > 0)
                        {
                            rtb = (CustomRichTextBox)ctrls[0];
                        }
                    }
                }

                return rtb;
                
            }

        }
        #endregion 

        #region SelectedRPGSearchToolBar
        /// <summary>
        /// Selected RPG search toolbar
        /// </summary>
        public BaseSearchBar SelectedRPGSearchToolBar
        {
            get
            {
                BaseSearchBar rpgSearchToolbar = null;
                if (this.RightMainForm.SelectedTab != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)this.RightMainForm.SelectedTab.Tag;
                    string searchtoolbarID = BaseSearchBar.GetSearchToolbarID(cbi.ContextInfoID);
                    Control[] ctrls = this.RightMainForm.SelectedTab.Controls.Find(searchtoolbarID, true);
                    if (ctrls.Length > 0)
                    {
                        rpgSearchToolbar = (BaseSearchBar)ctrls[0];
                    }
                }
                return rpgSearchToolbar;
            }
        }
        #endregion 

        #region SelectedSplitContainerInTabPage
        /// <summary>
        /// the selected splitContainer in the Tappage
        /// </summary>
        public SplitContainer SelectedSplitContainerInTabPage
        {
            get 
            {
                SplitContainer selectedSplitContainer = null;
                TabPage selectedPage = this.RightMainForm.SelectedTab;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        string tabpagePannelID = GetSplitContainerName(cbi.ContextInfoID);

                        selectedSplitContainer = (SplitContainer)selectedPage.Controls[tabpagePannelID];
                    }
                }

                return selectedSplitContainer;

            }
        }
        #endregion 

        #region SelectedRPGTool
        /// <summary>
        /// the selected splitContainer in the Tappage
        /// </summary>
        public RPGTool SelectedRPGTool
        {
            get
            {
                RPGTool currentrpgTool = null;
                TabPage selectedPage = this.RightMainForm.SelectedTab;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        string tabpagePannelID = GetSplitContainerName(cbi.ContextInfoID);
                        string selectedRPGtoolId = GetRPGToolName(cbi.ContextInfoID);
                        currentrpgTool = (RPGTool)(((SplitContainer)selectedPage.Controls[tabpagePannelID]).Panel2.Controls[selectedRPGtoolId]);
                    }
                }

                return currentrpgTool;

            }
        }
        #endregion 
        
        #region GetRichTextBoxFromTabPage
        /// <summary>
        /// get richtextbox from tabpage
        /// </summary>
        /// <returns></returns>
        public CustomRichTextBox GetRichTextBoxFromTabPage(TabPage CertainTabPage)
        {
            CustomRichTextBox rtb = null;
            TabPage currentPage = CertainTabPage;
            if (currentPage != null)
            {
                ContextBaseInfo cbi = (ContextBaseInfo)currentPage.Tag;
                if (cbi != null)
                {
                    string tabpagePannelID = GetSplitContainerName(cbi.ContextInfoID);
                    string selectedRichTextBoxId = this.GetRichTextBoxName(cbi.ContextInfoID);
                    Control[] ctrls = currentPage.Controls.Find(selectedRichTextBoxId, true);
                    if (ctrls.Length > 0)
                    {
                        rtb = (CustomRichTextBox)ctrls[0];
                    }
                }
            }

            return rtb;

        }
        #endregion 

        public string SelectedContextInfoID
        {
            get
            {
                string ContextID = null;
                TabPage selectedPage = this.RightMainForm.SelectedTab;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        ContextID = cbi.ContextInfoID;
                    }
                }

                return ContextID;
            }


        }
        #region TapPageContextMenu
        private ContextMenuStrip tapPageContextMenu;
        /// <summary>
        /// the contextmenu of the tabpage except the start page
        /// </summary>
        public ContextMenuStrip TapPageContextMenu
        {
            get { return tapPageContextMenu; }
            set { tapPageContextMenu = value; }
        }


        
        #endregion 


        #region RTBContextMenu
        private ContextMenuStrip rtbContextMenu;
        /// <summary>
        /// the contextmenu of the tabpage except the start page
        /// </summary>
        public ContextMenuStrip RTBContextMenu
        {
            get { return rtbContextMenu; }
            set { rtbContextMenu = value; }
        }
        #endregion

        private StatusStrip currentStatusStrip;
        public StatusStrip CurrentStatusStrip
        {
            get { return currentStatusStrip; }
            set
            {
                currentStatusStrip = value; 
            }
        }


        /// <summary>
        ///  the operator of the right form
        /// </summary>
        /// <param name="TCRichTextBox">the tabcontrol of the right form</param>
        public ContextOperator(TabControl TCRichTextBox, ContextMenuStrip PageContextMenu,
            ContextMenuStrip ContentContextMenu,StatusStrip StatusStripControl)
        {
            this.RightMainForm = TCRichTextBox;
            this.TapPageContextMenu = PageContextMenu;
            this.RTBContextMenu = ContentContextMenu;
            this.CurrentStatusStrip = StatusStripControl;
            InitialEvent();

        }

        #region InitialEvent
        /// <summary>
        /// InitialEvent
        /// </summary>
        private void InitialEvent()
        {
            this.RightMainForm.SelectedIndexChanged += new EventHandler(RightMainForm_GotFocus);

        }
        #endregion

        #region RightMainForm_GotFocus
        void RightMainForm_GotFocus(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                this.SelectedRichTextBox.Focus();
            }
        }
        #endregion 

        #region GetAllChangeTabPages
        /// <summary>
        /// get tabpages which are changed
        /// </summary>
        /// <returns></returns>
        public List<ContextBaseInfo> GetAllChangedTabPages()
        {
            List<ContextBaseInfo> Listchanged = new List<ContextBaseInfo>();
            
            foreach (TabPage tb in this.RightMainForm.TabPages)
            {
                ContextBaseInfo cbi = (ContextBaseInfo)tb.Tag;
                if (cbi != null && cbi.IsChanged)
                {
                    Listchanged.Add(cbi);
                }
            }

            return Listchanged;

        }
        /// <summary>
        /// get tabpages which are changed
        /// </summary>
        /// <returns></returns>
        public List<ContextBaseInfo> GetAllChangedTabPages(TabPage[] TabPages)
        {
            List<ContextBaseInfo> Listchanged = new List<ContextBaseInfo>();

            foreach (TabPage tb in TabPages)
            {
                ContextBaseInfo cbi = (ContextBaseInfo)tb.Tag;
                if (cbi !=null &&cbi.IsChanged)
                {
                    Listchanged.Add(cbi);
                }
            }

            return Listchanged;

        }
        #endregion 

        #region GetRichTextBoxName
        /// <summary>
        /// get the rich text box name
        /// </summary>
        /// <param name="ContextInfoId"></param>
        /// <returns></returns>
        public string GetRichTextBoxName(string ContextInfoId)
        {
            return "RTB" + ContextInfoId;

        }

        public static string ConstructRichTextBoxName(string ContextInfoId)
        {
            return "RTB" + ContextInfoId;

        }
        #endregion 

        #region GetRichTextBoxName
        /// <summary>
        /// get the RPG tool  name
        /// </summary>
        /// <param name="ContextInfoId"></param>
        /// <returns></returns>
        public static string GetRPGToolName(string ContextInfoId)
        {
            return "RPG" + ContextInfoId;

        }
        #endregion 

        #region GetSplitContainerInTabPageID
        /// <summary>
        /// get the Name of SplitContainer in tabpage
        /// </summary>
        /// <param name="ContextInfoId"></param>
        /// <returns></returns>
        public static string GetSplitContainerName(string ContextInfoId)
        {
            return "SPL" + ContextInfoId;
        }
        /// <summary>
        /// get  the Name of SplitContainer for the main richtextbox and searchtoolbar
        /// </summary>
        /// <param name="ContextInfoId"></param>
        /// <returns></returns>
        public static string GetContextSplitContainerName(string ContextInfoId)
        {
            return "CTX" + ContextInfoId;
        }
        #endregion 

        #region GetTabPageName
        /// <summary>
        /// get the rich text box name
        /// </summary>
        /// <param name="ContextInfoId"></param>
        /// <returns></returns>
        public string GetTabPageName(string ContextInfoId)
        {
            //context tabpage
            return "CTP" + ContextInfoId;

        }
        #endregion 

        #region OpenContext

        /// <summary>
        /// open context page
        /// </summary>
        /// <param name="ContextInfoID">contextInfoid</param>
        public void OpenContext(TreeNode OpenNode)
        {

            TreeNodeInfo nodeinfo = (TreeNodeInfo)OpenNode.Tag;
            string ContextInfoID = nodeinfo.ContextTreeID;
            string PageTile = OpenNode.Text;
            TabPage checkedTabPage = CheckTabPageIsOPened(ContextInfoID);
            //the the tabpage is exist, selected it
            if (checkedTabPage != null )
            {
                this.RightMainForm.SelectedTab = checkedTabPage;
            }
            else
            {
                //get the richtext information from database 
                DataRow contextDr = this.LoadContextData(ContextInfoID);
                TabPage newPage = CreateNewPage(OpenNode);
                this.RightMainForm.TabPages.Add(newPage);

                SplitContainer tabpageContainer = CreatSplitContainerInTabPage(ContextInfoID);
                SplitContainer contextContaner = CreatContextSplitContainer(tabpageContainer, ContextInfoID);
                CustomRichTextBox rbx = new CustomRichTextBox();
                contextContaner.Panel2.Controls.Add(rbx);
                newPage.Controls.Add(tabpageContainer);
                InitializeNewRichTextbox(rbx, ContextInfoID);
                this.RightMainForm.SelectedTab = newPage;
                //invoke the event
                OpenNewRTB.Invoke(rbx);
 
            }

        }

        #endregion

        #region OpenSearchContext
        /// <summary>
        /// open Search context page
        /// and set the seach key word back color
        /// </summary>
        /// <param name="ContextInfoID">contextInfoid</param>
        public void OpenSearchContext(TreeNode OpenNode, string SearchKeyWord)
        {
            
            TreeNodeInfo nodeinfo = (TreeNodeInfo)OpenNode.Tag;
            string ContextInfoID = nodeinfo.ContextTreeID;
            string PageTile = OpenNode.Text;
            TabPage checkedTabPage = CheckTabPageIsOPened(ContextInfoID);
            
            //the the tabpage is exist, selected it
            if (checkedTabPage != null)
            {
                this.RightMainForm.SelectedTab = checkedTabPage;
                TransferRichTextBox.Rtf = this.SelectedRichTextBox.Rtf;
               
                //clear the former search key word backcolor
                if (this.SelectedRichTextBox.Tag !=null)
                {
                    TransferRichTextBox.SelectionStart = 0;
                    ClearSearchKeyWordBackColor(this.SelectedRichTextBox.Tag.ToString());
                }
                //Set the current search key word backColor
                TransferRichTextBox.SelectionStart = 0;
                TransferRichTextBox.SelectionLength = 0;
                SetSearchKeyWordBackColor(SearchKeyWord);
                this.SelectedRichTextBox.Tag = SearchKeyWord;
                this.SelectedRichTextBox.Rtf = TransferRichTextBox.Rtf;
            }
            else
            {
                //get the richtext information from database 
                DataRow contextDr = this.LoadContextData(ContextInfoID);
                TabPage newPage = CreateNewPage(OpenNode);
                this.RightMainForm.TabPages.Add(newPage);
                SplitContainer tabpageContainer = CreatSplitContainerInTabPage(ContextInfoID);
                SplitContainer contextContaner = CreatContextSplitContainer(tabpageContainer, ContextInfoID);
                CustomRichTextBox rbx = new CustomRichTextBox();
                contextContaner.Panel2.Controls.Add(rbx);
                newPage.Controls.Add(tabpageContainer);
                InitializeNewRichTextbox(rbx, ContextInfoID, SearchKeyWord);
                //newPage.Controls.Add(rbx);
                this.RightMainForm.SelectedTab = newPage;
                //invoke the event
                OpenNewRTB.Invoke(rbx);

            }



        }
        #endregion 

        #region OpenSearchContext
        /// <summary>
        /// open Search context page
        /// and set the seach key word back color
        /// </summary>
        /// <param name="ContextInfoID">contextInfoid</param>
        public void OpenSearchContext(string NodeText, string ContextInfoID, string FullPath, string SearchKeyWord)
        {

            string PageTile = NodeText;
            TabPage checkedTabPage = CheckTabPageIsOPened(ContextInfoID);

            //the the tabpage is exist, selected it
            if (checkedTabPage != null)
            {
                this.RightMainForm.SelectedTab = checkedTabPage;
                TransferRichTextBox.Rtf = this.SelectedRichTextBox.Rtf;

                //clear the former search key word backcolor
                if (this.SelectedRichTextBox.Tag != null)
                {
                    TransferRichTextBox.SelectionStart = 0;
                    ClearSearchKeyWordBackColor(this.SelectedRichTextBox.Tag.ToString());
                }
                //Set the current search key word backColor
                TransferRichTextBox.SelectionStart = 0;
                TransferRichTextBox.SelectionLength = 0;
                SetSearchKeyWordBackColor(SearchKeyWord);
                this.SelectedRichTextBox.Tag = SearchKeyWord;
                this.SelectedRichTextBox.Rtf = TransferRichTextBox.Rtf;
            }
            else
            {
                //get the richtext information from database 
                DataRow contextDr = this.LoadContextData(ContextInfoID);
                TabPage newPage = CreateNewPage(ContextInfoID, NodeText, FullPath);
                this.RightMainForm.TabPages.Add(newPage);
                this.RightMainForm.SelectedTab = newPage;
                SplitContainer tabpageContainer = CreatSplitContainerInTabPage(ContextInfoID);
                SplitContainer contextContaner = CreatContextSplitContainer(tabpageContainer, ContextInfoID);
                CustomRichTextBox rbx = new CustomRichTextBox();
                contextContaner.Panel2.Controls.Add(rbx);
                newPage.Controls.Add(tabpageContainer);
                InitializeNewRichTextbox(rbx, ContextInfoID, SearchKeyWord);
                //invoke the event
                OpenNewRTB.Invoke(rbx);

            }



        }
        #endregion 

        #region CreatSplitContainerInTabPage
        private SplitContainer CreatSplitContainerInTabPage(string ContextInfoID)
        {
            //add the split container to contain the richtextbox
            SplitContainer TabPageContainer = new SplitContainer();
            TabPageContainer.Name = GetSplitContainerName(ContextInfoID);
            TabPageContainer.Dock = DockStyle.Fill;
            TabPageContainer.FixedPanel = FixedPanel.Panel2;
            TabPageContainer.SplitterDistance = 150;
            //hiden the pannel2 first
            TabPageContainer.Panel2Collapsed = true;
            return TabPageContainer;
            //TabPageContainer.SplitterDistance = TabPageContainer.Width;

        }
        #region CreatContextSplitContainer
        /// <summary>
        /// create t split container control for searchtoolbar and richtextbox
        /// </summary>
        /// <returns></returns>
        private SplitContainer CreatContextSplitContainer(SplitContainer TabPageContainer,string ContextInfoID)
        {
            //add the split container to contain the richtextbox
            SplitContainer ContextSplitContainer = new SplitContainer();
            ContextSplitContainer.Name = GetContextSplitContainerName(ContextInfoID);
            ContextSplitContainer.Dock = DockStyle.Fill;
            ContextSplitContainer.IsSplitterFixed = true;
            ContextSplitContainer.FixedPanel = FixedPanel.Panel1;
            ContextSplitContainer.Panel1MinSize = 24;
            ContextSplitContainer.SplitterDistance = 24;
            ContextSplitContainer.SplitterWidth = 1;
            ContextSplitContainer.Orientation = Orientation.Horizontal;
            ContextSplitContainer.Panel1Collapsed = true;
            //hiden the pannel2 first
            TabPageContainer.Panel1.Controls.Add(ContextSplitContainer);
            return ContextSplitContainer;

        }
        #endregion 
        #endregion

        #region SetSearchKeyWordBackColor
        /// <summary>
        /// Set search keyword in richtextbox Context
        /// </summary>
        /// <param name="SearchKeyWord"></param>
        private  void SetSearchKeyWordBackColor(string SearchKeyWord)
        {
            //Reset the search postion
            TransferRichTextBox.SelectionStart = 0;
            FindPosition = 0;
            while (FindPosition != -1)
            {
                // select in order
                int selectStart = StartFindPosition;
                FindPosition = TransferRichTextBox.Find(SearchKeyWord, selectStart, RichTextBoxFinds.None);


                if (FindPosition != -1)
                {
                    //make the the find string in richtextbox selected
                    TransferRichTextBox.Select(FindPosition, SearchKeyWord.Length);
                    TransferRichTextBox.SelectionBackColor = Color.DarkOrange;
                    TransferRichTextBox.SelectionProtected = true;
                }
            }
        }
        #endregion 

        #region ClearSearchKeyWordBackColor
        /// <summary>
        /// Clear Search Keyword the backColor to Transparent;
        /// </summary>
        /// <param name="SearchKeyWord"></param>
        private void ClearSearchKeyWordBackColor(string SearchKeyWord)
        {
            //Reset the search postion
            TransferRichTextBox.SelectionStart = 0;
            FindPosition = 0;
            while (FindPosition != -1)
            {
                // select in order
                int selectStart = StartFindPosition;
                FindPosition = TransferRichTextBox.Find(SearchKeyWord, selectStart, RichTextBoxFinds.None);


                if (FindPosition != -1)
                {
                    
                    //make the the find string in richtextbox selected
                    TransferRichTextBox.Select(FindPosition, SearchKeyWord.Length);
                    TransferRichTextBox.SelectionProtected = false;
                    if (TransferRichTextBox.SelectionBackColor == Color.DarkOrange)
                    {
                    TransferRichTextBox.SelectionBackColor = Color.Transparent;
                    }
                    
                }
            }

        }
        #endregion 

        #region CreateNewPage
        /// <summary>
        /// Create the new TapPage  properties and delegrate
        /// </summary>
        /// <param name="NewPage">new tap page</param>
        private TabPage CreateNewPage(TreeNode OpenNode)
        {
            TabPage newPage = null ;
            TreeNodeInfo nodeinfo = (TreeNodeInfo)OpenNode.Tag;
            string ContextInfoID = nodeinfo.ContextTreeID;
            string PageTile = GetTabTitle(OpenNode.Text);
            newPage = new TabPage(PageTile);
            newPage.Name = GetTabPageName(ContextInfoID);
            newPage.Tag = new ContextBaseInfo(ContextInfoID, PageTile, OpenNode.FullPath,this.RightMainForm);
            newPage.ToolTipText = OpenNode.FullPath;

            return newPage;


        }

        /// <summary>
        /// Create the new TapPage  properties and delegrate
        /// </summary>
        /// <param name="NewPage">new tap page</param>
        private TabPage CreateNewPage(string ContextInfoID, string NodeTitleText, string FullPath)
        {
            TabPage newPage = null;
            string PageTile = GetTabTitle(NodeTitleText);
            newPage = new TabPage(PageTile);
            newPage.Name = GetTabPageName(ContextInfoID);
            newPage.Tag = new ContextBaseInfo(ContextInfoID, PageTile, FullPath, this.RightMainForm);
            newPage.ToolTipText = FullPath;
            return newPage;


        }
        #endregion

        #region GetTabTitle
        /// <summary>
        /// the the short name of tab page
        /// </summary>
        /// <param name="OriginalTitle"></param>
        /// <returns></returns>
        public string GetTabTitle(string OriginalTitle)
        {
            string displayName = OriginalTitle;
            if (OriginalTitle.Length > 20)
            {
                displayName = OriginalTitle.Substring(0, 10);
                displayName += "...";
                displayName += OriginalTitle.Substring(OriginalTitle.Length - 10, 10);
            }
            return displayName;
        }
        #endregion 

        #region InitializeNewRichTextbox
        /// <summary>
        /// intialize the richtextbox
        /// </summary>
        /// <param name="RBX"></param>
        private void InitializeNewRichTextbox(CustomRichTextBox RBX, string ContextInfoID)
        {
            
            //the richtextbox id rule is rtb + contextinfoid
            RBX.Name = this.GetRichTextBoxName(ContextInfoID);
            RBX.Font = RichTextBoxDefaultFont;
            //load the context information of the context
            DataRow dr = this.LoadContextData(ContextInfoID);
            RBX.Rtf = dr["ContextRTF"].ToString();
            RBX.Dock = DockStyle.Fill;
            RBX.HideSelection = false;
            RBX.AcceptsTab = true;
            RBX.AllowDrop = false;
            RBX.WordWrap = true;
            RBX.EnableAutoDragDrop = true;
            RBX.SelectionFont = Configure.DefaultFont;
            //RBX.AcceptsTabChanged += new EventHandler(RBX_AcceptsTabChanged);
            RBX.DragDrop += new DragEventHandler(RBX_DragDrop);
            RBX.DragEnter += new DragEventHandler(RBX_DragEnter);
            RBX.LinkClicked += new LinkClickedEventHandler(RBX_LinkClicked);
            RBX.SelectionChanged += new EventHandler(RBX_SelectionChanged);
            RBX.MouseUp += new MouseEventHandler(RBX_MouseUp);
            RBX.ContextMenuStrip = this.RTBContextMenu;
            RBX.TextChanged += new EventHandler(RBX_TextChanged);
            RBX.KeyDown += new KeyEventHandler(RBX_KeyDown);
        }

        private void InitializeNewRichTextbox(CustomRichTextBox RBX, string ContextInfoID, string SearchKeyWord)
        {
            RBX.Dock = DockStyle.Fill;
            RBX.HideSelection = false;
            RBX.WordWrap = true;
            RBX.EnableAutoDragDrop = true;
            RBX.DragEnter += new DragEventHandler(RBX_DragEnter);
            RBX.SelectionChanged += new EventHandler(RBX_SelectionChanged);
            RBX.ContextMenuStrip = this.RTBContextMenu;
            RBX.Font = RichTextBoxDefaultFont;
            //the richtextbox id rule is rtb + contextinfoid
            RBX.Name = this.GetRichTextBoxName(ContextInfoID);
            //load the context information of the context
            DataRow dr = this.LoadContextData(ContextInfoID);
            TransferRichTextBox.Rtf = dr["ContextRTF"].ToString();
            SetSearchKeyWordBackColor(SearchKeyWord);
            RBX.Rtf = TransferRichTextBox.Rtf;
            //keep the search key word
            RBX.Tag = SearchKeyWord;
            RBX.SelectionFont = Configure.DefaultFont;
            RBX.TextChanged += new EventHandler(RBX_TextChanged);
            RBX.MouseUp += new MouseEventHandler(RBX_MouseUp);
            RBX.KeyDown += new KeyEventHandler(RBX_KeyDown);
            //clear the memory
            TransferRichTextBox.Clear();
        }

        /// <summary>
        /// key down on the richtextbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void RBX_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.B)
            {   
                bool isadd = this.SelectedRichTextBox.SelectionFont == null ? true:!this.SelectedRichTextBox.SelectionFont.Bold;
                this.ChangeContextFont.Invoke(FontStyle.Bold, isadd);
            }
            else if(e.Control && e.KeyCode == Keys.U)
            {
                bool isadd = this.SelectedRichTextBox.SelectionFont == null ? true : !this.SelectedRichTextBox.SelectionFont.Underline;
                this.ChangeContextFont.Invoke(FontStyle.Underline, isadd);
            }
            else if (e.Control && e.KeyCode == Keys.I)
            {
                bool isadd = this.SelectedRichTextBox.SelectionFont == null ? true : !this.SelectedRichTextBox.SelectionFont.Italic;
                this.ChangeContextFont.Invoke(FontStyle.Italic, isadd);
            }
        }

        void RBX_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && this.SelectedRichTextBox.Cursor != Cursors.IBeam)
            {
                //fomat paint
                if (this.SelectedRichTextBox.Cursor != Cursors.IBeam )
                {
                    CustomRichTextBox interRTB = new CustomRichTextBox();
                    interRTB.Rtf = this.SelectedRichTextBox.SelectedRtf.ToString();
                    interRTB.SelectAll();
                    if (ToolBarOperator.PaintFormat.PaintFont != null)
                        interRTB.SelectionFont = ToolBarOperator.PaintFormat.PaintFont;

                    interRTB.SelectionColor = ToolBarOperator.PaintFormat.FontColor;
                    interRTB.SelectionBackColor = ToolBarOperator.PaintFormat.BackGroudColor;
                    //interRTB.SelectionBullet = ToolBarOperator.PaintFormat.IsBullet;
                    this.SelectedRichTextBox.SelectedRtf = interRTB.SelectedRtf.ToString();
                    this.SelectedRichTextBox.SelectionBullet = ToolBarOperator.PaintFormat.IsBullet;
                    //this.SelectedRichTextBox.Focus();

                }
                //Rollback cursor
                this.SelectedRichTextBox.Cursor = Cursors.IBeam;
 
            }
        }

        void RBX_LinkClicked(object sender, LinkClickedEventArgs e)
        {
            string linkString = e.LinkText;
            Process.Start("IExplore.exe",linkString); 
        }

        void RBX_DragDrop(object sender, DragEventArgs e)
        {
            if (this.SelectedRichTextBox.SelectedRtf != ContextEmptyRTF && this.SelectedRichTextBox.SelectedText.Trim() != string.Empty)
            {
                e.Effect = DragDropEffects.Move;
            }
               
            
        }


        /// <summary>
        /// press tab keybord
        /// </summary>
        /// <param name="RBX"></param>
        private void TabKeyDown(RichTextBox RBX)
        {

            int selLength = RBX.SelectionLength;
            if (selLength == 0) return;
            // Ensure selection starts at beginning of line 
            int line = RBX.GetLineFromCharIndex(RBX.SelectionStart);
            int lineStart = RBX.GetFirstCharIndexFromLine(line);
            if (lineStart < RBX.SelectionStart)
            {
                selLength += RBX.SelectionStart - lineStart;
                RBX.SelectionStart = lineStart;
                RBX.SelectionLength = selLength;
            }
            // Insert a tab before every line 
            string[] lines = RBX.SelectedText.Split('\n');
            for (int ix = 0; ix < lines.Length; ++ix)
                lines[ix] = "\t" + lines[ix];
            string selectText = string.Join("\n", lines);
            RBX.SelectedText = selectText;
            // Reselect previous text 
            RBX.SelectionStart = lineStart;
            RBX.SelectionLength = selLength + lines.Length;
            RBX.Focus(); 
        }

        #region RBX_SelectionChanged
        /// <summary>
        /// tips the line number and colum number
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void RBX_SelectionChanged(object sender, EventArgs e)
        {
            //if (this.SelectedRichTextBox != null)
            //{
            CustomRichTextBox selectedRTB = this.SelectedRichTextBox;
            int startIndex = selectedRTB.SelectionStart;
            int firstCharIndexInCurrentLine = selectedRTB.GetFirstCharIndexOfCurrentLine();
            int columnNum = startIndex - firstCharIndexInCurrentLine;
            int linenum = selectedRTB.GetLineFromCharIndex(firstCharIndexInCurrentLine);
            ((ToolStripLabel)this.CurrentStatusStrip.Items["TSSLLineNum"]).Text = "Line:" + linenum.ToString();
            ((ToolStripLabel)this.CurrentStatusStrip.Items["TSSLColumnNum"]).Text = "Column:" + columnNum.ToString();
            //}
        }
        #endregion 

        /// <summary>
        /// drag rich text , move it to current Richtextbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void RBX_DragEnter(object sender, DragEventArgs e)
        {
            if (this.SelectedRichTextBox.SelectedRtf != ContextEmptyRTF)
                e.Effect = DragDropEffects.Move;
            
        }

        void RBX_TextChanged(object sender, EventArgs e)
        {
            CustomRichTextBox  RBX = (CustomRichTextBox) sender;
            TabPage tp = this.RightMainForm.SelectedTab;
            ContextBaseInfo cbi = (ContextBaseInfo)tp.Tag;
            //if the text first changed, and * character to the page title
            if (cbi.ContextDisplayName == cbi.ContextNodeTitle)
            { 
                tp.Text += "*";
                cbi.ContextDisplayName = tp.Text;
            }
            


        }
        #endregion 

        #region IsTabPageOPened
        /// <summary>
        /// check whether the certain tabpage opened
        /// </summary>
        /// <param name="ContextInfoID">the contextid </param>
        /// <returns></returns>
        private TabPage CheckTabPageIsOPened(string ContextInfoID)
        {
            TabPage checkedTabPage = null;
            //check whether the tabpage is already opeded
            foreach (TabPage tb in this.RightMainForm.TabPages)
            {
                ContextBaseInfo cbi = (ContextBaseInfo)tb.Tag;
                if (cbi != null && cbi.ContextInfoID == ContextInfoID)
                {
                    checkedTabPage = tb;
                }

            }
            return checkedTabPage;


        }
        #endregion 

        #region CloseSelectedTab
        /// <summary>
        /// Close current tabpage
        /// </summary>
        public void CloseSelectedTab()
        {
            if (this.RightMainForm.SelectedTab != null)
            {
                int tabpageIndex = this.RightMainForm.SelectedIndex;
                TabPage[] tabpages = new TabPage[] { this.RightMainForm.SelectedTab };
                this.CloseTabPages(tabpages);
                //this.SetSelectionTabPageAfterCloseAction(tabpageIndex);

            }


        }
        #endregion 

        #region CloseTabPages
        /// <summary>
        /// Close TabPages 
        /// </summary>
        /// <param name="CloseTabPages">the certain tabpages</param>
        public bool CloseTabPages(TabPage[] CloseTabPages)
        {
            bool IsClose = true;
            //if no tabpages ,no action
            if (CloseTabPages == null && CloseTabPages.Length == 0)
            {
                throw(new Exception("no tabpage referenced"));
            }

            List<ContextBaseInfo> changedItems = GetAllChangedTabPages(CloseTabPages);
            if (changedItems.Count > 0)
            {
                CloseConfirm saveConfirm = new CloseConfirm(changedItems);
                DialogResult drslt = saveConfirm.ShowDialog();
                if (drslt == DialogResult.Yes)
                {
                    foreach (TabPage tp in CloseTabPages)
                    {
                        //save and close tappages
                        this.SavePageContextData(tp);
                        SetSelectionTabPageBeforeCloseAction(FindIndex(tp));
                        this.RightMainForm.TabPages.Remove(tp);
                    }

                }
                else if (drslt == DialogResult.No)
                {
                    foreach (TabPage tp in CloseTabPages)
                    {
                        // close tappages
                        SetSelectionTabPageBeforeCloseAction(FindIndex(tp));
                        this.RightMainForm.TabPages.Remove(tp);
                    }

                }
                else if (drslt == DialogResult.Cancel)
                {
                    IsClose = false;
                }
                //when user click cancel button  , do nothing

            }
            else
            {
                // if all tabpage has no changes
                foreach (TabPage tp in CloseTabPages)
                {
                    // close tappages
                    SetSelectionTabPageBeforeCloseAction(FindIndex(tp));
                    this.RightMainForm.TabPages.Remove(tp);
                }
 
            }
            return IsClose;

        }
        #endregion 

        #region CloseAllButThis
        public void CloseAllButThis()
        {
            if (this.RightMainForm.TabPages.Count-1 > 0)
            {
                //the count is equal to n-1
                //because except the current selected tabpage
                TabPage[] tabpages = new TabPage[this.RightMainForm.TabPages.Count-1];
                for (int i = 0 ,j=0; i < this.RightMainForm.TabPages.Count; i++)
                {
                    if (this.RightMainForm.TabPages[i] !=  this.RightMainForm.SelectedTab)
                    {
                        //when j is set, j++;
                        tabpages[j] = this.RightMainForm.TabPages[i];
                        j++;
                    }

                }
                this.CloseTabPages(tabpages);

            }

        }
        #endregion 

        #region CloseAllTabPages
        /// <summary>
        /// Close all the tabPages
        /// </summary>
        /// <returns>Is user Confirm to close </returns>
        public bool CloseAllTabPages()
        {
            bool isClose = false;
            if (this.RightMainForm.TabPages.Count > 0)
            {
                TabPage[] tabpages = new TabPage[this.RightMainForm.TabPages.Count];
                for (int i = 0; i < this.RightMainForm.TabPages.Count; i++)
                {
                    tabpages[i] = this.RightMainForm.TabPages[i];

                }
                isClose = this.CloseTabPages(tabpages);

            }
            else
            {
                isClose = true;
            }
            return isClose;

        }
        #endregion 

        #region RemoveTapPage
        /// <summary>
        /// remove the tap page from tab control by contextid without save
        /// </summary>
        /// <param name="ContextInfoId"></param>
        public void RemoveTapPage(string ContextInfoId)
        {
            TabPage tb = this.RightMainForm.TabPages[this.GetTabPageName(ContextInfoId)];
            if (tb != null)
            {
                this.RightMainForm.TabPages.Remove(tb);
            }

        }
        #endregion 

        #region SetMostRightTabPageSelected
        private void SetSelectionTabPageAfterCloseAction(int TabpageClosedIndex)
        {
            if (this.RightMainForm.TabPages.Count > 0)
            {
                int selctionIndex = TabpageClosedIndex == this.RightMainForm.TabPages.Count ? TabpageClosedIndex - 1 : TabpageClosedIndex;
                this.RightMainForm.SelectedTab = this.RightMainForm.TabPages[selctionIndex];
            }

        }
        private void SetSelectionTabPageBeforeCloseAction(int TabpageClosedIndex)
        {
            if (this.RightMainForm.TabPages.Count > 1)
            {
                int selctionIndex = TabpageClosedIndex == this.RightMainForm.TabPages.Count-1 ? TabpageClosedIndex - 1 : TabpageClosedIndex+1;
                this.RightMainForm.SelectedTab = this.RightMainForm.TabPages[selctionIndex];
            }


        }
        #endregion SetMostRightTabPageSelected

        #region SaveCurrentPageContextData
        /// <summary>
        /// Save the context infomation 
        /// </summary>
        public void SaveCurrentPageContextData()
        {
            if (this.RightMainForm.SelectedTab != null)
            {
                if (this.IsCurrentRichTextBoxChanged(this.RightMainForm.SelectedTab))
                {
                    //((ToolStripStatusLabel)this.CurrentStatusStrip.Items["TSSBSave"]).Visible = true;
                    SavePageContextData(this.RightMainForm.SelectedTab);
                   
                }
            }

        }
        #endregion 

        #region AddNewIndexForContext
        /// <summary>
        /// add a new Index value for current RichTextbox   
        /// </summary>
        /// <param name="IndexValue">Index value</param>
        public void AddNewIndexForContext(string IndexValue)
        {
            if (!string.IsNullOrEmpty(IndexValue))
            {
                string ContextInfoId = ((ContextBaseInfo)this.RightMainForm.SelectedTab.Tag).ContextInfoID;
                string updateNodeSqlText = string.Format("Select * From {0} where ContextTreeID = '{1}' ", TreeViewDataTableName, ContextInfoId);
                using (OleDbConnection connection = AccessDatabase.CreateConnnection())
                {
                    string sqlText = string.Format("Select * from {0} where contextInfoId = '{1}'", ContextInfoTableName, ContextInfoId);
                    DataSet ds = this.ADB.ExecuteDataSet(sqlText, ContextInfoTableName);
                    DataRow dr = ds.Tables[0].Rows[0];

                    dr["IndexString"] = dr["IndexString"].ToString() + " " + IndexValue;
                    dr["UpdateTime"] = DateTime.Now;
                    this.ADB.UpdateDataSet(ds);

                }
            }


        }
        #endregion 

        #region RenewTabPageState
        /// <summary>
        /// renew the TabPage state by ContextBaseInfo ContextNodeTitle
        /// </summary>
        /// <param name="tp">the tabpage which need to be renew</param>
        public void RenewTabPageState(TabPage tp)
        {
            ContextBaseInfo bi = (ContextBaseInfo)tp.Tag;
            if (bi != null)
            {
                bi.ContextDisplayName = bi.ContextNodeTitle;
                tp.Text = this.GetTabTitle(bi.ContextNodeTitle);
            }

        }
        #endregion 

        #region SaveSingalPageContextData
        /// <summary>
        /// save singal page richtextbox
        /// </summary>
        /// <param name="ContextInfoId"></param>
        /// <param name="RTX"></param>
        private void SaveSingalPageContextData(TabPage SavePage)
        {

            Thread tdSave = new Thread(new ParameterizedThreadStart(this.MiddleThreadPageContextData));
            tdSave.Start((object)SavePage);

        }

        private void MiddleThreadPageContextData(object SavePage)
        {
            if (this.CurrentStatusStrip.InvokeRequired)
            {
                Thread.Sleep(1);
                SaveTabPageData d = new SaveTabPageData(MiddleThreadPageContextData);
                this.RightMainForm.Invoke(d, new object[] { SavePage });
            }
            else
            {
                this.SavePageContextData((TabPage)SavePage);
                RenewTabPageState((TabPage)SavePage);
               ((ToolStripStatusLabel)this.CurrentStatusStrip.Items["TSSBSave"]).Visible = false;
            }
        }

        private void SavePageContextData(TabPage SavePage)
        {
            ContextBaseInfo bi = (ContextBaseInfo)SavePage.Tag;
            //if not start page ,save it 
            if (bi != null)
            {
                CustomRichTextBox RTX = GetRichTextBoxFromTabPage(SavePage);
                string ContextInfoId = bi.ContextInfoID;
                if (bi.IsChanged)
                {

                    string sqlText = string.Format("Select * from {0} where contextInfoId = '{1}'", ContextInfoTableName, ContextInfoId);
                    DataSet ds = this.ADB.ExecuteDataSet(sqlText, ContextInfoTableName);
                    DataRow dr = ds.Tables[0].Rows[0];
                    TransferRichTextBox.Rtf = RTX.Rtf;
                    //if the richtextbox is a full text searched  box
                    if (RTX.Tag != null)
                    {
                        this.ClearSearchKeyWordBackColor(RTX.Tag.ToString());
                    }
                    dr["ContextRTF"] = TransferRichTextBox.Rtf;
                    dr["ContextText"] = TransferRichTextBox.Text;
                    dr["UpdateTIme"] = DateTime.Now;
                    this.ADB.UpdateDataSet(ds);
                    //renew the title
                    RenewTabPageState((TabPage)SavePage);
                }
            }
           
        }
        #endregion 

        #region SaveAllPagesContextData
        /// <summary>
        /// save all changed text to access database 
        /// </summary>
        public void SaveAllPagesContextData()
        {
            if (this.IsAllRichtextboxsChanged())
            {
                //((ToolStripStatusLabel)this.CurrentStatusStrip.Items["TSSBSave"]).Visible = true;
                //TODO: should be optimized ,all rocord should be update one time
                foreach (TabPage tp in this.RightMainForm.TabPages)
                {
                    SavePageContextData(tp);
                }
            }

        }
        #endregion 

        #region LoadContextData
        /// <summary>
        /// load the context data from the context id
        /// </summary>
        public DataRow LoadContextData(string ContextInfoId)
        {
            string sqlText = string.Format("Select * from {0} where contextInfoId = '{1}'", ContextInfoTableName, ContextInfoId);
            DataSet ds = this.ADB.ExecuteDataSet(sqlText, ContextInfoTableName);

            return ds.Tables[0].Rows[0];


        }
        #endregion 

        #region RefreshRichTextBox
        /// <summary>
        /// Refresh the current Selected RichTextbox
        /// after full text Search
        /// </summary>
        public void RefreshRichTextBox()
        {
            if (this.SelectedRichTextBox.Tag != null)
            {
                TransferRichTextBox.Rtf = this.SelectedRichTextBox.Rtf;
                this.ClearSearchKeyWordBackColor(this.SelectedRichTextBox.Tag.ToString());
                this.SelectedRichTextBox.Clear();
                this.SelectedRichTextBox.Rtf = TransferRichTextBox.Rtf;
                ContextBaseInfo cbi = (ContextBaseInfo)this.RightMainForm.SelectedTab.Tag;
                //bool ischanged = cbi.IsChanged;
                TransferRichTextBox.Clear();
            }
            else
            {
                this.SelectedRichTextBox.SelectionStart = 0;
            }


        }
        #endregion 

        #region ShowRPGToolbar
        /// <summary>
        ///  Show RPG tool bar 
        /// </summary>
        public  void ShowRPGToolbar()
        {
            if (this.SelectedRPGTool != null)
            {
                this.SelectedSplitContainerInTabPage.Panel2Collapsed = false;
            }

        }
        #endregion 

        #region CloseRPGToolBar
        /// <summary>
        /// Hide RPG too bar
        /// </summary>
        public  void CloseRPGToolBar()
        {
            if (this.SelectedRPGTool != null)
            {
                this.SelectedSplitContainerInTabPage.Panel2Collapsed = true;
            }
        }
        #endregion 

        #region FindIndex
        /// <summary>
        /// Loops over all the TabPages to find the index of the given TabPage.
        /// </summary>
        /// <param name="page">The TabPage we want the index for.</param>
        /// <returns>The index of the given TabPage(-1 if it isn't found.)</returns>
        private int FindIndex(TabPage page)
        {
            for (int i = 0; i < this.RightMainForm.TabPages.Count; i++)
            {
                if (this.RightMainForm.TabPages[i] == page)
                    return i;
            }

            return -1;
        }
        #endregion 
    }
}
