using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using System.Data.Common;
using GLTc.NoteLib;
using GLTc.QuickNote;

namespace GLTc.QuickNote.Command
{   

    /// <summary>
    /// Full text search
    /// </summary>
    public class SearchOperator
    {

        private TabPage currentSearchTablePage;
        /// <summary>
        /// the search tabpage of left window
        /// </summary>
        public TabPage CurrentSearchTablePage
        {
            get { return currentSearchTablePage; }
            set { currentSearchTablePage = value; }
        }

        private TextBox searchTextBox;
        /// <summary>
        /// Search text box 
        /// </summary>
        public TextBox SearchTextBox
        {
            get {
                if (this.searchTextBox == null)
                {
                    this.searchTextBox = (TextBox)this.CurrentSearchTablePage.Controls["SearchTableLayOut"].Controls["TPSearchCondition"];
                }

                return searchTextBox; 
            }
   
        }

        private ListBox searchListBox;
        /// <summary>
        /// Search list view
        /// </summary>
        public ListBox SearchListBox
        {
            get
            {
                if (this.searchListBox == null)
                {
                    this.searchListBox = (ListBox)this.CurrentSearchTablePage.Controls["SearchTableLayOut"].Controls["TPSearchListBox"];
                }

                return searchListBox;
            }

        }
        private Label lbSearchResultTips;
        /// <summary>
        /// Search list view
        /// </summary>
        public Label LBSearchResultTips
        {
            get
            {
                if (this.lbSearchResultTips == null)
                {
                    this.lbSearchResultTips = (Label)this.CurrentSearchTablePage.Controls["SearchTableLayOut"].Controls["LBSearchResultTips"];
                }

                return lbSearchResultTips;
            }

        }

        #region RightMainForm
        private ContextOperator currentContextOperator;
        /// <summary>
        /// the right tabcontrol of the main form
        /// for display the multi richtextboxes
        /// </summary>
        public ContextOperator CurrentContextOperator
        {
            get { return currentContextOperator; }
            set { currentContextOperator = value; }
        }
        #endregion 

        public TreeView CurrentTree ;

        private static AccessDatabase adb;
        /// <summary>
        /// the access databse
        /// </summary>
        private AccessDatabase ADB
        {
            get 
            {
                if (adb == null)
                {
                    adb = new AccessDatabase();
                }
                return adb;
            }
        }

        #region InitalEvent
        private void InitalEvent()
        {
            this.SearchListBox.DoubleClick += new EventHandler(SearchListBox_DoubleClick);
        }
        #endregion 

        #region Constructor
        public SearchOperator(TabPage SearchTablePage, ContextOperator RightContextOperator, TreeView LeftTreeOpertor)
        {
            this.CurrentSearchTablePage = SearchTablePage;
            this.CurrentContextOperator = RightContextOperator;
            this.CurrentTree = LeftTreeOpertor;
           
            InitalEvent();
        }
        #endregion 

        #region SearchListBox_DoubleClick
        void SearchListBox_DoubleClick(object sender, EventArgs e)
        {
            if (this.SearchListBox.SelectedItem != null)
            {
                //SearchItem scItem = (SearchItem)this.SearchListBox.SelectedItem;
                //string nodeName = TreeOperator.GetTreeNodeName(scItem.ContextID);
                //TreeNode[] SearchedNode = this.CurrentTree.Nodes.Find(nodeName, true);
                //TreeNode SearchedNode = BuildSearchTreeNode((SearchItem)this.SearchListBox.SelectedItem);
                string contextId = ((SearchItem)this.SearchListBox.SelectedItem).ContextID;
                string NodeTitle = ((SearchItem)this.SearchListBox.SelectedItem).ShowText;
                string FullPath  =  BuildContextPath(contextId);
                this.CurrentContextOperator.OpenSearchContext(NodeTitle, contextId, FullPath,this.SearchTextBox.Text.Trim().Replace("'", "''"));
            }

        }
        #endregion 

        #region FullTextSearch
        /// <summary>
        /// search through all the database
        /// and display the find list in list view 
        /// </summary>
        public int FullTextSearch()
        {
            string sqlText = string.Format(@"select CI.ContextInfoID ,CT.NodeName  from ContextInfo AS CI Left Join ContextTree AS CT
                                             on CI.ContextInfoID =  CT.ContextTreeID
                                                where CI.ContextText Like '%{0}%' "
                            , this.SearchTextBox.Text.Trim().Replace("'","''"));
            DataSet ds = this.ADB.ExecuteDataSet(sqlText);
            this.SearchListBox.Items.Clear();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                SearchItem scItem = new SearchItem(dr["ContextInfoID"].ToString(), dr["NodeName"].ToString());
                this.SearchListBox.Items.Add(scItem);
            }

            return ds.Tables[0].Rows.Count;
        }
        /// <summary>
        /// search through all the database
        /// return the search result by dataTable
        /// </summary>
        /// <param name="searchkeyword">keyword by search</param>
        /// <returns></returns>
        public DataTable GetFullTextSearchData(string searchkeyword,out Exception SearchException)
        {
            DataTable dt = null;
            SearchException = null;
            try
            {
                string sqlText = string.Format(@"select CI.ContextInfoID ,CT.NodeName  from ContextInfo AS CI Left Join ContextTree AS CT
                                             on CI.ContextInfoID =  CT.ContextTreeID
                                                where CI.ContextText Like '%{0}%' "
                    , searchkeyword.Trim().Replace("'", "''"));
                DataSet ds = this.ADB.ExecuteDataSet(sqlText);
                dt = ds.Tables[0];
            }
            catch (Exception ex)
            {
                SearchException = ex;
            }
            return dt;

 
        }

        #endregion 

        #region BuildContextPath
        /// <summary>
        /// build the the path by ContextID
        /// </summary>
        /// <param name="ContextTreeID"></param>
        /// <returns></returns>
        public static string  BuildContextPath(string ContextTreeID)
        {
            AccessDatabase ADBStatic = new AccessDatabase();
            string sqlText = string.Format("select * from ContextTree");
            DataSet ds = ADBStatic.ExecuteDataSet(sqlText);
            string WholePath = GetConsolidatePath(ds.Tables[0],ContextTreeID);
            return WholePath;

        }
        #endregion 

        #region GetConsolidatePath
        /// <summary>
        /// build the the path by ContextID
        /// </summary>
        /// <param name="table">TreeNode Table</param>
        /// <param name="ContextTreID">TreeNode Id</param>
        /// <returns>whole path
        /// </returns>
        private static string GetConsolidatePath(DataTable table, string ContextTreID)
        {
           string Path = string.Empty;
           DataRow[] DRS  = table.Select(string.Format("ContextTreeID = '{0}'", ContextTreID));
           if (DRS.Length == 1)
           {
               Path += DRS[0]["NodeName"].ToString();
               //if the current Node is not the root note
               if (DRS[0]["NodeTypeID"].ToString() != "0")
               {
                   Path = GetConsolidatePath(table, DRS[0]["ParentID"].ToString()) + @"\" + Path;
               }
 
           }
           return Path;

       }
        #endregion 



   }
}
