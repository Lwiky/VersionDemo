using System;
using System.Collections.Generic;
using System.Text;

namespace GLTc.QuickNote.Command
{
    /// <summary>
    /// store the information of the TreeNode
    /// </summary>
    public class TreeNodeInfo
    {

        public string ContextTreeID;
        public string ParentID;
        /// <summary>
        /// the type of the node 
        /// </summary>
        public int NodeTypeID;

        public string NodeName;

        public string CreatedDate;

        public string UpdatedDate;

        public string FullPath;

        public string IndexInfo;

        public TreeNodeInfo(string contextTreeID, string parentID, int nodeTypeId)
        {
            this.ContextTreeID = contextTreeID;
            this.ParentID = parentID;
            this.NodeTypeID = nodeTypeId;

        }

        public TreeNodeInfo(string contextTreeID, string nodeName, int nodeTypeId,
                            string fullPath, string indexInfo, string createdDate, string updatedDate)
        {
            this.ContextTreeID = contextTreeID;
            this.NodeName = nodeName;
            this.NodeTypeID = nodeTypeId;
            this.FullPath = fullPath;
            this.IndexInfo = indexInfo;
            this.CreatedDate = createdDate;
            this.UpdatedDate = updatedDate;
        }
        
    }
}
