using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GLTc.QuickNote.Command;

namespace GLTc.QuickNote
{
    public partial class PageFind : Form
    {

        private int FindPosition;

        #region StartFindPosition
        /// <summary>
        /// the start position of the order select
        /// </summary>
        private int startFindPosition;
        public  int StartFindPosition
        {
            get
            {
                if (this.SelectedRichtextBox.SelectedText != string.Empty)
                {
                    startFindPosition = this.SelectedRichtextBox.SelectionStart + 1;

                }
                else
                {
                    startFindPosition = this.SelectedRichtextBox.SelectionStart;
                }

                return startFindPosition;
            }

        }
        #endregion 

        #region StartReverseFindPosition
        /// <summary>
        /// the start position of the disorder select
        /// </summary>
        private int startReverseFindPosition;
        public int StartReverseFindPosition
        {
            get
            {
                if (this.SelectedRichtextBox.SelectedText != string.Empty)
                {
                    startReverseFindPosition = this.SelectedRichtextBox.SelectionStart - 1;

                }
                else
                {
                    startReverseFindPosition = this.SelectedRichtextBox.SelectionStart;
                }

                return startReverseFindPosition;
            }

        }
        #endregion 

        #region CurrentContextOperator
        private ContextOperator currentContextOperator;

        public ContextOperator CurrentContextOperator
        {
            get { return currentContextOperator; }
            set { currentContextOperator = value; }
        }
        #endregion 

        #region SelectedRichtextBox
        private RichTextBox SelectedRichtextBox
        {
            get
            {
                return this.CurrentContextOperator.SelectedRichTextBox;
            }
        }
        #endregion 

        #region CurrentPageFind
        /// <summary>
        /// the singal PageFind object
        /// </summary>
        private static  PageFind CurrentPageFind;
        #endregion 

        #region PageFind
        private PageFind(ContextOperator COP)
        {
            this.CurrentContextOperator = COP;
            InitializeComponent();
        }

        #endregion 

        #region CreateParams
        /// <summary>
        /// hide the form from alt-tab
        /// </summary>
        protected override CreateParams CreateParams
        {
            get
            {
                // Turn on WS_EX_TOOLWINDOW style bit
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x80;
                return cp;
            }
        }
        #endregion

        #region CreatPageFindForm
        /// <summary>
        /// the methord to create a  singal pagefind class
        /// </summary>
        /// <param name="COP"></param>
        /// <returns></returns>
        public static PageFind CreatPageFindForm(ContextOperator COP)
        {

            if (CurrentPageFind == null)
            {
                CurrentPageFind = new PageFind(COP);
                CurrentPageFind.Location = COP.SelectedRichTextBox.PointToScreen(new Point(20, 50));

            }
            return CurrentPageFind;

        }
        #endregion 

        #region btnFind_Click
        /// <summary>
        /// find event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFind_Click(object sender, EventArgs e)
        {
            FindText();

        }
        #endregion 

        #region FindText
        private void FindText()
        {
            string findStr = this.tbFindText.Text.Trim();
            RichTextBoxFinds matchCase = this.cbMatchCase.Checked ? RichTextBoxFinds.MatchCase : RichTextBoxFinds.None;
            int selectStart;
            if (this.rbUp.Checked)
            {
                // select in disorder
                selectStart = StartReverseFindPosition;
                FindPosition = this.SelectedRichtextBox.Find(findStr, 0, selectStart, RichTextBoxFinds.Reverse | matchCase);

            }
            else
            {
                // select in order
                selectStart = StartFindPosition;
                FindPosition = this.SelectedRichtextBox.Find(findStr, selectStart, matchCase);

            }


            if (FindPosition != -1)
            {
                //this.SelectedRichtextBox.Select(FindPosition, this.tbFindText.Text.Trim().Length);
                //make the the find string in richtextbox selected
                //SelectedRichtextBox.ScrollToCaret();
            }
            else
            {
                MessageBox.Show("Can not find !");
            }
        }
        #endregion 

        #region Cancel Button
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();

        }
        #endregion 

        #region Enable Find Next Button
        private void tbFindText_TextChanged(object sender, EventArgs e)
        {
            if (this.tbFindText.Text.Trim() != string.Empty)
            {
                this.btnFind.Enabled = true;
            }
            else
            {
                this.btnFind.Enabled = false;
 
            }

        }
        #endregion 

        #region PageFind_FormClosed
        private void PageFind_FormClosed(object sender, FormClosedEventArgs e)
        {
            //release the resouce when close the window
            CurrentPageFind = null;
        }
        #endregion 

        #region ProcessCmdKey
        /// <summary>
        /// press esc key , close form
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape) this.Close();
            return base.ProcessCmdKey(ref msg, keyData);
        }
        #endregion

        #region PageFind_FormClosing
        private void PageFind_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();

        }
        #endregion 

        #region tbFindText_KeyDown
        private void tbFindText_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && this.tbFindText.Text != string.Empty)
            {
                FindText();
            }

        }
        #endregion 

        #region ShowPageFind
        public void ShowPageFind()
        {
            this.Show();
            this.tbFindText.Focus();
            if (this.tbFindText.Text != string.Empty)
            {
                this.tbFindText.SelectAll();
            }

        }
        #endregion 




    }
}