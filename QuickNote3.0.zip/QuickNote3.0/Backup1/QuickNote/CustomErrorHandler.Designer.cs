namespace GLTc.QuickNote
{
    partial class CustomErrorHandler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scErrorMessage = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbErrorMessage = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btnErrorMessage = new System.Windows.Forms.Button();
            this.btnSupportTeam = new System.Windows.Forms.Button();
            this.tbInformation = new System.Windows.Forms.TextBox();
            this.scErrorMessage.Panel1.SuspendLayout();
            this.scErrorMessage.Panel2.SuspendLayout();
            this.scErrorMessage.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // scErrorMessage
            // 
            this.scErrorMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scErrorMessage.Location = new System.Drawing.Point(0, 0);
            this.scErrorMessage.Name = "scErrorMessage";
            this.scErrorMessage.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // scErrorMessage.Panel1
            // 
            this.scErrorMessage.Panel1.Controls.Add(this.tableLayoutPanel1);
            // 
            // scErrorMessage.Panel2
            // 
            this.scErrorMessage.Panel2.Controls.Add(this.tbInformation);
            this.scErrorMessage.Panel2Collapsed = true;
            this.scErrorMessage.Size = new System.Drawing.Size(407, 66);
            this.scErrorMessage.SplitterDistance = 41;
            this.scErrorMessage.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.lbErrorMessage, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.26984F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 58.73016F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(407, 66);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lbErrorMessage
            // 
            this.lbErrorMessage.AutoSize = true;
            this.lbErrorMessage.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbErrorMessage.Location = new System.Drawing.Point(3, 14);
            this.lbErrorMessage.Name = "lbErrorMessage";
            this.lbErrorMessage.Size = new System.Drawing.Size(401, 13);
            this.lbErrorMessage.TabIndex = 0;
            this.lbErrorMessage.Text = "Sorry for the inconvenience , Please contact QuickNote Support Team for support.";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.btnErrorMessage, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnSupportTeam, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 30);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(401, 33);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // btnErrorMessage
            // 
            this.btnErrorMessage.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnErrorMessage.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnErrorMessage.Location = new System.Drawing.Point(107, 3);
            this.btnErrorMessage.Name = "btnErrorMessage";
            this.btnErrorMessage.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnErrorMessage.Size = new System.Drawing.Size(90, 27);
            this.btnErrorMessage.TabIndex = 0;
            this.btnErrorMessage.Text = "ErrorMessage";
            this.btnErrorMessage.UseVisualStyleBackColor = true;
            this.btnErrorMessage.Click += new System.EventHandler(this.btnErrorMessage_Click);
            // 
            // btnSupportTeam
            // 
            this.btnSupportTeam.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnSupportTeam.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSupportTeam.Location = new System.Drawing.Point(203, 3);
            this.btnSupportTeam.Name = "btnSupportTeam";
            this.btnSupportTeam.Size = new System.Drawing.Size(90, 27);
            this.btnSupportTeam.TabIndex = 1;
            this.btnSupportTeam.Text = "SupportTeam";
            this.btnSupportTeam.UseVisualStyleBackColor = true;
            this.btnSupportTeam.Click += new System.EventHandler(this.btnSupportTeam_Click);
            // 
            // tbInformation
            // 
            this.tbInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbInformation.Location = new System.Drawing.Point(0, 0);
            this.tbInformation.Multiline = true;
            this.tbInformation.Name = "tbInformation";
            this.tbInformation.Size = new System.Drawing.Size(150, 46);
            this.tbInformation.TabIndex = 0;
            // 
            // CustomErrorHandler
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(407, 66);
            this.Controls.Add(this.scErrorMessage);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CustomErrorHandler";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Error Message";
            this.scErrorMessage.Panel1.ResumeLayout(false);
            this.scErrorMessage.Panel2.ResumeLayout(false);
            this.scErrorMessage.Panel2.PerformLayout();
            this.scErrorMessage.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer scErrorMessage;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lbErrorMessage;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btnErrorMessage;
        private System.Windows.Forms.Button btnSupportTeam;
        public System.Windows.Forms.TextBox tbInformation;

    }
}