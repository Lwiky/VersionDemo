using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GLTc.QuickNote.Command;

namespace GLTc.QuickNote
{
    public partial class CloseConfirm : Form
    {
        private  CloseConfirm()
        {
            InitializeComponent();
            InitalizeBtnStatus();

        }

        public CloseConfirm(List<ContextBaseInfo> SaveItems):this()
        {
            ListBoxItemBind(SaveItems);
        }

        #region ListBoxItemBind
        /// <summary>
        /// bind the save items
        /// </summary>
        /// <param name="SaveItems"></param>
        private void ListBoxItemBind(List<ContextBaseInfo> SaveItems)
        {
            foreach (ContextBaseInfo cbi in SaveItems)
            {
                this.LBSaveItems.Items.Add(cbi.FullPath);
            }

        }
        #endregion 

        #region InitalizeBtnStatus
        private void InitalizeBtnStatus()
        {
            this.btnYes.DialogResult = DialogResult.Yes;
            this.btnNo.DialogResult = DialogResult.No;
            this.btnCancel.DialogResult = DialogResult.Cancel;
        }
        #endregion 

        private void btnYes_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}