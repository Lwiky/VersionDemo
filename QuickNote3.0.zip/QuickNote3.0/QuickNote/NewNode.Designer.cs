namespace GLTc.QuickNote
{
    partial class NewNode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbAddNode = new System.Windows.Forms.GroupBox();
            this.TbNodeText = new System.Windows.Forms.TextBox();
            this.CBBNodeType = new System.Windows.Forms.ComboBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.lbNodeText = new System.Windows.Forms.Label();
            this.lbNodeType = new System.Windows.Forms.Label();
            this.gbAddNode.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbAddNode
            // 
            this.gbAddNode.Controls.Add(this.TbNodeText);
            this.gbAddNode.Controls.Add(this.CBBNodeType);
            this.gbAddNode.Controls.Add(this.btnCancel);
            this.gbAddNode.Controls.Add(this.btnConfirm);
            this.gbAddNode.Controls.Add(this.lbNodeText);
            this.gbAddNode.Controls.Add(this.lbNodeType);
            this.gbAddNode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbAddNode.Location = new System.Drawing.Point(0, 0);
            this.gbAddNode.Name = "gbAddNode";
            this.gbAddNode.Size = new System.Drawing.Size(284, 128);
            this.gbAddNode.TabIndex = 0;
            this.gbAddNode.TabStop = false;
            this.gbAddNode.Text = "New Node";
            // 
            // TbNodeText
            // 
            this.TbNodeText.Location = new System.Drawing.Point(98, 52);
            this.TbNodeText.Name = "TbNodeText";
            this.TbNodeText.Size = new System.Drawing.Size(121, 20);
            this.TbNodeText.TabIndex = 0;
            this.TbNodeText.Text = "NewNode";
            // 
            // CBBNodeType
            // 
            this.CBBNodeType.FormattingEnabled = true;
            this.CBBNodeType.Items.AddRange(new object[] {
            "1",
            "2"});
            this.CBBNodeType.Location = new System.Drawing.Point(98, 25);
            this.CBBNodeType.Name = "CBBNodeType";
            this.CBBNodeType.Size = new System.Drawing.Size(121, 21);
            this.CBBNodeType.TabIndex = 1;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(144, 99);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(32, 99);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(75, 23);
            this.btnConfirm.TabIndex = 3;
            this.btnConfirm.Text = "Ok";
            this.btnConfirm.UseVisualStyleBackColor = true;
            // 
            // lbNodeText
            // 
            this.lbNodeText.AutoSize = true;
            this.lbNodeText.Location = new System.Drawing.Point(21, 60);
            this.lbNodeText.Name = "lbNodeText";
            this.lbNodeText.Size = new System.Drawing.Size(57, 13);
            this.lbNodeText.TabIndex = 8;
            this.lbNodeText.Text = "Node Text";
            // 
            // lbNodeType
            // 
            this.lbNodeType.AutoSize = true;
            this.lbNodeType.Location = new System.Drawing.Point(21, 25);
            this.lbNodeType.Name = "lbNodeType";
            this.lbNodeType.Size = new System.Drawing.Size(60, 13);
            this.lbNodeType.TabIndex = 9;
            this.lbNodeType.Text = "Node Type";
            // 
            // NewNode
            // 
            this.AcceptButton = this.btnConfirm;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(284, 128);
            this.Controls.Add(this.gbAddNode);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "NewNode";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "NewNode";
            this.gbAddNode.ResumeLayout(false);
            this.gbAddNode.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbAddNode;
        private System.Windows.Forms.TextBox TbNodeText;
        private System.Windows.Forms.ComboBox CBBNodeType;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Label lbNodeText;
        private System.Windows.Forms.Label lbNodeType;

    }
}