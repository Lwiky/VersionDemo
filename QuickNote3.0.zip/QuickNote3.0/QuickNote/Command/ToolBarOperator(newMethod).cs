using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Drawing.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using System.Data.Common;
using GLTc.NoteLib;
using GLTc.QuickNote;
using GLTc.QuickNote.CustomControl;

namespace GLTc.QuickNote.Command
{



    public class ToolBarOperator : BaseOperator
    {

        #region  fields
        // the usual color Name
        public string[] TextColorName = new string[] { "Black", "Maroon", "Green", "Olive", "Navy", "Purple", "Teal", "Gray",
                                                        "Silver", "Red", "Lime", "Yellow", "Blue", "Fuchsia", "Aqua", "White" };
        //the zoom text
        public string[] ZoomText = new string[] { "10%", "25%", "50%", "75%", "100%", "150%", "200%", "500%" };
        // the zoom value
        public float[] ZoomValue = new float[] { 0.1f, 0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 5f };


        public Font CurrentSelectionFont;


        #endregion

        #region  Properties

        #region RightMainForm
        private ContextOperator currentContextOperator;
        /// <summary>
        /// the right tabcontrol of the main form
        /// for display the multi richtextboxes
        /// </summary>
        public ContextOperator CurrentContextOperator
        {
            get { return currentContextOperator; }
            set { currentContextOperator = value; }
        }
        #endregion


        #region CurrentSplitContainer
        private SplitContainer currentSplitContainer;
        /// <summary>
        /// the split control of the right form and left form
        /// </summary>
        public SplitContainer CurrentSplitContainer
        {
            get { return currentSplitContainer; }
            set { currentSplitContainer = value; }
        }
        #endregion

        #region CurrentTreeOperator
        private TreeOperator currentTreeOperator;
        /// <summary>
        /// currentTreeView  outline
        /// </summary>
        public TreeOperator CurrentTreeOperator
        {
            get { return currentTreeOperator; }
            set { currentTreeOperator = value; }
        }
        #endregion


        #region FormatToolBar
        private ToolStrip formatToolBar;
        /// <summary>
        /// the format toolstrip
        /// </summary>
        public ToolStrip FormatToolBar
        {
            get { return formatToolBar; }
            set { formatToolBar = value; }
        }
        #endregion

        #region StandardToolBar
        private ToolStrip standardToolBar;
        /// <summary>
        /// the standard tool  bar
        /// </summary>
        public ToolStrip StandardToolBar
        {
            get { return standardToolBar; }
            set { standardToolBar = value; }
        }
        #endregion

        #region UsualColors
        private Color[] usualColors;
        /// <summary>
        /// the usual text color
        /// </summary>
        public Color[] UsualColors
        {
            get
            {
                int usualColorCount = Enum.GetNames(typeof(TextColor)).Length;
                usualColors = new Color[usualColorCount];
                for (int i = 0; i < usualColorCount; i++)
                {

                    usualColors[i] = Color.FromName(TextColorName[i]);


                }
                return usualColors;

            }
        }
        #endregion

        #region SelectedRichTextBox
        /// <summary>
        /// the selected RichTextbox
        /// </summary>
        public CustomRichTextBox SelectedRichTextBox
        {
            get
            {
                CustomRichTextBox rtb = null;
                TabPage selectedPage = this.CurrentContextOperator.RightMainForm.SelectedTab;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        string selectedRichTextBoxId = this.CurrentContextOperator.GetRichTextBoxName(cbi.ContextInfoID);
                        rtb = (CustomRichTextBox)selectedPage.Controls[selectedRichTextBoxId];
                    }
                }

                return rtb;

            }

        }
        #endregion

        #region  FormatBar

        private ToolStripComboBox tscbFont;
        /// <summary>
        /// font combox
        /// </summary>
        public ToolStripComboBox TSCBFont
        {
            get
            {

                tscbFont = (ToolStripComboBox)this.FormatToolBar.Items["TSCBFont"];
                return tscbFont;
            }

        }

        private ToolStripComboBox tscbSize;
        /// <summary>
        /// font combox
        /// </summary>
        public ToolStripComboBox TSCBSize
        {
            get
            {

                tscbSize = (ToolStripComboBox)this.FormatToolBar.Items["TSCBSize"];
                return tscbSize;
            }

        }

        private ToolStripButton tsbBlod;
        /// <summary>
        /// font combox
        /// </summary>
        public ToolStripButton TSBBlod
        {
            get
            {

                tsbBlod = (ToolStripButton)this.FormatToolBar.Items["TSBBlod"];
                return tsbBlod;
            }

        }

        private ToolStripButton tsbItalic;
        /// <summary>
        /// font combox
        /// </summary>
        public ToolStripButton TSBItalic
        {
            get
            {

                tsbItalic = (ToolStripButton)this.FormatToolBar.Items["TSBItalic"];
                return tsbItalic;
            }

        }

        private ToolStripButton tsbUnderline;
        /// <summary>
        /// font combox
        /// </summary>
        public ToolStripButton TSBUnderline
        {
            get
            {

                tsbUnderline = (ToolStripButton)this.FormatToolBar.Items["TSBUnderline"];
                return tsbUnderline;
            }

        }

        private ToolStripButton tsbTextBackColor;
        /// <summary>
        /// back Color button
        /// </summary>
        public ToolStripButton TSBTextBackColor
        {
            get
            {
                tsbTextBackColor = (ToolStripButton)this.FormatToolBar.Items["TSBTextBackColor"];
                return tsbTextBackColor;
            }

        }

        private ToolStripDropDownButton tsddlBackColor;
        /// <summary>
        /// back Color dropdownlist
        /// </summary>
        public ToolStripDropDownButton TSDDLBackColor
        {
            get
            {

                tsddlBackColor = (ToolStripDropDownButton)this.FormatToolBar.Items["TSDDLBackColor"];
                return tsddlBackColor;
            }

        }

        private ToolStripButton tsbColor;
        /// <summary>
        /// Color button
        /// </summary>
        public ToolStripButton TSBColor
        {
            get
            {
                tsbColor = (ToolStripButton)this.FormatToolBar.Items["TSBColor"];
                return tsbColor;
            }

        }

        private ToolStripDropDownButton tsDDLColor;
        /// <summary>
        /// font combox
        /// </summary>
        public ToolStripDropDownButton TSDDLColor
        {
            get
            {

                tsDDLColor = (ToolStripDropDownButton)this.FormatToolBar.Items["TSDDLColor"];
                return tsDDLColor;
            }

        }



        private ToolStripButton tsbAlignLeft;
        /// <summary>
        /// align left
        /// </summary>
        public ToolStripButton TSBAlignLeft
        {
            get
            {

                tsbAlignLeft = (ToolStripButton)this.FormatToolBar.Items["TSBAlignLeft"];
                return tsbAlignLeft;
            }

        }

        private ToolStripButton tsbAlignCenter;
        /// <summary>
        /// align center
        /// </summary>
        public ToolStripButton TSBAlignCenter
        {
            get
            {

                tsbAlignCenter = (ToolStripButton)this.FormatToolBar.Items["TSBAlignCenter"];
                return tsbAlignCenter;
            }

        }

        private ToolStripButton tsbAlignRight;
        /// <summary>
        /// align right
        /// </summary>
        public ToolStripButton TSBAlignRight
        {
            get
            {

                tsbAlignRight = (ToolStripButton)this.FormatToolBar.Items["TSBAlignRight"];
                return tsbAlignRight;
            }

        }

        private ToolStripButton tsbBullet;
        /// <summary>
        /// bullet
        /// </summary>
        public ToolStripButton TSBBullet
        {
            get
            {

                tsbBullet = (ToolStripButton)this.FormatToolBar.Items["TSBBullet"];
                return tsbBullet;
            }

        }

        private ToolStripButton tsbDecreaseIndent;
        /// <summary>
        /// Decrease Indent
        /// </summary>
        public ToolStripButton TSBDecreaseIndent
        {
            get
            {

                tsbDecreaseIndent = (ToolStripButton)this.FormatToolBar.Items["TSBDecreaseIndent"];
                return tsbDecreaseIndent;
            }

        }

        private ToolStripButton tsbIncreaseIndent;
        /// <summary>
        /// Increase Indent
        /// </summary>
        public ToolStripButton TSBIncreaseIndent
        {
            get
            {

                tsbIncreaseIndent = (ToolStripButton)this.FormatToolBar.Items["TSBIncreaseIndent"];
                return tsbIncreaseIndent;
            }

        }

        #endregion

        #region StandBar

        private ToolStripButton tsbNewPage;
        /// <summary>
        /// tsbNewPage
        /// </summary>
        public ToolStripButton TSBNewPage
        {
            get
            {

                tsbNewPage = (ToolStripButton)this.StandardToolBar.Items["TSBNewPage"];
                return tsbNewPage;
            }

        }

        private ToolStripButton tsbSave;
        /// <summary>
        /// TSBSave 
        /// </summary>
        public ToolStripButton TSBSave
        {
            get
            {

                tsbSave = (ToolStripButton)this.StandardToolBar.Items["TSBSave"];
                return tsbSave;
            }
        }

        private ToolStripButton tsbSaveAll;
        /// <summary>
        /// TSBSaveAll
        /// </summary>
        public ToolStripButton TSBSaveAll
        {
            get
            {

                tsbSaveAll = (ToolStripButton)this.StandardToolBar.Items["TSBSaveAll"];
                return tsbSaveAll;
            }

        }
        private ToolStripButton stbCut;
        /// <summary>
        /// STBCut
        /// </summary>
        public ToolStripButton STBCut
        {
            get
            {

                stbCut = (ToolStripButton)this.StandardToolBar.Items["STBCut"];
                return stbCut;
            }
        }

        private ToolStripButton stbCopy;
        /// <summary>
        /// STBCopy
        /// </summary>
        public ToolStripButton STBCopy
        {
            get
            {

                stbCopy = (ToolStripButton)this.StandardToolBar.Items["STBCopy"];
                return stbCopy;
            }

        }
        private ToolStripButton stbPaste;
        /// <summary>
        /// STBPaste
        /// </summary>
        public ToolStripButton STBPaste
        {
            get
            {

                stbPaste = (ToolStripButton)this.StandardToolBar.Items["STBPaste"];
                return stbPaste;
            }

        }

        private ToolStripButton tsbFormatPrinter;
        /// <summary>
        /// TSBFormatPrinter
        /// </summary>
        public ToolStripButton TSBFormatPrinter
        {
            get
            {

                tsbFormatPrinter = (ToolStripButton)this.StandardToolBar.Items["TSBFormatPrinter"];
                return tsbFormatPrinter;
            }

        }


        private ToolStripButton tsbUndo;
        /// <summary>
        /// TSBUndo
        /// </summary>
        public ToolStripButton TSBUndo
        {
            get
            {

                tsbUndo = (ToolStripButton)this.StandardToolBar.Items["TSBUndo"];
                return tsbUndo;
            }

        }

        private ToolStripButton tsbRedo;
        /// <summary>
        /// TSBUndo
        /// </summary>
        public ToolStripButton TSBRedo
        {
            get
            {

                tsbRedo = (ToolStripButton)this.StandardToolBar.Items["TSBRedo"];
                return tsbRedo;
            }

        }


        private ToolStripButton tsbMap;
        /// <summary>
        /// TSBMap
        /// </summary>
        public ToolStripButton TSBMap
        {
            get
            {

                tsbMap = (ToolStripButton)this.StandardToolBar.Items["TSBMap"];
                return tsbMap;
            }

        }

        private ToolStripComboBox tscbWidth;
        /// <summary>
        /// TSCBWidth
        /// </summary>
        public ToolStripComboBox TSCBWidth
        {
            get
            {

                tscbWidth = (ToolStripComboBox)this.StandardToolBar.Items["TSCBWidth"];
                return tscbWidth;
            }

        }


        #endregion

        #endregion

        #region Constructor
        public ToolBarOperator(SplitContainer MainSplitContainer, ContextOperator CurrContextOperator, ToolStrip StandardToolStrip, ToolStrip FormatToolStrip, TreeOperator MainTreeOperator)
        {
            this.CurrentSplitContainer = MainSplitContainer;
            this.CurrentContextOperator = CurrContextOperator;
            this.FormatToolBar = FormatToolStrip;
            this.StandardToolBar = StandardToolStrip;
            this.CurrentTreeOperator = MainTreeOperator;

        }
        #endregion

        public void InializeToolBarState()
        {
            InitalFormatToolbar();
            InitalizeEvent();

        }

        #region InitalFormatToolbar
        /// <summary>
        /// Initial the format tool bar
        /// </summary>
        private void InitalFormatToolbar()
        {
            // initalize the Text back color button
            this.ColorBind(TSDDLBackColor, TSBTextBackColor);
            // initalize the Text  color button
            this.ColorBind(TSDDLColor, TSBColor);
            //initalize the font family dropdown list
            this.FontFamilyBind();
            //initalize the font  size dropdown list
            this.FontSizeBind();

            this.ZoomBind(this.TSCBWidth);
        }
        #endregion

        #region InitalizeEvent
        public void InitalizeEvent()
        {
            this.TSCBFont.SelectedIndexChanged += new EventHandler(TSCBFont_SelectedIndexChanged);
            this.TSCBSize.KeyDown += new KeyEventHandler(TSCBSize_KeyDown);
            this.TSCBSize.SelectedIndexChanged += new EventHandler(TSCBSize_SelectedIndexChanged);
            this.TSBBlod.Click += new EventHandler(TSBBlod_Click);
            this.TSBUnderline.Click += new EventHandler(tsbUnderline_Click);
            this.TSBItalic.Click += new EventHandler(TSBItalic_Click);
            this.TSDDLColor.DropDownItemClicked += new ToolStripItemClickedEventHandler(TSDDLColor_DropDownItemClicked);
            this.TSBColor.Click += new EventHandler(TSBColor_Click);
            this.TSDDLBackColor.DropDownItemClicked += new ToolStripItemClickedEventHandler(tsddlBackColor_DropDownItemClicked);
            this.TSBTextBackColor.Click += new EventHandler(TSBTextBackColor_Click);
            this.TSBAlignLeft.Click += new EventHandler(TSBAlignLeft_Click);
            this.TSBAlignCenter.Click += new EventHandler(TSBAlignCenter_Click);
            this.TSBAlignRight.Click += new EventHandler(TSBAlignRight_Click);
            this.TSBBullet.Click += new EventHandler(TSBBullet_Click);
            this.TSBDecreaseIndent.Click += new EventHandler(TSBDecreaseIndent_Click);
            this.TSBIncreaseIndent.Click += new EventHandler(TSBIncreaseIndent_Click);
            //standard bar event
            this.TSBNewPage.Click += new EventHandler(TSBNewPage_Click);
            this.STBCut.Click += new EventHandler(STBCut_Click);
            this.STBCopy.Click += new EventHandler(STBCopy_Click);
            this.STBPaste.Click += new EventHandler(STBPaste_Click);
            this.TSBUndo.Click += new EventHandler(TSBUndo_Click);
            this.TSBRedo.Click += new EventHandler(TSBRedo_Click);
            this.TSBMap.Click += new EventHandler(TSBMap_Click);
            this.TSCBWidth.SelectedIndexChanged += new EventHandler(TSCBWidth_SelectedIndexChanged);
            this.TSCBWidth.KeyDown += new KeyEventHandler(TSCBWidth_KeyDown);




        }





        #endregion

        #region StandardBarEvent

        void TSBMap_Click(object sender, EventArgs e)
        {

            this.CurrentSplitContainer.Panel1Collapsed = !this.CurrentSplitContainer.Panel1Collapsed;


        }

        /// <summary>
        /// Richtextbox redo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void TSBRedo_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null && this.SelectedRichTextBox.CanRedo)
            {

                this.SelectedRichTextBox.Redo();
            }

        }

        /// <summary>
        /// Richtextbox undo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void TSBUndo_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null && this.SelectedRichTextBox.CanUndo)
            {

                this.SelectedRichTextBox.Undo();
            }

        }
        /// <summary>
        /// richtextbox Paste
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void STBPaste_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                this.SelectedRichTextBox.Paste();
            }


        }
        /// <summary>
        /// Richtextbox Copy
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void STBCopy_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                this.SelectedRichTextBox.Copy();
            }

        }

        /// <summary>
        /// Richtextbox Cut
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void STBCut_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                this.SelectedRichTextBox.Cut();
            }
        }
        void TSBNewPage_Click(object sender, EventArgs e)
        {
            TreeNode parentNode = this.CurrentTreeOperator.CurrentTreeView.SelectedNode;
            TreeNodeInfo tni = (TreeNodeInfo)parentNode.Tag;
            if (tni.NodeTypeID == (int)TreeNodeType.Page)
            {
                parentNode = parentNode.Parent;

            }

            NewNode newNode = new NewNode();
            newNode.SelectedNodeTypeIndex = (int)TreeNodeType.Page;
            if (newNode.ShowDialog() == DialogResult.OK)
            {

                TreeNode childrenNode = CurrentTreeOperator.AddTreeNode(newNode.NodeText, newNode.NodeTypeId, parentNode);
                parentNode.Expand();
                //after new the tree node , open the treenode
                this.CurrentTreeOperator.CurrentTreeView.SelectedNode = childrenNode;
                TreeNodeInfo nodeinfo = (TreeNodeInfo)this.CurrentTreeOperator.CurrentTreeView.SelectedNode.Tag;
                if (nodeinfo.NodeTypeID == (int)TreeNodeType.Page)
                {
                    //the text of  book and section  will not be opened  for the time being
                    this.CurrentContextOperator.OpenContext(this.CurrentTreeOperator.CurrentTreeView.SelectedNode);
                }

            }
        }


        void TSCBWidth_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                ToolStripComboBox tsb = (ToolStripComboBox)sender;
                float result;
                if (this.SelectedRichTextBox != null && float.TryParse(tsb.Text, out result))
                {
                    this.SelectedRichTextBox.ZoomFactor = (float)(result / 100.0);

                }

            }

        }

        void TSCBWidth_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(this.SelectedRichTextBox != null)
            this.SelectedRichTextBox.ZoomFactor = ZoomValue[this.TSCBWidth.SelectedIndex];

        }

        #endregion

        #region fontStyle event


        void TSCBSize_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                ToolStripComboBox tsb = (ToolStripComboBox)sender;
                float result;
                if (this.SelectedRichTextBox != null && float.TryParse(tsb.Text, out result))
                {
                    SetRichTextboxFontSize(this.TSCBSize.Text.ToString());

                }

            }
        }

        void TSCBSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                SetRichTextboxFontSize(this.TSCBSize.SelectedItem.ToString());
                this.SelectedRichTextBox.Focus();

            }
        }




        void TSBColor_Click(object sender, EventArgs e)
        {
            //change the text color
            if (this.SelectedRichTextBox != null)
            {
                Color currentColor = (Color)TSDDLColor.Tag;
                this.SelectedRichTextBox.SelectionColor = currentColor;
            }
        }

        void TSBTextBackColor_Click(object sender, EventArgs e)
        {
            //change the text color
            if (this.SelectedRichTextBox != null)
            {
                Color currentColor = (Color)TSDDLBackColor.Tag;
                this.SelectedRichTextBox.SelectionBackColor = currentColor;
            }


        }

        void tsddlBackColor_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            //change the button color
            ToolStripDropDownButton tsddb = (ToolStripDropDownButton)sender;

            //change the text back color
            if (this.SelectedRichTextBox != null)
            {
                if (e.ClickedItem.Text != "None")
                {
                    tsddb.Tag = Color.FromName(e.ClickedItem.Text);
                    this.SelectedRichTextBox.SelectionBackColor = Color.FromName(e.ClickedItem.Text);
                    TSBTextBackColor.Image = GetColorSelectedImg(e.ClickedItem.Text, "BackColor");
                }
                else
                {
                    this.SelectedRichTextBox.SelectionBackColor = Color.Transparent;
                }

            }

        }

        void TSBItalic_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                if (this.SelectedRichTextBox.SelectionFont != null && this.SelectedRichTextBox.SelectionFont.Italic == true)
                {
                    SubstractRichTextboxFontStyle(FontStyle.Italic);
                }
                else
                {
                    AddRichTextboxFontStyle(FontStyle.Italic);
                }
                this.SelectedRichTextBox.Focus();
            }



        }

        void tsbUnderline_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                if (this.SelectedRichTextBox.SelectionFont != null && this.SelectedRichTextBox.SelectionFont.Underline == true)
                {
                    SubstractRichTextboxFontStyle(FontStyle.Underline);
                }
                else
                {
                    AddRichTextboxFontStyle(FontStyle.Underline);
                }
                this.SelectedRichTextBox.Focus();
            }



        }

        void TSBBlod_Click(object sender, EventArgs e)
        {

            if (this.SelectedRichTextBox != null)
            {
                if (this.SelectedRichTextBox.SelectionFont != null && this.SelectedRichTextBox.SelectionFont.Bold == true)
                {
                    SubstractRichTextboxFontStyle(FontStyle.Bold);
                }
                else
                {
                    AddRichTextboxFontStyle(FontStyle.Bold);
                }
                this.SelectedRichTextBox.Focus();
            }

        }


        void TSCBFont_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                SetRichTextboxFamilyFont(this.TSCBFont.SelectedItem.ToString());
                this.SelectedRichTextBox.Focus();
            }

        }




        void TSBIncreaseIndent_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                this.SelectedRichTextBox.SelectionIndent += 12;
            }
        }

        void TSBDecreaseIndent_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                this.SelectedRichTextBox.SelectionIndent -= 12;
            }
        }

        void TSBBullet_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                this.SelectedRichTextBox.SelectionBullet = !this.SelectedRichTextBox.SelectionBullet;
            }
        }

        void TSBAlignRight_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                this.SelectedRichTextBox.SelectionAlignment = HorizontalAlignment.Right;
            }
        }

        void TSBAlignCenter_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                this.SelectedRichTextBox.SelectionAlignment = HorizontalAlignment.Center;
            }
        }

        void TSBAlignLeft_Click(object sender, EventArgs e)
        {
            if (this.SelectedRichTextBox != null)
            {
                this.SelectedRichTextBox.SelectionAlignment = HorizontalAlignment.Left;
            }
        }

        #endregion

        #region FontFamilyBind
        /// <summary>
        /// Bind the font from windows system fontCollection 
        /// </summary>
        /// <param name="TSCBFont"></param>
        public void FontFamilyBind()
        {
            InstalledFontCollection fontCollection = new InstalledFontCollection();

            foreach (FontFamily f in fontCollection.Families)
            {
                if (IsAllFontStyleAvailable(f))
                {
                    TSCBFont.Items.Add(f.Name);
                    if (f.Name == Configure.DefaultFont.Name)
                    {
                        TSCBFont.SelectedItem = f.Name;

                    }
                }

            }


        }


        #region IsAllFontStyleAvailable
        /// <summary>
        /// IsAllFontStyleAvailable
        /// </summary>
        /// <param name="fontFamly"></param>
        /// <returns></returns>
        private bool IsAllFontStyleAvailable(FontFamily fontFamly)
        {
            bool isAllAvailable = false;
            if (fontFamly.IsStyleAvailable(FontStyle.Bold) &&
               fontFamly.IsStyleAvailable(FontStyle.Italic)
                && fontFamly.IsStyleAvailable(FontStyle.Regular)
                && fontFamly.IsStyleAvailable(FontStyle.Strikeout)
                && fontFamly.IsStyleAvailable(FontStyle.Underline)
                )
            {
                isAllAvailable = true;
            }

            return isAllAvailable;

        }
        #endregion

        #endregion

        #region SetRichTextboxSelectedFont
        /// <summary>
        /// set the select font
        /// </summary>
        /// <returns></returns>
        public void SetRichTextboxFamilyFont(string fontName)
        {

            Font currentFont = null;
            int selectStartPosion = this.SelectedRichTextBox.SelectionStart;
            int selectionLength = this.SelectedRichTextBox.SelectionLength;
            if (this.SelectedRichTextBox != null && this.SelectedRichTextBox.SelectedText != string.Empty)
            {
                if (this.SelectedRichTextBox.SelectedText.Length < 200)
                {
                    TransferRichTextBox.Rtf = this.SelectedRichTextBox.SelectedRtf;

                    for (int i = 0; i < TransferRichTextBox.Text.Length; i++)
                    {

                        //change the text size  charater by charater
                        TransferRichTextBox.Select(i, 1);
                        if (TransferRichTextBox.SelectionFont != null)
                        {
                            float fontSize = TransferRichTextBox.SelectionFont.Size;
                            currentFont = new Font(fontName, fontSize, TransferRichTextBox.SelectionFont.Style);
                            TransferRichTextBox.SelectionFont = currentFont;
                        }

                    }
                }
                else
                {
                    float fontSize;
                    if (!float.TryParse(this.TSCBSize.Text, out fontSize))
                    {
                        fontSize = 10f;

                    }
                    this.SelectedRichTextBox.SelectionFont = new Font(fontName, fontSize, FontStyle.Regular);
                    return;
 
                }

            }

            // the current Selectfont equals the last charater's font
            if (currentFont != null)
            {
                TransferRichTextBox.SelectAll();
                TransferRichTextBox.Cut();
                this.SelectedRichTextBox.Paste();
                this.SelectedRichTextBox.Select(selectStartPosion, selectionLength);
                //this.SelectedRichTextBox.SelectionFont = currentFont;
                TransferRichTextBox.Clear();
            }
            else
            {
                float fontSize = this.SelectedRichTextBox.SelectionFont.Size;
                currentFont = new Font(fontName, fontSize, this.SelectedRichTextBox.SelectionFont.Style);
                this.SelectedRichTextBox.SelectionFont = currentFont;
            }


        }

        /// <summary>
        /// set the select font
        /// </summary>
        /// <returns></returns>
        public void SetRichTextboxFontSize(string FontSize)
        {

            Font currentFont = null;
            int selectStartPosion = this.SelectedRichTextBox.SelectionStart;
            int selectionLength = this.SelectedRichTextBox.SelectionLength;
            if (this.SelectedRichTextBox != null && this.SelectedRichTextBox.SelectedText != string.Empty)
            {
                if (this.SelectedRichTextBox.Text.Length < 200)
                {
                    TransferRichTextBox.Rtf = this.SelectedRichTextBox.SelectedRtf;
                    if (this.SelectedRichTextBox != null && this.SelectedRichTextBox.SelectedText != string.Empty)
                    {
                        for (int i = 0; i < TransferRichTextBox.Text.Length; i++)
                        {
                            //change the text size  charater by charater
                            TransferRichTextBox.Select(i, 1);
                            if (TransferRichTextBox.SelectionFont != null)
                            {
                                string fontName = TransferRichTextBox.SelectionFont.Name;
                                float fontSize = float.Parse(FontSize);
                                currentFont = new Font(fontName, fontSize, TransferRichTextBox.SelectionFont.Style);
                                TransferRichTextBox.SelectionFont = currentFont;
                            }

                        }
                    }
                }
                else
                {
                    string fontName = this.TSCBFont.SelectedItem.ToString();
                    float fontSize = float.Parse(FontSize);
                    this.SelectedRichTextBox.SelectionFont = new Font(fontName, fontSize, FontStyle.Regular);
                    return;
 
                }


            }
            // the current Selectfont equals the last charater's font
            if (currentFont != null)
            {
                TransferRichTextBox.SelectAll();
                TransferRichTextBox.Cut();
                this.SelectedRichTextBox.Paste();
                this.SelectedRichTextBox.Select(selectStartPosion, selectionLength);
                //this.SelectedRichTextBox.SelectionFont = currentFont;
                TransferRichTextBox.Clear();
            }
            else
            {
    
                string fontName = this.SelectedRichTextBox.SelectionFont.Name;
                float fontSize = float.Parse(FontSize);
                currentFont = new Font(fontName, fontSize, this.SelectedRichTextBox.SelectionFont.Style);
                this.SelectedRichTextBox.SelectionFont = currentFont;
            }


        }


        /// <summary>
        /// add the  font style
        /// </summary>
        /// <returns></returns>
        public void AddRichTextboxFontStyle(FontStyle fs)
        {
            Font currentFont = null;
            string fontName;
            float fontSize;
            if (this.SelectedRichTextBox.SelectionFont != null)
            {
                 fontName = this.SelectedRichTextBox.SelectionFont.Name;
                 fontSize = this.SelectedRichTextBox.SelectionFont.Size;
                 currentFont = new Font(fontName, fontSize, this.SelectedRichTextBox.SelectionFont.Style | fs);
            }
            else
            {
 
                if (!float.TryParse(this.TSCBSize.Text, out fontSize))
                {
                    fontSize = 10f;

                }
                fontName = this.TSCBFont.SelectedItem.ToString();
                currentFont = new Font(fontName, fontSize, fs);
            }


            this.SelectedRichTextBox.SelectionFont = currentFont;

           
        }

        /// <summary>
        /// substract  font style 
        /// for richtextbox can not judge whether the selectText is bold or not
        /// so set all the selectedText to the same font
        /// </summary>
        /// <returns></returns>
        public void SubstractRichTextboxFontStyle(FontStyle fs)
        {
            Font currentFont = null;
            string fontName;
            float fontSize;
            if (this.SelectedRichTextBox.SelectionFont != null)
            {
                 fontName = this.SelectedRichTextBox.SelectionFont.Name;
                 fontSize = this.SelectedRichTextBox.SelectionFont.Size;
                 currentFont = new Font(fontName, fontSize, this.SelectedRichTextBox.SelectionFont.Style & ~fs);
            }
            else
            {
 
                if (!float.TryParse(this.TSCBSize.Text, out fontSize))
                {
                    fontSize = 10f;

                }
                fontName = this.TSCBFont.SelectedItem.ToString();
                currentFont = new Font(fontName, fontSize, ~fs);
            }

            

            this.SelectedRichTextBox.SelectionFont = currentFont;

        }
        #endregion

        #region FontSizeBind
        /// <summary>
        /// bind the font size
        /// </summary>
        /// <param name="TSCBFontSize"></param>
        public void FontSizeBind()
        {
            for (int i = 8; i <= 72; i += 2)
            {
                TSCBSize.Items.Add(i.ToString());
                TSCBSize.SelectedItem = Configure.DefaultFont.Size.ToString();
            }

        }
        #endregion

        #region ZoomBind
        /// <summary>
        /// Zoom databind
        /// </summary>
        /// <param name="ZoomComBox"></param>
        public void ZoomBind(ToolStripComboBox ZoomComBox)
        {
            foreach (string zoonText in ZoomText)
            {
                ZoomComBox.Items.Add(zoonText);
            }

        }
        #endregion

        #region ColorBind
        /// <summary>
        /// Color Dropdownlist show
        /// </summary>
        /// <param name="ColorDropdowButton"></param>
        public void ColorBind(ToolStripDropDownButton DDLColor, ToolStripButton ColorButton)
        {

            if (ColorButton.Name == "TSBTextBackColor")
            {
                ColorButton.Image = GetColorSelectedImg(Color.Lime.Name, "BackColor");
                Image colorImg = CreatColorImg(Color.Transparent);
                DDLColor.DropDownItems.Add("None", colorImg);
                DDLColor.DropDownItems[0].AutoSize = false;
                DDLColor.DropDownItems[0].Size = new Size(160, 18);
                DDLColor.Tag = Color.Lime;

            }
            else
            {
                ColorButton.Image = GetColorSelectedImg(Color.Black.Name, "Color");
                DDLColor.Tag = Color.Black;
            }


            for (int i = 0; i < TextColorName.Length; i++)
            {
                //Fuchsia
                string colorName = TextColorName[i];
                Color imgColor = UsualColors[i];
                Image colorImg = CreatColorImg(imgColor);
                DDLColor.DropDownItems.Add(colorName, colorImg);
                DDLColor.DropDownItems[i].AutoSize = false;
                DDLColor.DropDownItems[i].Size = new Size(160, 18);

            }




        }
        #endregion

        #region TSDDLColor_DropDownItemClicked
        /// <summary>
        /// Color dropdownlist Item click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void TSDDLColor_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            //change the button color
            ToolStripDropDownButton tsddb = (ToolStripDropDownButton)sender;
            TSBColor.Image = GetColorSelectedImg(e.ClickedItem.Text, "Color");
            //change the text color
            if (this.SelectedRichTextBox != null)
            {

                tsddb.Tag = Color.FromName(e.ClickedItem.Text);
                this.SelectedRichTextBox.SelectionColor = Color.FromName(e.ClickedItem.Text);
            }

        }
        #endregion

        #region GetColorSelectedImg
        private Image GetColorSelectedImg(string ColorName, string imgName)
        {

            Image img = null;
            if (imgName == "Color")
            {
                img = global::GLTc.QuickNote.Properties.Resources.TextColor;
            }
            else if (imgName == "BackColor")
            {
                img = global::GLTc.QuickNote.Properties.Resources.TextBackColor;
            }
            Graphics gdi = Graphics.FromImage(img);
            Color selectedColor = Color.FromName(ColorName);
            SolidBrush mySolidBrush = new SolidBrush(selectedColor);
            gdi.FillRectangle(mySolidBrush, 0, 12, 16, 4);

            return img;

        }
        #endregion

        #region CreatColorImg
        /// <summary>
        /// Creat one color image
        /// </summary>
        /// <param name="imgColor"></param>
        /// <returns></returns>
        private Image CreatColorImg(Color imgColor)
        {
            Bitmap colorImg = new Bitmap(16, 16);
            Graphics gpi = Graphics.FromImage(colorImg);
            SolidBrush sb = new SolidBrush(imgColor);
            gpi.FillRectangle(sb, 0, 0, 16, 16);

            return colorImg;
        }
        #endregion




    }
}
