using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GLTc.NoteLib;

namespace GLTc.QuickNote
{
    public partial class NewNode : Form
    {
        public NewNode()
        {
            
            InitializeComponent();
            this.btnConfirm.DialogResult = DialogResult.OK;
            this.btnCancel.DialogResult = DialogResult.Cancel;
            ComBxDataBind();
        }

        /// <summary>
        /// Node type Id
        /// </summary>
        public int NodeTypeId
        {
            get
            {
               return  int.Parse(this.CBBNodeType.SelectedValue.ToString());
              
            }

        }

        /// <summary>
        /// set the Node Type selected Index
        /// </summary>
        public int  SelectedNodeTypeIndex
        {
            set
            {
                this.CBBNodeType.SelectedValue = value;
                this.TbNodeText.Focus();
            }
        }

        /// <summary>
        /// the New Node Name
        /// </summary>
        public string NodeText
        {
            get
            {
                return this.TbNodeText.Text;
            }
        }


        #region ComBxDataBind
        private void ComBxDataBind()
        {
            string sqlText = "Select * from NodeType where NodeTypeId <> 0 ";
            AccessDatabase ADB = new AccessDatabase();
            DataSet ds = ADB.ExecuteDataSet(sqlText, "NodeType");
            this.CBBNodeType.DataSource = ds.Tables[0];
            this.CBBNodeType.DisplayMember = "NodeTypeText";
            this.CBBNodeType.ValueMember = "NodeTypeId";
            


 
        }
#endregion

    }
}