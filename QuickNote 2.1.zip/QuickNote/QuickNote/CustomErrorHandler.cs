using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;

namespace GLTc.QuickNote
{
    public partial class CustomErrorHandler : Form
    {
        public string AssemblyDescription
        {
            get
            {
                // Get all Description attributes on this assembly
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false);
                // If there aren't any Description attributes, return an empty string
                if (attributes.Length == 0)
                    return "";
                // If there is a Description attribute, return its value
                return ((AssemblyDescriptionAttribute)attributes[0]).Description;
            }
        }

        public Exception ErrorException;
        public CustomErrorHandler(Exception unhandledException  )
        {
            this.ErrorException = unhandledException;
            InitializeComponent();
        }

        private void btnErrorMessage_Click(object sender, EventArgs e)
        {
            ShowInformation();
            this.tbInformation.Text = this.ErrorException.Message;
        }

        private void btnSupportTeam_Click(object sender, EventArgs e)
        {
            ShowInformation();
            this.tbInformation.Text = AssemblyDescription;
        }

        private void ShowInformation()
        {
            if (this.scErrorMessage.Panel2Collapsed)
            {
                this.Height = 288;
                this.scErrorMessage.SplitterDistance = 68;
                this.scErrorMessage.Panel2Collapsed = false;
            }
 
        }
    }
}