using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
namespace GLTc.QuickNote.Command
{
    public class ContextBaseInfo:BaseOperator
    {
        /// <summary>
        /// the contextinfo rowid
        /// </summary>
        public string ContextInfoID;

        /// <summary>
        /// the title of the treenode
        /// </summary>
        public string ContextNodeTitle;

        /// <summary>
        /// the display title of the tabcontrol
        /// </summary>
        public string ContextDisplayName;

        /// <summary>
        /// the path of the node in the tree
        /// </summary>
        public string FullPath;

        private bool isChanged; 
        /// <summary>
        /// is the richtextbox changed
        /// </summary>
        public bool IsChanged
        {
            get
            {
                //if two title is not equal, it means that the richtextbox has been changed
                isChanged = ContextDisplayName != ContextNodeTitle;
                return isChanged;
            }

            set
            {
                isChanged = value;
                ContextDisplayName = ContextNodeTitle;
                this.RightMainForm.SelectedTab.Text = ContextDisplayName;

            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="contextInfoID">the contextinfo rowid</param>
        /// <param name="isTextChanged">store whether the richtextbox changed state</param>
        public ContextBaseInfo(string contextInfoID, string contextNodeTitle,string NodeFullPath,TabControl MainTabControl)
        {
            this.ContextInfoID = contextInfoID;
            this.ContextNodeTitle = contextNodeTitle;
            this.ContextDisplayName = contextNodeTitle;
            this.FullPath = NodeFullPath;
            this.RightMainForm = MainTabControl;

        }

    }
}
