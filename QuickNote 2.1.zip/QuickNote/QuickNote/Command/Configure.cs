using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Drawing.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using System.Data.Common;
using GLTc.NoteLib;
using GLTc.QuickNote;

namespace GLTc.QuickNote.Command
{

    // the usual color
    public enum TextColor { Black, Maroon, Green, Olive, Navy, Purple, Teal, Gray, Silver, Red, Lime, Yellow, Blue, Fuchsia, Aqua, White };

    public enum ZoomSize { P010, P025, P050, P075, P100, P150, P200, P500 };
    /// <summary>
    /// default configure for quick note
    /// </summary>
    public class Configure
    {
        
        #region DefaultFont
        private static Font defaultFont;
        /// <summary>
        /// the default font
        /// </summary>
        public  static Font DefaultFont
        {
            get
            {
                if (defaultFont == null)
                {

                    defaultFont = new Font("Arial", 10, FontStyle.Regular);

                }
                return defaultFont;
            }

        }
        #endregion 
    }
}
