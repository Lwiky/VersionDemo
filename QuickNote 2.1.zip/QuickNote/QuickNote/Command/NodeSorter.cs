using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Collections;
namespace GLTc.QuickNote.Command
{
    public class NodeSorter : IComparer
    {
        // Compare the the strings
        public int Compare(object x, object y)
        {
            TreeNode tx = x as TreeNode;
            TreeNode ty = y as TreeNode;

            return String.Compare(tx.Text, ty.Text);
        }
    }

}
