using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using System.Data.Common;
using GLTc.NoteLib;
using GLTc.QuickNote;

namespace GLTc.QuickNote.Command
{
    /// <summary>
    /// the index of the Context
    /// </summary>
    public class IndexOperator
    {

        private TabPage currentIndexTablePage;
        /// <summary>
        /// the search tabpage of left window
        /// </summary>
        public TabPage CurrentIndexTablePage
        {
            get { return currentIndexTablePage; }
            set { currentIndexTablePage = value; }
        }

        private TextBox indexTextBox;
        /// <summary>
        /// Search text box 
        /// </summary>
        public TextBox IndexTextBox
        {
            get {
                if (this.indexTextBox == null)
                {
                    this.indexTextBox = (TextBox)this.CurrentIndexTablePage.Controls["IndexTableLayOut"].Controls["TPIndexCondition"];
                }

                return indexTextBox; 
            }
   
        }

        private ListBox indexListBox;
        /// <summary>
        /// Search list view
        /// </summary>
        public ListBox IndexListBox
        {
            get
            {
                if (this.indexListBox == null)
                {
                    this.indexListBox = (ListBox)this.CurrentIndexTablePage.Controls["IndexTableLayOut"].Controls["TPIndexListBox"];
                }

                return indexListBox;
            }

        }


        #region RightMainForm
        private ContextOperator currentContextOperator;
        /// <summary>
        /// the right tabcontrol of the main form
        /// for display the multi richtextboxes
        /// </summary>
        public ContextOperator CurrentContextOperator
        {
            get { return currentContextOperator; }
            set { currentContextOperator = value; }
        }
        #endregion 

        public TreeView CurrentTree ;

        private AccessDatabase adb;
        /// <summary>
        /// the access databse
        /// </summary>
        private AccessDatabase ADB
        {
            get
            {
                if (adb == null)
                {
                    adb = new AccessDatabase();
                }
                return adb;
            }
        }


        public IndexOperator(TabPage IndexTablePage, ContextOperator RightContextOperator, TreeView LeftTreeOpertor)
        {
            this.CurrentIndexTablePage = IndexTablePage;
            this.CurrentContextOperator = RightContextOperator;
            this.CurrentTree = LeftTreeOpertor;
            this.IndexListBox.DoubleClick += new EventHandler(SearchListBox_DoubleClick);
 
        }

        void SearchListBox_DoubleClick(object sender, EventArgs e)
        {
            if (this.IndexListBox.SelectedItem != null)
            {
                //SearchItem scItem = (SearchItem)this.IndexListBox.SelectedItem;
                //string nodeName = TreeOperator.GetTreeNodeName(scItem.ContextID);
               // TreeNode[] SearchedNode = this.CurrentTree.Nodes.Find(nodeName, true);
                string contextId = ((SearchItem)this.indexListBox.SelectedItem).ContextID;
                string NodeTitle = ((SearchItem)this.indexListBox.SelectedItem).ShowText;
                string FullPath = SearchOperator.BuildContextPath(contextId);
                this.CurrentContextOperator.OpenSearchContext(NodeTitle, contextId, FullPath,  this.indexTextBox.Text.ToString().Replace("'", "''"));
            }
        }
        /// <summary>
        /// search through all the database
        /// and display the find list in list view 
        /// </summary>
        public int IndexTextSearch()
        {
            string sqlText = string.Format(@"select CI.ContextInfoID ,CT.NodeName  from ContextInfo AS CI Left Join ContextTree AS CT
                                             on CI.ContextInfoID =  CT.ContextTreeID
                                                where (CI.IndexString Like '%{0}%' or CT.NodeName Like '%{0}%' ) and CT.NodeTypeID = 2"
                            , this.IndexTextBox.Text.Trim().Replace("'","''"));
            DataSet ds = this.ADB.ExecuteDataSet(sqlText);
            this.IndexListBox.Items.Clear();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                SearchItem scItem = new SearchItem(dr["ContextInfoID"].ToString(), dr["NodeName"].ToString());
                this.IndexListBox.Items.Add(scItem);
            }

            return ds.Tables[0].Rows.Count;
        }
    }
}
