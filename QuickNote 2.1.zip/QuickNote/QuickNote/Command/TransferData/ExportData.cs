using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.Threading;
using ADOX;
using GLTc.NoteLib;

namespace GLTc.QuickNote.Command.TransferData
{
    /// <summary>
    /// The export data to new file
    /// </summary>
    public class ExportData
    {
        #region Fileds
        private const string TreeViewDataTableName = "ContextTree";
        private const string ExportTableName = "ExportTempTable";
        private const string CopyTableName = "CopyTempTable";
        private string CurrentBaseDirectory = AppDomain.CurrentDomain.BaseDirectory;
        private const string ExportDirectoryName = "ExportData";
        #endregion 

        /// <summary>
        /// the base database Operator 
        /// </summary>
        private AccessDatabase BaseADC = new AccessDatabase();
        /// <summary>
        /// the Export database Operator
        /// </summary>
        private AccessDatabase ExportADC;

        /// <summary>
        /// Export tips window
        /// </summary>
        private ExportImportTips EIT = new ExportImportTips();

        #region ExportDirectoryFullName
        /// <summary>
        /// Current Export Directory Full Path 
        /// </summary>
        private string ExportDirectoryFullName
        {
            get
            {
                return CurrentBaseDirectory + ExportDirectoryName;
            }
        }
        #endregion 

        #region sqlContextTreeClause
        /// <summary>
        /// Create table ContextTreeClause 
        /// </summary>
        private string sqlContextTreeClause = @"Create Table  ContextTree 
                     ( ContextTreeID   varchar(36) primary key,
                       NodeName  varchar(64)  ,
                       ParentID  varchar(36) , 
                       NodeTypeID  int ,
                       CreateTime  Date,
                       UpdateTIme  Date  ) "; 

        /// <summary>
        /// Create table ContextInfo
        /// </summary>
        private string  sqlContextInfoClause = @"Create Table  ContextInfo
                                                     (ContextInfoID   varchar(36) primary key,
                                                       ContextRTF  Memo ,
                                                       ContextText Memo , 
                                                       IndexString  varchar(128) ,
                                                       CreateTime  Date,
                                                       UpdateTIme  Date ) ";
        /// <summary>
        /// Create Export table sql Clause
        /// </summary>
        private string sqlCreateExportTableClause = @"Create Table  ExportTempTable 
                                                ( ExportID   varchar(36) primary key)";

        #endregion 

        /// <summary>
        /// the access databse
        /// </summary>
        private AccessDatabase ADB = new AccessDatabase();

        private string ConStr = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Jet OLEDB:Engine Type=5";

        private string ExportFileName;
        /// <summary>
        /// Export connection string 
        /// </summary>
        private string ExportConnnectionString
        {
            get
            {
                return string.Format(ConStr, ExportFileName);
            }
        }

        private string parentContextId;

        /// <summary>
        /// Parent ID, export note ID
        /// </summary>
        public string ParentContextId
        {
            get { return parentContextId; }
            set { parentContextId = value; }
        }


        #region Constuctor
        public ExportData(string ParentId)
        {
            this.ParentContextId = ParentId;

        }
        public ExportData()
        {

        }
        #endregion 

        #region CreateExportFile
        /// <summary>
        /// Create new ExportDatabase file
        /// </summary>
        public bool  SaveExportFile(string DefaultName)
        {

            bool IsCreated = false;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            this.CreatDefaultExportDirectory();
            saveFileDialog.SupportMultiDottedExtensions = true;
            saveFileDialog.InitialDirectory = ExportDirectoryFullName;
            saveFileDialog.FileName = DefaultName += ".mdb";
            saveFileDialog.Title = "Export to";
            saveFileDialog.Filter = "Access File (*.mdb)|*.mdb";
            saveFileDialog.FilterIndex = 0;
            
            saveFileDialog.RestoreDirectory = true;
            if (saveFileDialog.ShowDialog() == DialogResult.OK )
            {
                try
                {

                    this.ExportFileName = saveFileDialog.FileName;
                    //if (ExportFileName.Substring(ExportFileName.LastIndexOf('.')) != ".mdb")
                    //{
                    //    this.ExportFileName += ".mdb";
                    //}
                    this.CreateExportFile(this.ExportFileName);
                    IsCreated = true;
                    saveFileDialog.Dispose();
                }
                catch 
                {
                    throw (new Exception("Create Database Failed"));
                }

            }
            return IsCreated;

        }
        #endregion 

        #region CreatDefaultExportDirectory
        /// <summary>
        /// Create default exportDirectory
        /// </summary>
        private void CreatDefaultExportDirectory()
        {
            if (! Directory.Exists(ExportDirectoryFullName))
            {
                Directory.CreateDirectory(ExportDirectoryFullName);
            }
        }
        #endregion 

        #region CreateExportFile
        /// <summary>
        /// Create Export FIle
        /// </summary>
        /// <param name="FileName"></param>
        private void CreateExportFile(string FileName)
        {
            if(File.Exists(FileName))
            {
                File.Delete(FileName);
            }
            ADOX.CatalogClass cat = new ADOX.CatalogClass();
            string constr = string.Format(ExportConnnectionString);
            cat.Create(constr);
        }
        #endregion 
        
        #region CreateDataTable
        /// <summary>
        /// Create Exprot table
        /// </summary>
        private void CreateDataTable()
        {
            this.ExportADC.ExecuteNonQuery(sqlContextTreeClause);
            this.ExportADC.ExecuteNonQuery(sqlContextInfoClause);


        }
        #endregion 

        /// <summary>
        /// Export Data to new Database File
        /// </summary>
        /// <param name="ParentID"></param>
        /// <param name="DefaulName"></param>
        public  void ExportDataToAccessFile(string  ParentID,string DefaulName)
        {
            //Create export file firt
            bool IsCreated = this.SaveExportFile(DefaulName);
           if (IsCreated)
           {
               Thread ExportTipsThread = new Thread(new ThreadStart(new ControlExportInportTipWindow(this.ShowExportWindow)));
               ExportTipsThread.Start();

               CreateExportTable();
               //instance the ExportDataAccess
               this.ExportADC = new AccessDatabase(this.ExportFileName);
               //insert export ContextId to exporttable
               this.InsertContextIdIntoExportTable(ParentID);
               //create contexTree table and ContextInfo Table
               this.CreateDataTable();
               //transfer data to Export file
               this.TransferData();
               this.EIT.BeginInvoke(new ControlExportInportTipWindow(this.CloseExportWindow));
           }


       }

        #region ShowExportWindow
       /// <summary>
        /// show import tips windows
        /// </summary>
        private void ShowExportWindow()
        {
            this.EIT.ShowDialog();

        }
       #endregion 

        #region CloseExportWindow
        /// <summary>
        /// Close import tips windows
        /// </summary>
        private void CloseExportWindow()
        {
            this.EIT.Close();
        }
        #endregion

        #region TransferData
        /// <summary>
        /// Transfer Data to exportfile table
        /// </summary>
        private void TransferData()
        {

            //just wanto keep the squence of Exporttable
            string contextTreeSqlClause = string.Format(@"Select B.* from  ExportTempTable AS A  LEFT JOIN ContextTree AS B
                                                        On A.ExportID = B.ContextTreeID");

            string contextInfoSqlClause = string.Format(@"Select * from  ContextInfo  where ContextInfoID in 
                                          (Select ExportID from ExportTempTable )");

            string exportContextTreeSqlClause = "Select * from ContextTree";
            string exportContextInfoSqlClause = "Select * from ContextInfo";

            //load Context tree
            LoadDataToDataTable(exportContextTreeSqlClause, "ContextTree", contextTreeSqlClause);

            //load Context Info
            LoadDataToDataTable(exportContextInfoSqlClause, "ContextInfo", contextInfoSqlClause);

           


        }
        #endregion 
        
        #region LoadDataToDataTable
        /// <summary>
        /// load data to data table
        /// </summary>
        /// <param name="sqlText"></param>
        /// <param name="TableName"></param>
        /// <param name="SourceTableSqlText"></param>
        private void LoadDataToDataTable(string sqlText,string TableName, string SourceTableSqlText)
        {
            DataSet origanlDs = this.ExportADC.ExecuteDataSet(sqlText, TableName);
            DataSet SourceDs = this.ADB.ExecuteDataSet(SourceTableSqlText);
            foreach (DataRow dr in SourceDs.Tables[0].Rows)
            {

                DataRow newdr = origanlDs.Tables[0].NewRow();
                for(int i = 0; i < SourceDs.Tables[0].Columns.Count ;i++)
                {
                    newdr[i] = dr[i];
 
                }
                origanlDs.Tables[0].Rows.Add(newdr);
            }
            this.ExportADC.UpdateDataSet(origanlDs);

        }
        #endregion 

        #region InsertContextIdIntoExportTable
        /// <summary>
        /// Insert Exporting Data to ExportTable 
        /// </summary>
        /// <param name="ParentID">ParentID</param>
        private void InsertContextIdIntoExportTable(string ParentID)
        {
            //Delete All record in Exporttable
            string DeleteSqlText = string.Format("Delete From {0}  ", ExportTableName);
            this.ADB.ExecuteNonQuery(DeleteSqlText);

            //All Tree Nodes 
            string NodeSqlText = string.Format("Select ContextTreeID,ParentID From {0}  ", TreeViewDataTableName);
            DataSet NodeDs = this.ADB.ExecuteDataSet(NodeSqlText);

            //Get the Export DataTable
            string sqlText = string.Format("Select * from {0} ", ExportTableName);
            DataSet ds = this.ADB.ExecuteDataSet(sqlText, ExportTableName);

            //Insert Data  to Export DataTable

            InsertContextIdIntoExportTable(ParentID, NodeDs.Tables[0], ds.Tables[0]);
            this.ADB.UpdateDataSet(ds);
           
    



        }
        #endregion 

        #region InsertContextIdIntoExportTable
        /// <summary>
        /// recursive insert data to Export datatable 
        /// </summary>
        /// <param name="ParentID"></param>
        /// <param name="NodeTable"></param>
        /// <param name="ExportTable"></param>
        private void InsertContextIdIntoExportTable(string ParentID, DataTable NodeTable ,DataTable ExportTable)
        {
            DataRow[] childrendrs = NodeTable.Select(string.Format("ParentID = '{0}'", ParentID));
            DataRow[] parentdrs = NodeTable.Select(string.Format("ContextTreeId = '{0}'", ParentID));

            //all  current row
            if (parentdrs.Length > 0)
            {
                DataRow dr = ExportTable.NewRow();
                dr[0] = parentdrs[0]["ContextTreeId"].ToString();
                ExportTable.Rows.Add(dr);

            }
  
            foreach (DataRow dr in childrendrs)
            {
                InsertContextIdIntoExportTable(dr["ContextTreeId"].ToString(), NodeTable, ExportTable);
            }

        }
        #endregion 

        #region CreateExportTable
        /// <summary>
        /// If the export table not exist in current Database, creat it 
        /// </summary>
        private void CreateExportTable()
        {
            DataTable tableInfo = GetAllTablesInDataBase();
            DataRow[] drs = tableInfo.Select(string.Format("Table_Name = '{0}'",ExportTableName));
            if (drs.Length <= 0)
            {
                this.ADB.ExecuteNonQuery(sqlCreateExportTableClause);
            }

        }
        #endregion 


        #region GetAllTablesInDataBase
        /// <summary>
        /// get all the table in access database
        /// </summary>
        /// <returns></returns>
        private DataTable GetAllTablesInDataBase()
        {
            DataTable schemaTable = null;
            using (OleDbConnection connection = AccessDatabase.CreateConnnection())
            {
                connection.Open();
                 schemaTable = connection.GetOleDbSchemaTable(
                    OleDbSchemaGuid.Tables,
                    new object[] { null, null, null, "TABLE" });
                
            }
            return schemaTable;

        }
        #endregion 








    }
}
