using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using GLTc.QuickNote.CustomControl;

namespace GLTc.QuickNote.Command
{
    /// <summary>
    /// Clost tips window
    /// </summary>
    public delegate void SetTipsWindowCallback();

    public class BaseOperator
    {
        /// <summary>
        /// Use for full text search and save content
        /// </summary>
        public static CustomRichTextBox TransferRichTextBox = new CustomRichTextBox();

        private TabControl rightMainForm;
        /// <summary>
        /// the right tabcontrol of the main form
        /// for display the multi richtextboxes
        /// </summary>
        public TabControl RightMainForm
        {
            get { return rightMainForm; }
            set { rightMainForm = value; }
        }

    }
}
