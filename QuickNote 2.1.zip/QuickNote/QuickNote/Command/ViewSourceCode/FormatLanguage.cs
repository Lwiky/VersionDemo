using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using GLTc.QuickNote.CustomControl;

namespace GLTc.QuickNote.Command
{
    /// <summary>
    /// formate the string in certain language
    /// </summary>
    public class FormatLanguage :BaseOperator
    {
        #region static Fileds
        /// <summary>
        /// language configration xml File
        /// </summary>
        private static string LanguageConfigrationDocumentPath = @"Configuration\LanguageConfig.xml";

        private  string KeywordPath = "LanguageConfig/{0}/KeyWord";
        private  string CommentPath = "LanguageConfig/{0}/CommentFormat";
        private  string CustomRulePath = "LanguageConfig/{0}/CustomRule/Rule";
        #endregion 

        /// <summary>
        /// custom Rule store in Hashtable for reference quickly
        /// </summary>
        private Hashtable CustomRuleHashTable = new Hashtable();


        /// <summary>
        /// Source Code with Comment
        /// </summary>
        private string OriganlSourceCode;

        #region SelectedRichTextBox
        /// <summary>
        /// the selected RichTextbox
        /// </summary>
        public CustomRichTextBox SelectedRichTextBox;
        #endregion

        #region SelectedSplitContainerInTabPage
        /// <summary>
        /// the selected splitContainer in the Tappage
        /// </summary>
        public SplitContainer SelectedSplitContainerInTabPage
        {
            get
            {
                SplitContainer selectedSplitContainer = null;
                TabPage selectedPage = this.RightMainForm.SelectedTab;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        string tabpagePannelID = ContextOperator.GetSplitContainerName(cbi.ContextInfoID);

                        selectedSplitContainer = (SplitContainer)selectedPage.Controls[tabpagePannelID];
                    }
                }

                return selectedSplitContainer;

            }
        }
        #endregion 

        #region keywordHighLightColor
        private string  keywordHighLightColor = @"\red20\green0\blue200";
        /// <summary>
        /// key word highlight color
        /// </summary>
        public string KeywordHighLightColor
        {
            get
            {
                if (keywordHighLightColor == @"\red20\green0\blue200")
                {
                    keywordHighLightColor = this.languageConfigrationDocument.SelectSingleNode(KeywordPath).Attributes["Color"].Value;
                }
                return keywordHighLightColor;

            }

        }
        #endregion 

        #region CommentHighLightColor
        private string commentHighLightColor = @"\red20\green156\blue0";
        /// <summary>
        /// key word highlight color
        /// </summary>
        public string  CommentHighLightColor
        {
            get
            {
                if (commentHighLightColor == @"\red20\green156\blue0")
                {
                    commentHighLightColor = this.languageConfigrationDocument.SelectSingleNode(CommentPath).Attributes["Color"].Value;
                   
                }
                return commentHighLightColor;

            }

        }
        #endregion 

        #region LanguageConfigrationDocument
        private XmlDocument languageConfigrationDocument;
        /// <summary>
        /// the xmlDocument of language configration
        /// </summary>
        public XmlDocument LanguageConfigrationDocument
        {
            get { return languageConfigrationDocument; }
            set { languageConfigrationDocument = value; }
        }
        #endregion 

        #region Constructor
        /// <summary>
        /// Format constructor
        /// </summary>
        /// <param name="FomatString"></param>


        public FormatLanguage(CustomRichTextBox selectedRichTextBox, string LanguageSectionName)
        {
            this.SelectedRichTextBox = selectedRichTextBox;
            this.KeywordPath = string.Format(KeywordPath, LanguageSectionName);
            this.CommentPath = string.Format(CommentPath, LanguageSectionName);
            this.CustomRulePath = string.Format(CustomRulePath, LanguageSectionName);
            
        }

        #endregion 

        #region GetWholeRegularExpress
        /// <summary>
        /// consolidate the whole regular expression
        /// </summary>
        /// <returns></returns>
        private string GetWholeRegularExpression()
        {
            string wholeRegularExpress = null;
            this.LoadXmlConfiguration();
            wholeRegularExpress += this.GetKeywordRegularExpress() +"|";
            wholeRegularExpress += this.GetCommentRegularExpress();
            string customRegularExpresstion = this.GetConsolidateCustomRuleRegularExpress();
            //if the custome regular express is not null or empty, add "|" and the customer rule;
            if (!string.IsNullOrEmpty(customRegularExpresstion))
            {
                wholeRegularExpress += "|"+ customRegularExpresstion;
                
            }

            return wholeRegularExpress;
        }
        #endregion 

        #region GetKeywordRegularExpress
        /// <summary>
        /// build Key word regular express
        /// \sEXSR\s|\sIF\s|
        /// </summary>
        /// <returns></returns>
        private string GetKeywordRegularExpress()
        {
            string keywordExpress = null;
            XmlNode keyWordNode = this.languageConfigrationDocument.SelectSingleNode(KeywordPath);
            string rpgKeyWordString = keyWordNode.InnerText;
            string[] KeywordArray = rpgKeyWordString.Split(',');
            for (int i = 0; i < KeywordArray.Length; i++)
            {
                keywordExpress += @"\b" + KeywordArray[i] + @"\b";

                if (i + 1 < KeywordArray.Length)
                {
                    keywordExpress += "|";
                }
            }
            return keywordExpress;

        }
        #endregion 
        
        #region GetCommentRegularExpress
        /// <summary>
        /// get the comment regular expression 
        /// </summary>
        /// <returns></returns>
        public string GetCommentRegularExpress()
        {
            string commentRegularExpression  = null;
            commentRegularExpression = this.languageConfigrationDocument.SelectSingleNode(CommentPath).InnerText;
            return commentRegularExpression;
        }
        #endregion 

        #region GetConsolidateCustomRuleRegularExpress
        /// <summary>
        /// Get the custom regular express
        /// </summary>
        /// <returns></returns>
        private string GetConsolidateCustomRuleRegularExpress()
        {
            string customRuleExpress = null;
            XmlNodeList customRuleList = this.languageConfigrationDocument.SelectNodes(CustomRulePath);
            for (int i = 0; i < customRuleList.Count; i++)
            {
                customRuleExpress += customRuleList[i].InnerText;
                if (i + 1 < customRuleList.Count)
                {
                    customRuleExpress += "|";
                }
 
            }
            return customRuleExpress;
        }
        #endregion 

        #region MoveCustomRuleToHashTable
        /// <summary>
        /// Move CustomeRule to Hashtable
        /// </summary>
        private void MoveCustomRuleToHashTable()
        {
            string customRuleExpress = null;
            XmlNodeList customRuleList = this.languageConfigrationDocument.SelectNodes(CustomRulePath);
            for (int i = 0; i < customRuleList.Count; i++)
            {
                customRuleExpress += customRuleList[i].InnerText;
                this.CustomRuleHashTable.Add(customRuleList[i].InnerText, customRuleList[i].Attributes["Color"].Value);
            }

        }
        #endregion 

        #region ExcuteRegularExpressRule
        /// <summary>
        /// Excute the regular express rule
        /// firstly , change the comment color
        /// secondly , change custom rule color
        /// finnaly ,  change keyword color
        /// </summary>
        public  void ExcuteRegularExpressRule()
        {
            CustomRichTextBox transferRichtextBox = new CustomRichTextBox();
            transferRichtextBox.Rtf = this.SelectedRichTextBox.Rtf;
            string currentRichText = transferRichtextBox.Text;
            Regex wholeReg = new Regex(this.GetWholeRegularExpression());
            Regex commentReg = new Regex(this.GetCommentRegularExpress());
            this.MoveCustomRuleToHashTable();
            MatchCollection mc = wholeReg.Matches(currentRichText);
            foreach (Match mt in mc)
            {
                transferRichtextBox.Select(mt.Index, mt.Length);
                if (commentReg.Match(mt.ToString()).Success)
                {
                    //match comment
                   // transferRichtextBox.SelectionColor = this.CommentHighLightColor;
                }
                else if (MatchCustomRegularExpression(mt.ToString()) != Color.White)
                {
                    // match custom rule 
                   // transferRichtextBox.SelectionColor = MatchCustomRegularExpression(mt.ToString());

                }
                else
                {
                    //match keyword
                   // transferRichtextBox.SelectionColor = this.KeywordHighLightColor;

                }
            }
            this.SelectedRichTextBox.Rtf = transferRichtextBox.Rtf;
            
        }
        #endregion 

        #region HighLightByRegularExpressRule
        /// <summary>
        /// Excute the regular express rule
        /// firstly ,  change keyword color
        /// secondly , change custom rule color
        /// finnaly ,  change the comment color
        /// </summary>
        public void HighLightByRegularExpressRule()
        {
            CustomRichTextBox transferRichtextBox = new CustomRichTextBox();
            transferRichtextBox.Font = new Font("Courier New", 10);
            transferRichtextBox.Text = this.SelectedRichTextBox.Text;
            string HighlightRTF = transferRichtextBox.Rtf;
            this.LoadXmlConfiguration();
            this.MoveCustomRuleToHashTable();
            HighlightRTF = HighlightRTF.Insert(transferRichtextBox.Rtf.IndexOf(@"\viewkind4"), this.BuildColorList());
            Regex keywordReg = new Regex(this.GetKeywordRegularExpress());
            Regex commentReg = new Regex(this.GetCommentRegularExpress());
            Regex customReg = new Regex(this.GetConsolidateCustomRuleRegularExpress());
            //hightlight Keyword 
            HighlightRTF = keywordReg.Replace(HighlightRTF, new MatchEvaluator(LightKeyword));
            //hightlight CustomRule
            HighlightRTF = customReg.Replace(HighlightRTF, new MatchEvaluator(LightCustomRule));
            //hightLight Comment line
            HighlightRTF = commentReg.Replace(HighlightRTF, new MatchEvaluator(CommentLine));
            this.SelectedRichTextBox.Rtf = HighlightRTF;

        }

        /// <summary>
        /// Hightlight Key word
        /// </summary>
        /// <param name="mt"></param>
        /// <returns></returns>
        private string LightKeyword(Match mt)
        {
            string colorCode = @"\cf1 " + mt.Value + @"\cf0 ";
            return colorCode;
        }

        /// <summary>
        /// Hightlight Comment
        /// </summary>
        /// <param name="mt"></param>
        /// <returns></returns>
        private string CommentLine(Match mt)
        {
            string color = @"\\cf\d[\s]?";
            int iscontainPar = mt.Value.IndexOf("\\par\r");
            string str = mt.Value.Replace("\\par\r", "");
            Regex cl = new Regex(color, RegexOptions.IgnoreCase);
            str = cl.Replace(str, "");
            string colorCode = @"\cf2 " + str + @"\cf0";
            if (iscontainPar > 0)
            {
                colorCode += "\\par\r";
            }
            return colorCode;

        }
        /// <summary>
        /// Hightlight the custom rule
        /// </summary>
        /// <returns></returns>
        private string LightCustomRule(Match mt)
        {
            string colorCode = mt.Value;
            int indexOfHashTable = 0;
            foreach (object obj in this.CustomRuleHashTable.Keys )
            {   
                indexOfHashTable +=1;
                Regex customRule = new Regex(obj.ToString());
                if (customRule.Match(mt.Value).Success)
                {
                    colorCode = string.Format(@"\cf{0} " + mt.Value + @"\cf0 ", (indexOfHashTable + 2)); 
                    break;
                }

            }
            return colorCode;
 
        }

        #endregion 

        #region BuildColorList
        /// <summary>
        /// build Color List for RTF
        /// First  Key word
        /// Second Comment Color
        /// Third  Custom Rule
        /// 
        /// </summary>
        /// <returns></returns>
        private string BuildColorList()
        {
            string rtfColor = @"{\colortbl ;";
            rtfColor += this.keywordHighLightColor+ ";";
            rtfColor += this.CommentHighLightColor + ";";
            foreach (object obj in CustomRuleHashTable.Values)
            {
                rtfColor += obj.ToString() + ";";
            }
            rtfColor += "}";
            return rtfColor;
        }
        #endregion 

        #region MatchCustomRegularExpression
        /// <summary>
        /// check is match the custom regular expression after keyword and comment one by one
        /// </summary>
        private Color MatchCustomRegularExpression(string rawString)
        {
            Color customColor = Color.White;
            foreach (object obj in this.CustomRuleHashTable.Keys)
            {
                Regex customRule = new Regex(obj.ToString());
                if (customRule.Match(rawString).Success)
                {
                    customColor = Color.FromName(this.CustomRuleHashTable[obj].ToString());
                    break;
                }
            }
            return customColor;
        }
        #endregion 

        #region LoadXmlConfiguration
        /// <summary>
        /// Load language configration 
        /// </summary>
        /// <returns></returns>
        public void LoadXmlConfiguration()
        {
            LanguageConfigrationDocument = new XmlDocument();
            string xmlFileFullPath = Path.GetFullPath(LanguageConfigrationDocumentPath);
            if (File.Exists(xmlFileFullPath))
            {
                LanguageConfigrationDocument.Load(xmlFileFullPath);
            }
            else
            {
                throw (new IOException("language Configuration file was not found !"));
            }

        }
        #endregion 

        #region ShowOriganalSource
        /// <summary>
        /// Show the comment
        /// </summary>
        public void ShowOriganalSource()
        {
            if (!string.IsNullOrEmpty(this.OriganlSourceCode))
            {
                this.SelectedRichTextBox.Rtf = this.OriganlSourceCode;
            }
        }
        #endregion

        #region HideCommentOfSource
        /// <summary>
        /// Hidden the Comment
        /// </summary>
        public void HideCommentOfSource()
        {
            if (string.IsNullOrEmpty(this.OriganlSourceCode))
            {
                this.OriganlSourceCode = this.SelectedRichTextBox.Rtf;
                this.LoadXmlConfiguration();
            }
            string commentRegstr = @"(\\cf\d[\s]{0,7}" + this.GetCommentRegularExpress() + ")+";
            Regex commentReg = new Regex(commentRegstr);
            this.SelectedRichTextBox.Rtf = commentReg.Replace(this.SelectedRichTextBox.Rtf, "");
        }
        #endregion 


    }
}
