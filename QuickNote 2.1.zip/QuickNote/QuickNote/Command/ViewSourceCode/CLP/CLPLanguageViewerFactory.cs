using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using GLTc.QuickNote.CustomControl;

namespace GLTc.QuickNote.Command.ViewSourceCode.CLP
{
    public class CLPLanguageViewerFactory : LanguageViewerFactory
    {
        public override LanguageViewer GetLanguageViewer(TabPage SelectTabPage)
        {
            return new CLPLanguageViewer(SelectTabPage);
        }
    }
}
