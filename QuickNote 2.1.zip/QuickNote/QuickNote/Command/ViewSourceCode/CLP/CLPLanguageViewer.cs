using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Windows.Forms;
using GLTc.QuickNote.CustomControl;
using System.Runtime.InteropServices;
using System.Configuration;

namespace GLTc.QuickNote.Command.ViewSourceCode.CLP
{
    public class CLPLanguageViewer : LanguageViewer
    {
        
        #region Constructor
        public CLPLanguageViewer(TabPage SelectTabPage)
        {
            this.SelectedTabPage = SelectTabPage;
          
        }




        #endregion 

        #region SelectedTabPage
        private TabPage selectedTabPage;
        /// <summary>
        /// the selected Tabpage  which is the parent control of richtextbox
        /// </summary>
        public override TabPage SelectedTabPage
        {

            get
            {
                return selectedTabPage;
            }
            set 
            {
                selectedTabPage = value;
            }
        }
        #endregion 

        #region SelectedRPGTool
        /// <summary>
        /// the selected RPGTool in the Tappage
        /// </summary>
        public RPGTool SelectedRPGTool
        {
            get
            {
                RPGTool currentrpgTool = null;
                TabPage selectedPage = this.selectedTabPage;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        string tabpagePannelID = ContextOperator.GetSplitContainerName(cbi.ContextInfoID);
                        string selectedRPGtoolId = ContextOperator.GetRPGToolName(cbi.ContextInfoID);
                        currentrpgTool = (RPGTool)(((SplitContainer)selectedPage.Controls[tabpagePannelID]).Panel2.Controls[selectedRPGtoolId]);
                    }
                }

                return currentrpgTool;

            }
        }
        #endregion 

        #region SelectedRichTextBox

        private CustomRichTextBox selectedRichTextBox;

        /// <summary>
        /// Current source code container
        /// </summary>
        public override CustomRichTextBox SelectedRichTextBox
        {
            get
            {
                if (selectedRichTextBox == null)
                {
                    if (SelectedTabPage != null)
                    {
                        ContextBaseInfo cbi = (ContextBaseInfo)SelectedTabPage.Tag;
                        if (cbi != null)
                        {
                            string tabpagePannelID = ContextOperator.GetSplitContainerName(cbi.ContextInfoID);
                            string selectedRichTextBoxId = this.GetRichTextBoxName(cbi.ContextInfoID);
                            Control[] ctrls = SelectedTabPage.Controls.Find(selectedRichTextBoxId, true);
                            if (ctrls.Length > 0)
                            {
                                selectedRichTextBox = (CustomRichTextBox)ctrls[0];
                            }

                        }
                    }
                }

                return selectedRichTextBox;
            }
        }
    #endregion 

                
        #region SelectedCLPSearchToolBar
        /// <summary>
        /// Selected RPG search toolbar
        /// </summary>
        public SearchToolBar SelectedCLPSearchToolBar
        {
            get
            {
                SearchToolBar clpSearchToolbar = null;
                if (this.SelectedTabPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)SelectedTabPage.Tag;
                    string searchtoolbarID = SearchToolBar.GetSearchToolbarID(cbi.ContextInfoID);
                    Control[] ctrls = this.SelectedTabPage.Controls.Find(searchtoolbarID, true);
                    clpSearchToolbar = (SearchToolBar)ctrls[0];
                }
                return clpSearchToolbar;
            }
        }
        #endregion 
                
        /// <summary>
        /// RPG format language
        /// </summary>
        private FormatLanguage FormatCLPLanguage;

        #region ViewSourceCode
        /// <summary>
        /// view source code by RPG format
        /// </summary>
        public override void ViewSourceCode()
        {

            //change the font to counter new and size to 10
            this.SelectedRichTextBox.Font = new Font("Courier New", 10);
            this.SelectedRichTextBox.TextColor = RtfColor.Black;
            this.SelectedRichTextBox.WordWrap = false;
            //highlist code color
            FormatCLPLanguage = new FormatLanguage(this.SelectedRichTextBox, "CLP");
            FormatCLPLanguage.HighLightByRegularExpressRule();
            //add event of searchbar
            this.SelectedCLPSearchToolBar.ShowAllSourceEvent += new ShowWholeSource(SelectedRPGSearchToolBar_ShowAllSourceEvent);
            this.SelectedCLPSearchToolBar.HideSourceCommentEvent += new HideSourceComment(SelectedRPGSearchToolBar_HideSourceCommentEvent);
            

        }
        #endregion 

        public override void HideCommentOfSource(CustomRichTextBox SourceRichtexbox)
        {

            if (string.IsNullOrEmpty(this.OriganlSourceCode))
            {
                this.OriganlSourceCode = SourceRichtexbox.Rtf;
                FormatCLPLanguage.LoadXmlConfiguration();
            }
            string commentRegstr = @"(\\cf\d[\s]{0,7}" + FormatCLPLanguage.GetCommentRegularExpress() + ")+";
            Regex commentReg = new Regex(commentRegstr);
            SourceRichtexbox.Rtf = commentReg.Replace(SourceRichtexbox.Rtf, "");

        }


        #region ShowandHideCommentofSource
        void SelectedRPGSearchToolBar_HideSourceCommentEvent()
        {
            this.HideCommentOfSource(this.SelectedRichTextBox);
        }

        void SelectedRPGSearchToolBar_ShowAllSourceEvent()
        {

            this.ShowOriganalSource();
        }
        #endregion 

    }
}
