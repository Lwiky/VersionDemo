using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Windows.Forms;
using GLTc.QuickNote.CustomControl;
using System.Runtime.InteropServices;
using System.Configuration;

namespace GLTc.QuickNote.Command.ViewSourceCode.RPG
{
    public class RPGLanguageViewer:LanguageViewer
    {
        [DllImport("user32.Dll")]
        private static extern bool GetCaretPos(out Point pos);

        private static int RPGSubroutineDepth = 5;
        /// <summary>
        /// RPG format language
        /// </summary>
        private FormatLanguage FormatRPGLanguage;

        //private int PreviousLineNum;
        //private int PreviousLineLength;
        private Point CurrentCaretPosition;

        #region HashTableRPGSubroutineList
        /// <summary>
        /// Subroutine Name and Subroutine Content.
        /// </summary>
        public Hashtable HashTableRPGSubroutineList = new Hashtable();
#endregion 

        #region Constructor
        public RPGLanguageViewer(TabPage SelectTabPage)
        {
            this.SelectedTabPage = SelectTabPage;
            FormatRPGLanguage = new FormatLanguage(this.SelectedRichTextBox, "RPG");

            
            
        }


        #endregion 

        #region SelectedTabPage
        private TabPage selectedTabPage;
        /// <summary>
        /// the selected Tabpage  which is the parent control of richtextbox
        /// </summary>
        public override TabPage SelectedTabPage
        {

            get
            {
                return selectedTabPage;
            }
            set 
            {
                selectedTabPage = value;
            }
        }
        #endregion 

        #region SelectContextSplitControl
        public SplitContainer SelectContextSplitControl
        {
            get
            {
                SplitContainer contextSplitControl = null;
                if (this.SelectedTabPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)SelectedTabPage.Tag;
                    string contextsplicontrolId = ContextOperator.GetContextSplitContainerName(cbi.ContextInfoID);
                    Control[] ctrls =  this.SelectedTabPage.Controls.Find(contextsplicontrolId, true);
                    if(ctrls.Length >0)
                    {
                        contextSplitControl = (SplitContainer)ctrls[0];
                    }
                }
                return contextSplitControl;

            }

        }
        #endregion 
        
        #region SelectedRPGSearchToolBar
        /// <summary>
        /// Selected RPG search toolbar
        /// </summary>
        public SearchToolBarRPG SelectedRPGSearchToolBar
        {
            get
            {
                SearchToolBarRPG rpgSearchToolbar = null;
                if (this.SelectedTabPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)SelectedTabPage.Tag;
                    string searchtoolbarID = SearchToolBar.GetSearchToolbarID(cbi.ContextInfoID);
                    Control[] ctrls = this.SelectedTabPage.Controls.Find(searchtoolbarID, true);
                    rpgSearchToolbar = (SearchToolBarRPG)ctrls[0];
                }
                return rpgSearchToolbar;
            }
        }
        #endregion 

        #region RuleLineStyle
        /// <summary>
        /// Rule Line Type
        /// </summary>
        public string RuleLineStyle
        {
            get
            {
               return Properties.Settings.Default.RuleLineStyle;
 
            }
        }
        #endregion 

        #region SelectedRPGTool
        /// <summary>
        /// the selected RPGTool in the Tappage
        /// </summary>
        public RPGTool SelectedRPGTool
        {
            get
            {
                RPGTool currentrpgTool = null;
                TabPage selectedPage = this.selectedTabPage;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        string tabpagePannelID = ContextOperator.GetSplitContainerName(cbi.ContextInfoID);
                        string selectedRPGtoolId = ContextOperator.GetRPGToolName(cbi.ContextInfoID);
                        currentrpgTool = (RPGTool)(((SplitContainer)selectedPage.Controls[tabpagePannelID]).Panel2.Controls[selectedRPGtoolId]);
                    }
                }

                return currentrpgTool;

            }
        }
        #endregion 

        #region SelectedSplitContainerInTabPage
        /// <summary>
        /// the selected splitContainer in the Tappage
        /// </summary>
        public SplitContainer SelectedSplitContainerInTabPage
        {
            get
            {
                SplitContainer selectedSplitContainer = null;
                TabPage selectedPage = this.selectedTabPage;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        string tabpagePannelID = ContextOperator.GetSplitContainerName(cbi.ContextInfoID);

                        selectedSplitContainer = (SplitContainer)selectedPage.Controls[tabpagePannelID];
                    }
                }

                return selectedSplitContainer;

            }
        }
        #endregion 

        #region SelectedRichTextBox

        private CustomRichTextBox selectedRichTextBox;

        /// <summary>
        /// Current source code container
        /// </summary>
        public override CustomRichTextBox SelectedRichTextBox
        {
            get 
            {
                if (selectedRichTextBox == null)
                {
                    if (SelectedTabPage != null)
                    {
                        ContextBaseInfo cbi = (ContextBaseInfo)SelectedTabPage.Tag;
                        if (cbi != null)
                        {
                            string tabpagePannelID = ContextOperator.GetSplitContainerName(cbi.ContextInfoID);
                            string selectedRichTextBoxId = this.GetRichTextBoxName(cbi.ContextInfoID);
                            Control[] ctrls = SelectedTabPage.Controls.Find(selectedRichTextBoxId, true);
                            if (ctrls.Length > 0)
                            {
                                selectedRichTextBox = (CustomRichTextBox)ctrls[0];
                            }

                        }
                    }
                }

                return selectedRichTextBox;
            }
        }
        #endregion 

        #region ViewSourceCode
        /// <summary>
        /// view source code by RPG format
        /// </summary>
        public override void ViewSourceCode()
        {
            CustomRichTextBox currentSelectRichTextBox = this.SelectedRichTextBox;
            currentSelectRichTextBox.Cursor = Cursors.WaitCursor;
            //change the font to counter new and size to 10
            currentSelectRichTextBox.Font = new Font("Courier New", 10);
            currentSelectRichTextBox.TextColor = RtfColor.Black;
            currentSelectRichTextBox.WordWrap = false;
            //highlist code color
            this.FilterSpeicalCode(currentSelectRichTextBox);
            FormatRPGLanguage.HighLightByRegularExpressRule();
            currentSelectRichTextBox.Cursor = Cursors.IBeam;

            //add event of search bar
            this.SelectedRPGSearchToolBar.CurrentSearchToolbar.ShowAllSourceEvent += new ShowWholeSource(SelectedRPGSearchToolBar_ShowAllSourceEvent);
            this.SelectedRPGSearchToolBar.CurrentSearchToolbar.HideSourceCommentEvent += new HideSourceComment(SelectedRPGSearchToolBar_HideSourceCommentEvent);
        }

       
        #endregion 

        #region FilterSpeicalCode
        private void FilterSpeicalCode(CustomRichTextBox currentSelectRichTextBox)
        {
            string specailCodeReg = @"(\\'9a)|(\\'90)|(\\'82)";
            Regex regFilter = new Regex(specailCodeReg);
            currentSelectRichTextBox.Rtf = regFilter.Replace(currentSelectRichTextBox.Rtf, " ");

        }
#endregion

        #region DrawCrossLine
        /// <summary>
        /// Draw Cross line
        /// </summary>
        /// <param name="relCaretPos"></param>
        public void DrawLine()
        {
            //{CrossLine,SingleLine,DoubleLine,None};
            if (RuleLineStyle.ToLower() != "none")
            {
                
                Point relCaretPos;
                GetCaretPos(out relCaretPos);
                string LineType = RuleLineStyle.ToLower();
                using (Graphics g = this.SelectedRichTextBox.CreateGraphics())
                {
                    switch (LineType)
                    {
                        case "crossline":
                            g.DrawLine(Pens.Blue, new Point(0, relCaretPos.Y + 16),
                                new Point(this.SelectedRichTextBox.Width, relCaretPos.Y + 16));
                            g.DrawLine(Pens.Blue, new Point(relCaretPos.X + 2, 0),
                                 new Point(relCaretPos.X + 2, this.SelectedRichTextBox.Height));
                            break;
                        case "singleline":
                            g.DrawLine(Pens.Blue, new Point(0, relCaretPos.Y + 16),
                            new Point(this.SelectedRichTextBox.Width, relCaretPos.Y + 16));
                            break;
                        case "doubleline":
                            g.DrawLine(Pens.Blue, new Point(0, relCaretPos.Y - 1),
                            new Point(this.SelectedRichTextBox.Width, relCaretPos.Y -1 ));
                            g.DrawLine(Pens.Blue, new Point(0, relCaretPos.Y + 16),
                             new Point(this.SelectedRichTextBox.Width, relCaretPos.Y + 16));
                            break;


                    }
                }
            }



        }
        #endregion 

        #region RefreshCaretPosition
        /// <summary>
        /// refresh current
        /// </summary>
        public void RefreshCaretPosition()
        {
            GetCaretPos(out CurrentCaretPosition);
        }
        #endregion 

        #region DrawStyleLine
        /// <summary>
        /// Draw Cross line
        /// </summary>
        /// <param name="relCaretPos"></param>
        public void DrawStyleLine(bool IsDrawLine )
        {
            //{CrossLine,SingleLine,DoubleLine,None};
            if (RuleLineStyle.ToLower() != "none")
            {
                string LineType = RuleLineStyle.ToLower();
                using (Graphics g = this.SelectedRichTextBox.CreateGraphics())
                {
                    switch (LineType)
                    {
                        case "crossline":
                            g.DrawLine(Pens.Blue, new Point(0, CurrentCaretPosition.Y + 16),
                                new Point(this.SelectedRichTextBox.Width, CurrentCaretPosition.Y + 16));
                            g.DrawLine(Pens.Blue, new Point(CurrentCaretPosition.X + 2, 0),
                                 new Point(CurrentCaretPosition.X + 2, this.SelectedRichTextBox.Height));
                            break;
                        case "singleline":
                            g.DrawLine(Pens.Blue, new Point(0, CurrentCaretPosition.Y + 16),
                            new Point(this.SelectedRichTextBox.Width, CurrentCaretPosition.Y + 16));
                            break;
                        case "doubleline":
                            g.DrawLine(Pens.Blue, new Point(0, CurrentCaretPosition.Y - 1),
                            new Point(this.SelectedRichTextBox.Width, CurrentCaretPosition.Y - 1));
                            g.DrawLine(Pens.Blue, new Point(0, CurrentCaretPosition.Y + 16),
                             new Point(this.SelectedRichTextBox.Width, CurrentCaretPosition.Y + 16));
                            break;


                    }
                }
            }



        }
        #endregion 

        #region GetSubroutineList
        /// <summary>
        /// add all the subroutine to the listbox
        /// </summary>
        public ArrayList GetSubroutineList()
        {
            ArrayList arrl = new ArrayList();
            string subroutine = @"([C][\s]+[a-zA-Z\*]{1}.{10,15}BEGSR)|([C][\s]+.{1,16}ENDSR)";
            string begainSubroutine = @"([C][\s]+[a-zA-Z\*]{1}.{10,15}BEGSR)";
            string endSubroutine = @"([C][\s]+.{1,16}ENDSR)";
            string subroutineName = @"\s[a-zA-Z\*][\w]*";
            Regex subroutineReg = new Regex(subroutine, RegexOptions.IgnoreCase);
            Regex begainSubroutineReg = new Regex(begainSubroutine, RegexOptions.IgnoreCase);
            Regex endSubroutineReg = new Regex(endSubroutine, RegexOptions.IgnoreCase);
            Regex subroutineNameReg = new Regex(subroutineName,RegexOptions.IgnoreCase);
            MatchCollection mc = subroutineReg.Matches(this.SelectedRichTextBox.Text);
            int begainSrpostion = 0;
            string strsbName = null;
            string strbeginSubroutineName = null;
            string strsbBody;
            foreach (Match mt in mc)
            {
                //if it is begain subroutine 
                if (begainSubroutineReg.IsMatch(mt.ToString()))
                {
                    Match mtSbname = subroutineNameReg.Match(mt.ToString());
                    strsbName = mtSbname.ToString().Trim();
                    strbeginSubroutineName = mt.ToString();
                    begainSrpostion = mt.Index;
                }
                else 
                {
                    //endsubroutine
                    Match mtEndSubroutine = endSubroutineReg.Match(mt.ToString());
                    int endPostion = mt.Index + mtEndSubroutine.ToString().Length;
                    strsbBody = this.SelectedRichTextBox.Text.Substring(begainSrpostion, endPostion - begainSrpostion);
                    //strsbBody = strsbBody.Length > 350 ? strsbBody.Substring(0, 350) + "\n\t......" : strsbBody;
                    //store the subroutine context in the arraylist.
                    arrl.Add(new SubroutineItem(strsbName, strbeginSubroutineName, strsbBody));
                }
 
            }

            return arrl;


        }
        #endregion 

        #region GetSubroutineList
        /// <summary>
        /// add all the subroutine to the listbox
        /// </summary>
        public ArrayList GetSubroutineListWithoutSubRoutineContext()
        {
            ArrayList arrl = new ArrayList();
            string subroutine = @"([C][\s]+[a-zA-Z\*]{1}.{10,15}BEGSR)|([C][\s]+.{1,16}ENDSR)";
            string begainSubroutine = @"([C][\s]+[a-zA-Z\*]{1}.{10,15}BEGSR)";
            string endSubroutine = @"([C][\s]+.{1,16}ENDSR)";
            string subroutineName = @"\s[a-zA-Z\*][\w]*";
            Regex subroutineReg = new Regex(subroutine, RegexOptions.IgnoreCase);
            Regex begainSubroutineReg = new Regex(begainSubroutine, RegexOptions.IgnoreCase);
            Regex endSubroutineReg = new Regex(endSubroutine, RegexOptions.IgnoreCase);
            Regex subroutineNameReg = new Regex(subroutineName, RegexOptions.IgnoreCase);
            MatchCollection mc = subroutineReg.Matches(this.SelectedRichTextBox.Text);
            int begainSrpostion = 0;
            string strsbName = null;
            string strbeginSubroutineName = null;
            foreach (Match mt in mc)
            {
                //if it is begain subroutine 
                if (begainSubroutineReg.IsMatch(mt.ToString()))
                {
                    Match mtSbname = subroutineNameReg.Match(mt.ToString());
                    strsbName = mtSbname.ToString().Trim();
                    strbeginSubroutineName = mt.ToString();
                    begainSrpostion = mt.Index;
                    arrl.Add(new SubroutineItem(strsbName, strbeginSubroutineName, strsbName));
                }

            }

            return arrl;


        }
        #endregion 

        #region GotoSubtine
        /// <summary>
        /// Goto subroutine postion
        /// </summary>
        /// <param name="subroutineName"></param>
        public void GotoSubtine(string subroutineName)
        {
            int FindPosition;
            // select in order
            FindPosition = this.SelectedRichTextBox.Find(subroutineName, 0, RichTextBoxFinds.None);

            if (FindPosition != -1)
            {
                this.SelectedRichTextBox.Select(FindPosition, subroutineName.Length);
                //make the the find string in richtextbox selected
                this.SelectedRichTextBox.ScrollToCaret();
                
            }
            else
            {
                MessageBox.Show("Can not find !");
            }

        }
        #endregion 

        #region GotoPotionByRegularExpression
        /// <summary>
        /// find string postion  by regular expression
        /// </summary>
        /// <param name="RegularExperession"></param>
        public void GotoPotionByRegularExpression(string RegularExperession)
        {
            this.SelectedRichTextBox.SelectionLength = 0;
            //for (int i = 0; i < this.SelectedRichTextBox.Lines.Length; i++)
            //{
            //    Regex findReg = new Regex(RegularExperession, RegexOptions.IgnoreCase);
            //    // just search the first 8 character
            //    if (this.SelectedRichTextBox.Lines[i].ToString().Length >= 8)
            //    {
            //        Match mt = findReg.Match(this.SelectedRichTextBox.Lines[i].ToString().Substring(0, 8));
            //        if (mt.Success)
            //        {
            //            int findposition = this.SelectedRichTextBox.GetFirstCharIndexFromLine(i);
            //            this.SelectedRichTextBox.SelectionStart = findposition;
            //            this.SelectedRichTextBox.ScrollToCaret();
            //            break;
            //        }
            //    }

            //}

            Regex findReg= new Regex(RegularExperession, RegexOptions.IgnoreCase);
            Match mt = findReg.Match(this.SelectedRichTextBox.Text);
            if (mt.Success)
            {
                //because it mathed "\n",so the position should add 1
                this.SelectedRichTextBox.SelectionStart = mt.Index+1;
                this.SelectedRichTextBox.ScrollToCaret();
            }

        }
        #endregion 

        #region GetCurrentLineText
        /// <summary>
        /// get the current line text
        /// </summary>
        /// <returns></returns>
        private string GetCurrentLineText()
        {
            int firstCharIndexInCurrentLine = this.SelectedRichTextBox.GetFirstCharIndexOfCurrentLine();
            int linenum = this.SelectedRichTextBox.GetLineFromCharIndex(firstCharIndexInCurrentLine);
            return this.SelectedRichTextBox.Lines.Length == 0 ? string.Empty : this.SelectedRichTextBox.Lines[linenum].ToString();
        }
        private string GetCurrentLineText(CustomRichTextBox currentRichTextBox)
        {
            int firstCharIndexInCurrentLine = currentRichTextBox.GetFirstCharIndexOfCurrentLine();
            int linenum = currentRichTextBox.GetLineFromCharIndex(firstCharIndexInCurrentLine);
            return this.SelectedRichTextBox.Lines.Length == 0 ? string.Empty : this.SelectedRichTextBox.Lines[linenum].ToString();
 
        }
        #endregion 

        #region GetCurrentSubroutine
        /// <summary>
        /// get the subroutine name where the caret
        /// </summary>
        public string GetCurrentSubroutine()
        {
            CustomRichTextBox currentRichTextBox = this.SelectedRichTextBox;
            if (currentRichTextBox.Text == string.Empty)
            {
                return string.Empty;
            }
            //string strSpecReg = @"([.]{6}[HDFCIO]\*.*)";
            string subroutineName = string.Empty;
            string SpecStr  = @"[HFDC]";
            string strCSpecReg = @"[.\s]{5,6}[C].*";
            string strSRReg = @"([C][\s]+[a-zA-Z\*]{1}.{10,15}BEGSR)|([C][\s]+.{10,16}ENDSR)";
            string strBegainaSRReg = @"[C][\s]+[a-zA-Z\*]{1}.{10,15}BEGSR";
            string strEndSRReg = @"[C][\s]+.{10,16}ENDSR";
            string strroutineNameReg = @"[\s][a-zA-Z\*][\w]*";
            //the seartch string should include currrent line text
            int caretPostion = currentRichTextBox.GetFirstCharIndexOfCurrentLine() + this.GetCurrentLineText(currentRichTextBox).Length;
            string richboxTextBeforeCurrentCaret = currentRichTextBox.Text.Substring(0, caretPostion);
            Regex ALLSpecReg = new Regex(SpecStr, RegexOptions.IgnoreCase);
            Regex CSpecReg = new Regex(strCSpecReg, RegexOptions.IgnoreCase);
            Regex SRReg = new Regex(strSRReg, RegexOptions.RightToLeft);
            Regex LeftToRightBegainaSRReg = new Regex(strBegainaSRReg, RegexOptions.IgnoreCase);
            Regex RightToLeftBegainaSRReg = new Regex(strBegainaSRReg, RegexOptions.IgnoreCase | RegexOptions.RightToLeft);
            Regex EndSRReg = new Regex(strEndSRReg,RegexOptions.IgnoreCase);
            Regex subroutineNameReg = new Regex(strroutineNameReg, RegexOptions.IgnoreCase);
            string currentLinetext = this.GetCurrentLineText(currentRichTextBox);
            string FistEightCharacter = currentLinetext.Length > 8 ? currentLinetext.Substring(0, 8) : currentLinetext;
            string currentSpec = this.GetSpecName(richboxTextBeforeCurrentCaret, currentRichTextBox);
            if (currentSpec.ToLower() == "c-spec")
            {   
                //if this is C-spec  then search the subtoutine
                subroutineName = currentSpec;
                Match firstMathResult = SRReg.Match(richboxTextBeforeCurrentCaret);
                if (firstMathResult.Success )
                {
                    // if the text fist meet BEGSR or if currentLinText meets ENDSR , then treat is as in Subroutine
                    if (LeftToRightBegainaSRReg.IsMatch(firstMathResult.ToString()))
                    {
                        subroutineName = subroutineNameReg.Match(firstMathResult.ToString()).ToString();
                    }
                    else if(EndSRReg.IsMatch(currentLinetext))
                    {
                        subroutineName = subroutineNameReg.Match(RightToLeftBegainaSRReg.Match(richboxTextBeforeCurrentCaret).ToString()).ToString();
                        
                    }
                }
                
            }
            else
            {

                subroutineName = currentSpec;

            }
            return subroutineName.Trim();

        }
        #endregion 

        #region BuildSubRoutineHashTable
        /// <summary>
        /// build subroutine HashTable  
        /// </summary>
        public void BuildSubRoutineHashTable(ArrayList SubroutineList)
        {
            this.HashTableRPGSubroutineList.Clear();
            foreach (object obj in SubroutineList)
            {
                SubroutineItem item = (SubroutineItem)obj;
                if (!this.HashTableRPGSubroutineList.Contains(item.SubroutineName))
                {
                    this.HashTableRPGSubroutineList.Add(item.SubroutineName, item);
                }

            }

        }
        #endregion 
        
        #region GetSpecName
        /// <summary>
        /// get current spec name
        /// </summary>
        /// <param name="richboxTextBeforeCurrentCaret"></param>
        /// <returns></returns>
        public string GetSpecName(string richboxTextBeforeCurrentCaret, CustomRichTextBox currentRichTextBox)
        {
            string SpecName = string.Empty;
            string currentLinetext = this.GetCurrentLineText(currentRichTextBox);
            string SpecCode = currentLinetext.Length > 8 ? currentLinetext.Substring(6, 2) : currentLinetext;
            string SpecStr = @"[HFDC]";
            //when the current is only "*" in the spec position. find it's spec with it former code text.
            string PreviousSpecReg = @"\n[.\s]{5,6}[HFDC]";
            Regex ALLSpecReg = new Regex(SpecStr, RegexOptions.IgnoreCase);
            Regex FormerSpecReg = new Regex(PreviousSpecReg, RegexOptions.IgnoreCase| RegexOptions.RightToLeft);
            if (ALLSpecReg.IsMatch(SpecCode))
            {
                 SpecName =ALLSpecReg.Match(SpecCode).ToString() + "-Spec";
            }
            else if (FormerSpecReg.IsMatch(richboxTextBeforeCurrentCaret))
            {
                SpecName = FormerSpecReg.Match(richboxTextBeforeCurrentCaret).Value;
                SpecName = SpecName.Substring(SpecName.Length - 1) + "-Spec";
            }
            return SpecName;
        }
        public string GetSpecName(string richboxTextBeforeCurrentCaret)
        {
            string SpecName = string.Empty;
            string currentLinetext = this.GetCurrentLineText();
            string SpecCode = currentLinetext.Length > 8 ? currentLinetext.Substring(6, 2) : currentLinetext;
            string SpecStr = @"[HFDC]";
            //when the current is only "*" in the spec position. find it's spec with it former code text.
            string PreviousSpecReg = @"\n[.\s]{5,6}[HFDC]";
            Regex ALLSpecReg = new Regex(SpecStr, RegexOptions.IgnoreCase);
            Regex FormerSpecReg = new Regex(PreviousSpecReg, RegexOptions.IgnoreCase | RegexOptions.RightToLeft);
            if (ALLSpecReg.IsMatch(SpecCode))
            {
                SpecName = ALLSpecReg.Match(SpecCode).ToString() + "-Spec";
            }
            else if (FormerSpecReg.IsMatch(richboxTextBeforeCurrentCaret))
            {
                SpecName = FormerSpecReg.Match(richboxTextBeforeCurrentCaret).Value;
                SpecName = SpecName.Substring(SpecName.Length - 1) + "-Spec";
            }
            return SpecName;
        }
        #endregion 

        #region GetMainSubroutines
        /// <summary>
        /// get the main subroutine in the RPG
        /// </summary>
        /// <returns></returns>
        public ArrayList GetMainSubroutines()  
        {
            ArrayList alMainSubroutine = new ArrayList();
            //string ExcuteSubrountine = @"[C][\s]+.{10,16}EXSR[\s]+[\w]+";
            string ExcuteSubrountine = @"[C][^\*]+.{10,16}EXSR[\s]+[\w]+";
            string subroutineName = @"[\w]+";
            string INZSR =@"[\*]INZSR";
            string strSRReg = @"([C][\s]+[a-zA-Z\*]{1}.{10,15}BEGSR)|([C][\s]+.{10,16}ENDSR)";
            string strEndSRReg = @"[C][\s]+.{10,16}ENDSR";
            Regex subroutineReg = new Regex(ExcuteSubrountine, RegexOptions.IgnoreCase);
            Regex subroutineNameRegex = new Regex(subroutineName, RegexOptions.IgnoreCase | RegexOptions.RightToLeft);
            Regex INZSRRegex = new Regex(INZSR, RegexOptions.IgnoreCase);
            Regex strSRRegex = new Regex(strSRReg, RegexOptions.IgnoreCase|RegexOptions.RightToLeft);
            Regex strEndSRRegex = new Regex(strEndSRReg, RegexOptions.IgnoreCase | RegexOptions.RightToLeft);
            //check whether the *INZSR is exist.
            if (INZSRRegex.IsMatch(this.SelectedRichTextBox.Text))
            {
                alMainSubroutine.Add("*INZSR");
            }
            //get the main subroutine
            MatchCollection mc = subroutineReg.Matches(this.SelectedRichTextBox.Text);
            foreach (Match c in mc)
            {

                string richboxTextBeforeCurrentCaret = this.SelectedRichTextBox.Text.Substring(0, c.Index);
                if (strSRRegex.IsMatch(richboxTextBeforeCurrentCaret))
                {
                    string matchtext = strSRRegex.Match(richboxTextBeforeCurrentCaret).Value;
                    if (strEndSRRegex.IsMatch(matchtext))
                    {
                        alMainSubroutine.Add(subroutineNameRegex.Match(c.Value).Value);
                    }
                }
                else if (!strSRRegex.IsMatch(richboxTextBeforeCurrentCaret))
                {
                    alMainSubroutine.Add(subroutineNameRegex.Match(c.Value).Value);
                }
                
            }

            return alMainSubroutine;
 
        }
        #endregion 
        
        #region GetChidrenSubroutines
        /// <summary>
        /// Get the children subroutines in the certain subroutine
        /// </summary>
        /// <param name="S"></param>
        /// <returns></returns>
        public ArrayList GetChidrenSubroutines(string FromSubroutineName )
        {
            ArrayList alchildrensubroutine = new ArrayList();
            //string ExcuteSubrountine = @"[C][\s]+.{10,16}EXSR[\s]+[\w]+";
            string ExcuteSubrountine = @"[C][\s]+.{10,16}EXSR[\s]+[\w]+";
            string subroutineName = @"[\w]+";
            Regex excuteSubrountineRegex = new Regex(ExcuteSubrountine, RegexOptions.IgnoreCase);
            Regex subroutineNameRegex = new Regex(subroutineName, RegexOptions.IgnoreCase | RegexOptions.RightToLeft);
            string subroutineBodyText = ((SubroutineItem)this.HashTableRPGSubroutineList[FromSubroutineName]).SubroutineBody;
            MatchCollection mc = excuteSubrountineRegex.Matches(subroutineBodyText);
            foreach (Match m in mc)
            {
                string srName = subroutineNameRegex.Match(m.Value).Value;
                if (!alchildrensubroutine.Contains(srName))
                {
                    alchildrensubroutine.Add(srName);
                }
            }

            return alchildrensubroutine;
        }
        #endregion 

        #region BindSunRoutineTreeView
        /// <summary>
        /// bind the sunroutine architechture to the treeview
        /// </summary>
        /// <param name="subroutineTreeView"></param>
        public void BindSunRoutineTreeView(TreeView subroutineTreeView)
        {
           
            subroutineTreeView.Nodes.Clear();
            subroutineTreeView.Nodes.Add("SubRoutineList");
            subroutineTreeView.Nodes[0].Expand();
            ArrayList mainsubroutineList = this.GetMainSubroutines();
            foreach (object obj in mainsubroutineList)
            {
                TreeNode tn = new TreeNode(obj.ToString());
                tn.Tag = this.HashTableRPGSubroutineList[obj];
                subroutineTreeView.Nodes[0].Nodes.Add(tn);
                this.RecursiveBindSubroutine(tn);
            }
            
        }
        #endregion 

        #region RecursiveBindSubroutine
        /// <summary>
        /// Bind the subroutine recursively
        /// </summary>
        /// <param name="TNSubroutine"></param>
        private void RecursiveBindSubroutine(TreeNode TNSubroutine)
        {
            
            ArrayList childerenSubroutine = GetChidrenSubroutines(TNSubroutine.Text);
            if (childerenSubroutine.Count > 0 && TNSubroutine.Level <= RPGSubroutineDepth)
            {
                foreach (object obj in childerenSubroutine)
                {
                    TreeNode tn = new TreeNode(obj.ToString());
                    tn.Tag = this.HashTableRPGSubroutineList[obj];
                    TNSubroutine.Nodes.Add(tn);
                    RecursiveBindSubroutine(tn);

                }

            }
        }
        #endregion 

        #region GetSpecName
        /// <summary>
        /// get the selected Spec Name of Currentline in the CertainRichTextbox
        /// </summary>
        /// <param name="CRT"></param>
        /// <returns></returns>
        public static string GetSpecName(CustomRichTextBox CertainRichTextBox)
        {
            string SpecName = string.Empty;
            if (CertainRichTextBox.Text == string.Empty)
            {
                return string.Empty;
            }
            //string strSpecReg = @"([.]{6}[HDFCIO]\*.*)";
            string subroutineName = string.Empty;
            string SpecStr = @"[HFDC]";
            string strCSpecReg = @"[.\s]{5,6}[C].*";
            //get the current line text            
            int firstCharIndexInCurrentLine = CertainRichTextBox.GetFirstCharIndexOfCurrentLine();
            int linenum = CertainRichTextBox.GetLineFromCharIndex(firstCharIndexInCurrentLine);
            string currentLinetext = CertainRichTextBox.Lines.Length == 0 ? string.Empty : CertainRichTextBox.Lines[linenum].ToString();

            //the seartch string should include currrent line text
            int caretPostion = CertainRichTextBox.GetFirstCharIndexOfCurrentLine() + currentLinetext.Length;
            string richboxTextBeforeCurrentCaret = CertainRichTextBox.Text.Substring(0, caretPostion);
            Regex ALLSpecReg = new Regex(SpecStr, RegexOptions.IgnoreCase);
            Regex CSpecReg = new Regex(strCSpecReg, RegexOptions.IgnoreCase);

  

            string FistEightCharacter = currentLinetext.Length > 8 ? currentLinetext.Substring(0, 8) : currentLinetext;
            string SpecCode = currentLinetext.Length > 8 ? currentLinetext.Substring(6, 2) : currentLinetext;
            //when the current is only "*" in the spec position. find it's spec with it former code text.
            string PreviousSpecReg = @"\n[.\s]{5,6}[HFDC]";
            Regex FormerSpecReg = new Regex(PreviousSpecReg, RegexOptions.IgnoreCase | RegexOptions.RightToLeft);
            if (ALLSpecReg.IsMatch(SpecCode))
            {
                SpecName = ALLSpecReg.Match(SpecCode).ToString();
            }
            else if (FormerSpecReg.IsMatch(richboxTextBeforeCurrentCaret))
            {
                SpecName = FormerSpecReg.Match(richboxTextBeforeCurrentCaret).Value;
                SpecName = SpecName.Substring(SpecName.Length - 1);
            }
            return SpecName;

        }
        #endregion 

        #region HideCommentOfSource
        /// <summary>
        /// Hide  the commment
        /// </summary>
        public override void HideCommentOfSource(CustomRichTextBox SourceRichtexbox)
        {


            if (string.IsNullOrEmpty(this.OriganlSourceCode))
            {
                this.OriganlSourceCode = SourceRichtexbox.Rtf;
                FormatRPGLanguage.LoadXmlConfiguration();
            }
            string commentRegstr = @"(\\cf\d[\s]{0,2}" + FormatRPGLanguage.GetCommentRegularExpress() + ")+";
            Regex commentReg = new Regex(commentRegstr);
            SourceRichtexbox.Rtf = commentReg.Replace(SourceRichtexbox.Rtf, "\\Par");

        }
        #endregion 

        #region ShowandHideCommentofSource
        void SelectedRPGSearchToolBar_HideSourceCommentEvent()
        {
            this.HideCommentOfSource(this.SelectedRichTextBox);
        }

        void SelectedRPGSearchToolBar_ShowAllSourceEvent()
        {
           
            this.ShowOriganalSource();
        }
        #endregion 

    }
}
