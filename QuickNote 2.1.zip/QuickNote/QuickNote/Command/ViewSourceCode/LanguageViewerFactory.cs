using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace GLTc.QuickNote.Command.ViewSourceCode
{
    /// <summary>
    /// Factory Design pattern for view source code 
    /// </summary>
    public abstract class LanguageViewerFactory
    {
        /// <summary>
        /// get the concrete languageviewer class, must be override
        /// </summary>
        /// <returns></returns>
        public abstract LanguageViewer GetLanguageViewer(TabPage SelectTabPage);


    }
}
