using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace GLTc.QuickNote.Command
{
    public class FormatInfo
    {
        public Font PaintFont;
        public Color BackGroudColor;
        public Color FontColor;
        public bool IsBullet;
    }
}
