using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GLTc.QuickNote.Command;

namespace GLTc.QuickNote
{
    public partial class NodeProperty : Form
    {
        private TreeNode CurrentSelectedNode;

        private TreeNodeInfo currentNodeInfo;

        private int ContainNodes;
        /// <summary>
        /// Current Node info
        /// </summary>
        public TreeNodeInfo CurrentNodeInfo
        {
            get { return currentNodeInfo; }
            set { currentNodeInfo = value; }
        }

        private TreeNodeOperator currentTreeNodeOperator;

        public TreeNodeOperator CurrentTreeNodeOperator
        {
            get { return currentTreeNodeOperator; }
            set { currentTreeNodeOperator = value; }
        }


        private TreeOperator CurrentTreeOperator;

        public  NodeProperty(TreeNode CurrentTreeNode , TreeOperator CurrTreeOperator)
        {
            //this.TCProperty.SetStyle(ControlStyles.ResizeRedraw, true);
            this.ContainNodes = CurrentTreeNode.GetNodeCount(true);
            this.CurrentSelectedNode = CurrentTreeNode;
            InitializeComponent();
            InitalizeProperty();
            this.TPGeneral.Paint += new PaintEventHandler(TPGeneral_Paint);
            this.CurrentTreeOperator = CurrTreeOperator;
            this.btnApply.DialogResult = DialogResult.OK;
            this.btnOK.DialogResult = DialogResult.OK;
            this.btnCancel.DialogResult = DialogResult.Cancel;
            this.TbNodeName.TextChanged +=new EventHandler(TbNodeName_TextChanged);
            this.tbIndexInfo.TextChanged +=new EventHandler(tbIndexInfo_TextChanged);
            
        }

        void TPGeneral_Paint(object sender, PaintEventArgs e)
        {
            
            e.Graphics.DrawLine(Pens.DarkGray, 10, 69, 313, 69);
            e.Graphics.DrawLine(Pens.DarkGray, 10, 150, 313, 150);
            e.Graphics.DrawLine(Pens.DarkGray, 10, 200, 313, 200);
        }





        private void InitalizeProperty()
        {
            TreeNodeInfo tni = (TreeNodeInfo)this.CurrentSelectedNode.Tag;
            string ContextId = tni.ContextTreeID;
            this.CurrentTreeNodeOperator = new TreeNodeOperator(ContextId,this.CurrentSelectedNode.FullPath);
            tni = this.CurrentTreeNodeOperator.GetTreeNodeInfo();
            this.TbNodeName.Text = tni.NodeName;
            this.lbTypeValue.Text = tni.NodeTypeID == 2 ? "Page" : "Folder";
            this.lbLocationValue.Text = tni.FullPath;
            this.tbIndexInfo.Text = tni.IndexInfo;
            this.Text = this.CurrentSelectedNode.Text + " Properties";
            this.lbCreatedDateValue.Text = GetCustomDateFormat(tni.CreatedDate);
            this.lbModifyDateValue.Text = GetCustomDateFormat(tni.UpdatedDate);
            this.lbContainValue.Text = string.Format("{0} Nodes", this.ContainNodes.ToString());
        }

        private string GetCustomDateFormat(string OriginalDateTime)
        {
            string customDateFormat = string.Empty;
            if (!string.IsNullOrEmpty(OriginalDateTime))
            {
               DateTime dt = Convert.ToDateTime(OriginalDateTime);
               customDateFormat = dt.ToLongDateString() +", "+ dt.ToLongTimeString();
 
            }
            return customDateFormat;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            TreeNodeInfo tni = (TreeNodeInfo)this.CurrentSelectedNode.Tag;
            tni.NodeName = this.TbNodeName.Text.Length <= 64 ? this.TbNodeName.Text:this.TbNodeName.Text.Substring(0,64);
            tni.IndexInfo = this.tbIndexInfo.Text.Length <= 128 ? this.tbIndexInfo.Text:this.tbIndexInfo.Text.Substring(0,128);
            bool isupdated = this.CurrentTreeNodeOperator.UpDateTreeNodeInfo(tni);
            if (isupdated)
            {
                this.CurrentTreeOperator.RenameTreeNode(tni.NodeName, this.CurrentSelectedNode);
            }
            //change the node Text
            this.CurrentTreeOperator.CurrentTreeView.BeginUpdate();
            this.CurrentSelectedNode.Text = tni.NodeName;
            this.CurrentTreeOperator.CurrentTreeView.EndUpdate();

        }

        private void TbNodeName_TextChanged(object sender, EventArgs e)
        {
            this.btnApply.Enabled = true;
           
        }

        private void tbIndexInfo_TextChanged(object sender, EventArgs e)
        {
             this.btnApply.Enabled = true;
        
        }

        private void NodeProperty_Paint(object sender, PaintEventArgs e)
        {
            TreeNodeInfo tni = (TreeNodeInfo)this.CurrentSelectedNode.Tag;
            if (tni.NodeTypeID != (int)TreeNodeType.Page)
            {
                this.lbIndexInfo.Visible = false;
                this.tbIndexInfo.Visible = false;
                


            }

            switch (tni.NodeTypeID)
            {
                case 0:
                    this.PicBoxNodeType.Image = (Image)GLTc.QuickNote.Properties.Resources.NoteIcon.ToBitmap();

                    break;
                case 1:
                    this.PicBoxNodeType.Image = GLTc.QuickNote.Properties.Resources.Folder;
                    break;
                case 2:
                    this.PicBoxNodeType.Image = GLTc.QuickNote.Properties.Resources.PageIcon.ToBitmap();
                    break;
            }

        }




 
    }
}