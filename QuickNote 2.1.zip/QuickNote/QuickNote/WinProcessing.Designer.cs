namespace GLTc.QuickNote
{
    partial class WinProcessing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbProcessing = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbProcessing)).BeginInit();
            this.SuspendLayout();
            // 
            // pbProcessing
            // 
            this.pbProcessing.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbProcessing.Image = global::GLTc.QuickNote.Properties.Resources.Processing;
            this.pbProcessing.Location = new System.Drawing.Point(0, 0);
            this.pbProcessing.Name = "pbProcessing";
            this.pbProcessing.Size = new System.Drawing.Size(481, 356);
            this.pbProcessing.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbProcessing.TabIndex = 0;
            this.pbProcessing.TabStop = false;
            // 
            // WinProcessing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(481, 356);
            this.Controls.Add(this.pbProcessing);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "WinProcessing";
            this.Opacity = 0.9;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "WinProcessing";
            ((System.ComponentModel.ISupportInitialize)(this.pbProcessing)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbProcessing;

    }
}