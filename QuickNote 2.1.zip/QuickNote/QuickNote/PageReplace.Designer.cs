namespace GLTc.QuickNote
{
    partial class PageReplace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TblayoutReplace = new System.Windows.Forms.TableLayoutPanel();
            this.lbFindWhat = new System.Windows.Forms.Label();
            this.lbReplaceWith = new System.Windows.Forms.Label();
            this.tbFind = new System.Windows.Forms.TextBox();
            this.tbReplace = new System.Windows.Forms.TextBox();
            this.btnFindNext = new System.Windows.Forms.Button();
            this.btnReplace = new System.Windows.Forms.Button();
            this.btnReplaceAll = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.chbMatchCase = new System.Windows.Forms.CheckBox();
            this.TblayoutReplace.SuspendLayout();
            this.SuspendLayout();
            // 
            // TblayoutReplace
            // 
            this.TblayoutReplace.ColumnCount = 3;
            this.TblayoutReplace.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.TblayoutReplace.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 173F));
            this.TblayoutReplace.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 88F));
            this.TblayoutReplace.Controls.Add(this.lbFindWhat, 0, 0);
            this.TblayoutReplace.Controls.Add(this.lbReplaceWith, 0, 1);
            this.TblayoutReplace.Controls.Add(this.tbFind, 1, 0);
            this.TblayoutReplace.Controls.Add(this.tbReplace, 1, 1);
            this.TblayoutReplace.Controls.Add(this.btnFindNext, 2, 0);
            this.TblayoutReplace.Controls.Add(this.btnReplace, 2, 1);
            this.TblayoutReplace.Controls.Add(this.btnReplaceAll, 2, 2);
            this.TblayoutReplace.Controls.Add(this.btnCancel, 2, 3);
            this.TblayoutReplace.Controls.Add(this.chbMatchCase, 0, 3);
            this.TblayoutReplace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TblayoutReplace.Location = new System.Drawing.Point(0, 0);
            this.TblayoutReplace.Name = "TblayoutReplace";
            this.TblayoutReplace.RowCount = 4;
            this.TblayoutReplace.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.TblayoutReplace.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.TblayoutReplace.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.TblayoutReplace.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.TblayoutReplace.Size = new System.Drawing.Size(350, 156);
            this.TblayoutReplace.TabIndex = 0;
            // 
            // lbFindWhat
            // 
            this.lbFindWhat.AutoSize = true;
            this.lbFindWhat.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbFindWhat.Location = new System.Drawing.Point(3, 17);
            this.lbFindWhat.Name = "lbFindWhat";
            this.lbFindWhat.Size = new System.Drawing.Size(83, 13);
            this.lbFindWhat.TabIndex = 0;
            this.lbFindWhat.Text = "Fi&nd What:";
            // 
            // lbReplaceWith
            // 
            this.lbReplaceWith.AutoSize = true;
            this.lbReplaceWith.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbReplaceWith.Location = new System.Drawing.Point(3, 47);
            this.lbReplaceWith.Name = "lbReplaceWith";
            this.lbReplaceWith.Size = new System.Drawing.Size(83, 13);
            this.lbReplaceWith.TabIndex = 1;
            this.lbReplaceWith.Text = "Re&place With";
            // 
            // tbFind
            // 
            this.tbFind.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbFind.Location = new System.Drawing.Point(92, 7);
            this.tbFind.Name = "tbFind";
            this.tbFind.Size = new System.Drawing.Size(167, 20);
            this.tbFind.TabIndex = 2;
            this.tbFind.TextChanged += new System.EventHandler(this.tbFind_TextChanged);
            // 
            // tbReplace
            // 
            this.tbReplace.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbReplace.Location = new System.Drawing.Point(92, 37);
            this.tbReplace.Name = "tbReplace";
            this.tbReplace.Size = new System.Drawing.Size(167, 20);
            this.tbReplace.TabIndex = 3;
            // 
            // btnFindNext
            // 
            this.btnFindNext.Enabled = false;
            this.btnFindNext.Location = new System.Drawing.Point(265, 3);
            this.btnFindNext.Name = "btnFindNext";
            this.btnFindNext.Size = new System.Drawing.Size(75, 23);
            this.btnFindNext.TabIndex = 4;
            this.btnFindNext.Text = "&Find Next";
            this.btnFindNext.UseVisualStyleBackColor = true;
            this.btnFindNext.Click += new System.EventHandler(this.btnFindNext_Click);
            // 
            // btnReplace
            // 
            this.btnReplace.Enabled = false;
            this.btnReplace.Location = new System.Drawing.Point(265, 33);
            this.btnReplace.Name = "btnReplace";
            this.btnReplace.Size = new System.Drawing.Size(75, 23);
            this.btnReplace.TabIndex = 5;
            this.btnReplace.Text = "&Replace";
            this.btnReplace.UseVisualStyleBackColor = true;
            this.btnReplace.Click += new System.EventHandler(this.btnReplace_Click);
            // 
            // btnReplaceAll
            // 
            this.btnReplaceAll.Enabled = false;
            this.btnReplaceAll.Location = new System.Drawing.Point(265, 63);
            this.btnReplaceAll.Name = "btnReplaceAll";
            this.btnReplaceAll.Size = new System.Drawing.Size(75, 23);
            this.btnReplaceAll.TabIndex = 6;
            this.btnReplaceAll.Text = "Replace &All";
            this.btnReplaceAll.UseVisualStyleBackColor = true;
            this.btnReplaceAll.Click += new System.EventHandler(this.btnReplaceAll_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(265, 93);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // chbMatchCase
            // 
            this.chbMatchCase.AutoSize = true;
            this.chbMatchCase.Location = new System.Drawing.Point(3, 93);
            this.chbMatchCase.Name = "chbMatchCase";
            this.chbMatchCase.Size = new System.Drawing.Size(83, 17);
            this.chbMatchCase.TabIndex = 8;
            this.chbMatchCase.Text = "Match Case";
            this.chbMatchCase.UseVisualStyleBackColor = true;
            // 
            // PageReplace
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 156);
            this.Controls.Add(this.TblayoutReplace);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.HelpButton = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PageReplace";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Replace";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.PageReplace_FormClosed);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PageReplace_FormClosing);
            this.TblayoutReplace.ResumeLayout(false);
            this.TblayoutReplace.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel TblayoutReplace;
        private System.Windows.Forms.Label lbFindWhat;
        protected System.Windows.Forms.Label lbReplaceWith;
        private System.Windows.Forms.TextBox tbFind;
        private System.Windows.Forms.TextBox tbReplace;
        private System.Windows.Forms.Button btnFindNext;
        private System.Windows.Forms.Button btnReplace;
        private System.Windows.Forms.Button btnReplaceAll;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.CheckBox chbMatchCase;
    }
}