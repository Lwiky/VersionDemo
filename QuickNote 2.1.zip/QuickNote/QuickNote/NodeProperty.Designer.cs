namespace GLTc.QuickNote
{
    partial class NodeProperty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TCProperty = new System.Windows.Forms.TabControl();
            this.TPGeneral = new System.Windows.Forms.TabPage();
            this.lbIndexInfo = new System.Windows.Forms.Label();
            this.tbIndexInfo = new System.Windows.Forms.TextBox();
            this.tblopDate = new System.Windows.Forms.TableLayoutPanel();
            this.lbModifyDateValue = new System.Windows.Forms.Label();
            this.lbModifyDate = new System.Windows.Forms.Label();
            this.lbCreatedDateValue = new System.Windows.Forms.Label();
            this.lbCreateDate = new System.Windows.Forms.Label();
            this.tblopInfo = new System.Windows.Forms.TableLayoutPanel();
            this.lbLocationValue = new System.Windows.Forms.Label();
            this.lbLocation = new System.Windows.Forms.Label();
            this.lbTypeValue = new System.Windows.Forms.Label();
            this.lbType = new System.Windows.Forms.Label();
            this.TbNodeName = new System.Windows.Forms.TextBox();
            this.PicBoxNodeType = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnApply = new System.Windows.Forms.Button();
            this.lbContainValue = new System.Windows.Forms.Label();
            this.lbContain = new System.Windows.Forms.Label();
            this.TCProperty.SuspendLayout();
            this.TPGeneral.SuspendLayout();
            this.tblopDate.SuspendLayout();
            this.tblopInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxNodeType)).BeginInit();
            this.SuspendLayout();
            // 
            // TCProperty
            // 
            this.TCProperty.Controls.Add(this.TPGeneral);
            this.TCProperty.Dock = System.Windows.Forms.DockStyle.Top;
            this.TCProperty.Location = new System.Drawing.Point(0, 0);
            this.TCProperty.Name = "TCProperty";
            this.TCProperty.SelectedIndex = 0;
            this.TCProperty.Size = new System.Drawing.Size(334, 348);
            this.TCProperty.TabIndex = 0;
            // 
            // TPGeneral
            // 
            this.TPGeneral.Controls.Add(this.lbIndexInfo);
            this.TPGeneral.Controls.Add(this.tbIndexInfo);
            this.TPGeneral.Controls.Add(this.tblopDate);
            this.TPGeneral.Controls.Add(this.tblopInfo);
            this.TPGeneral.Controls.Add(this.TbNodeName);
            this.TPGeneral.Controls.Add(this.PicBoxNodeType);
            this.TPGeneral.Location = new System.Drawing.Point(4, 22);
            this.TPGeneral.Name = "TPGeneral";
            this.TPGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.TPGeneral.Size = new System.Drawing.Size(326, 322);
            this.TPGeneral.TabIndex = 1;
            this.TPGeneral.Text = "General";
            this.TPGeneral.UseVisualStyleBackColor = true;
            // 
            // lbIndexInfo
            // 
            this.lbIndexInfo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbIndexInfo.AutoSize = true;
            this.lbIndexInfo.Location = new System.Drawing.Point(16, 213);
            this.lbIndexInfo.Margin = new System.Windows.Forms.Padding(0);
            this.lbIndexInfo.Name = "lbIndexInfo";
            this.lbIndexInfo.Size = new System.Drawing.Size(88, 13);
            this.lbIndexInfo.TabIndex = 5;
            this.lbIndexInfo.Text = "Index Information";
            this.lbIndexInfo.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tbIndexInfo
            // 
            this.tbIndexInfo.Location = new System.Drawing.Point(14, 229);
            this.tbIndexInfo.Multiline = true;
            this.tbIndexInfo.Name = "tbIndexInfo";
            this.tbIndexInfo.Size = new System.Drawing.Size(299, 87);
            this.tbIndexInfo.TabIndex = 4;
            // 
            // tblopDate
            // 
            this.tblopDate.ColumnCount = 2;
            this.tblopDate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.4698F));
            this.tblopDate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 79.5302F));
            this.tblopDate.Controls.Add(this.lbModifyDateValue, 1, 1);
            this.tblopDate.Controls.Add(this.lbModifyDate, 0, 1);
            this.tblopDate.Controls.Add(this.lbCreatedDateValue, 1, 0);
            this.tblopDate.Controls.Add(this.lbCreateDate, 0, 0);
            this.tblopDate.Location = new System.Drawing.Point(8, 152);
            this.tblopDate.Name = "tblopDate";
            this.tblopDate.RowCount = 2;
            this.tblopDate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblopDate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblopDate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblopDate.Size = new System.Drawing.Size(305, 40);
            this.tblopDate.TabIndex = 3;
            // 
            // lbModifyDateValue
            // 
            this.lbModifyDateValue.AutoSize = true;
            this.lbModifyDateValue.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbModifyDateValue.Location = new System.Drawing.Point(65, 27);
            this.lbModifyDateValue.Name = "lbModifyDateValue";
            this.lbModifyDateValue.Size = new System.Drawing.Size(237, 13);
            this.lbModifyDateValue.TabIndex = 3;
            this.lbModifyDateValue.Text = "None";
            this.lbModifyDateValue.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbModifyDate
            // 
            this.lbModifyDate.AutoSize = true;
            this.lbModifyDate.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbModifyDate.Location = new System.Drawing.Point(3, 27);
            this.lbModifyDate.Name = "lbModifyDate";
            this.lbModifyDate.Size = new System.Drawing.Size(56, 13);
            this.lbModifyDate.TabIndex = 2;
            this.lbModifyDate.Text = "Modified :";
            this.lbModifyDate.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbCreatedDateValue
            // 
            this.lbCreatedDateValue.AutoSize = true;
            this.lbCreatedDateValue.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbCreatedDateValue.Location = new System.Drawing.Point(65, 7);
            this.lbCreatedDateValue.Name = "lbCreatedDateValue";
            this.lbCreatedDateValue.Size = new System.Drawing.Size(237, 13);
            this.lbCreatedDateValue.TabIndex = 1;
            this.lbCreatedDateValue.Text = "None";
            this.lbCreatedDateValue.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbCreateDate
            // 
            this.lbCreateDate.AutoSize = true;
            this.lbCreateDate.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbCreateDate.Location = new System.Drawing.Point(3, 7);
            this.lbCreateDate.Name = "lbCreateDate";
            this.lbCreateDate.Size = new System.Drawing.Size(56, 13);
            this.lbCreateDate.TabIndex = 0;
            this.lbCreateDate.Text = "Created :";
            this.lbCreateDate.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tblopInfo
            // 
            this.tblopInfo.ColumnCount = 2;
            this.tblopInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.13423F));
            this.tblopInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 79.86577F));
            this.tblopInfo.Controls.Add(this.lbContain, 0, 2);
            this.tblopInfo.Controls.Add(this.lbContainValue, 0, 2);
            this.tblopInfo.Controls.Add(this.lbLocationValue, 1, 1);
            this.tblopInfo.Controls.Add(this.lbLocation, 0, 1);
            this.tblopInfo.Controls.Add(this.lbTypeValue, 1, 0);
            this.tblopInfo.Controls.Add(this.lbType, 0, 0);
            this.tblopInfo.Location = new System.Drawing.Point(8, 77);
            this.tblopInfo.Name = "tblopInfo";
            this.tblopInfo.RowCount = 3;
            this.tblopInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblopInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblopInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblopInfo.Size = new System.Drawing.Size(305, 60);
            this.tblopInfo.TabIndex = 2;
            // 
            // lbLocationValue
            // 
            this.lbLocationValue.AllowDrop = true;
            this.lbLocationValue.AutoEllipsis = true;
            this.lbLocationValue.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbLocationValue.Location = new System.Drawing.Point(64, 27);
            this.lbLocationValue.Name = "lbLocationValue";
            this.lbLocationValue.Size = new System.Drawing.Size(238, 13);
            this.lbLocationValue.TabIndex = 3;
            this.lbLocationValue.Text = "None";
            this.lbLocationValue.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbLocation
            // 
            this.lbLocation.AutoSize = true;
            this.lbLocation.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbLocation.Location = new System.Drawing.Point(3, 27);
            this.lbLocation.Name = "lbLocation";
            this.lbLocation.Size = new System.Drawing.Size(55, 13);
            this.lbLocation.TabIndex = 2;
            this.lbLocation.Text = "Location:";
            this.lbLocation.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbTypeValue
            // 
            this.lbTypeValue.AutoEllipsis = true;
            this.lbTypeValue.AutoSize = true;
            this.lbTypeValue.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbTypeValue.Location = new System.Drawing.Point(64, 7);
            this.lbTypeValue.Name = "lbTypeValue";
            this.lbTypeValue.Size = new System.Drawing.Size(238, 13);
            this.lbTypeValue.TabIndex = 1;
            this.lbTypeValue.Text = "None";
            this.lbTypeValue.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbType
            // 
            this.lbType.AutoSize = true;
            this.lbType.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbType.Location = new System.Drawing.Point(3, 7);
            this.lbType.Name = "lbType";
            this.lbType.Size = new System.Drawing.Size(55, 13);
            this.lbType.TabIndex = 0;
            this.lbType.Text = "Type:";
            this.lbType.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // TbNodeName
            // 
            this.TbNodeName.Location = new System.Drawing.Point(76, 20);
            this.TbNodeName.Name = "TbNodeName";
            this.TbNodeName.Size = new System.Drawing.Size(237, 20);
            this.TbNodeName.TabIndex = 3;
            // 
            // PicBoxNodeType
            // 
            this.PicBoxNodeType.ErrorImage = null;
            this.PicBoxNodeType.InitialImage = null;
            this.PicBoxNodeType.Location = new System.Drawing.Point(15, 15);
            this.PicBoxNodeType.Name = "PicBoxNodeType";
            this.PicBoxNodeType.Size = new System.Drawing.Size(30, 30);
            this.PicBoxNodeType.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBoxNodeType.TabIndex = 0;
            this.PicBoxNodeType.TabStop = false;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(84, 354);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(165, 354);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnApply
            // 
            this.btnApply.Enabled = false;
            this.btnApply.Location = new System.Drawing.Point(246, 354);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(75, 23);
            this.btnApply.TabIndex = 2;
            this.btnApply.Text = "Apply";
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // lbContainValue
            // 
            this.lbContainValue.AutoSize = true;
            this.lbContainValue.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbContainValue.Location = new System.Drawing.Point(64, 47);
            this.lbContainValue.Name = "lbContainValue";
            this.lbContainValue.Size = new System.Drawing.Size(238, 13);
            this.lbContainValue.TabIndex = 4;
            this.lbContainValue.Text = "None";
            this.lbContainValue.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbContain
            // 
            this.lbContain.AllowDrop = true;
            this.lbContain.AutoEllipsis = true;
            this.lbContain.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbContain.Location = new System.Drawing.Point(3, 47);
            this.lbContain.Name = "lbContain";
            this.lbContain.Size = new System.Drawing.Size(55, 13);
            this.lbContain.TabIndex = 5;
            this.lbContain.Text = "Contians:";
            this.lbContain.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // NodeProperty
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(334, 383);
            this.Controls.Add(this.TCProperty);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.HelpButton = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "NodeProperty";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "NodeProperty";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.NodeProperty_Paint);
            this.TCProperty.ResumeLayout(false);
            this.TPGeneral.ResumeLayout(false);
            this.TPGeneral.PerformLayout();
            this.tblopDate.ResumeLayout(false);
            this.tblopDate.PerformLayout();
            this.tblopInfo.ResumeLayout(false);
            this.tblopInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxNodeType)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl TCProperty;
        private System.Windows.Forms.TabPage TPGeneral;
        private System.Windows.Forms.TextBox TbNodeName;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TableLayoutPanel tblopInfo;
        private System.Windows.Forms.Label lbType;
        private System.Windows.Forms.Label lbLocationValue;
        private System.Windows.Forms.Label lbLocation;
        private System.Windows.Forms.Label lbTypeValue;
        private System.Windows.Forms.TableLayoutPanel tblopDate;
        private System.Windows.Forms.Label lbModifyDateValue;
        private System.Windows.Forms.Label lbModifyDate;
        private System.Windows.Forms.Label lbCreatedDateValue;
        private System.Windows.Forms.Label lbCreateDate;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.PictureBox PicBoxNodeType;
        private System.Windows.Forms.Label lbIndexInfo;
        private System.Windows.Forms.TextBox tbIndexInfo;
        private System.Windows.Forms.Label lbContain;
        private System.Windows.Forms.Label lbContainValue;
    }
}