using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using GLTc.QuickNote.CustomControl.Options;

namespace GLTc.QuickNote.Options
{
    public partial class OptionsWindow : Form
    {
        private Form mainForm;
        /// <summary>
        /// the main form window
        /// </summary>
        public Form MainForm
        {
            get { return mainForm; }
            set { mainForm = value; }
        }

        public OptionsWindow(Form MainWindow)
        {
            InitializeComponent();
            this.MainForm = MainWindow;
            this.tvSettingList.SelectedNode = this.tvSettingList.Nodes[0];
        }

        #region tvSettingList_AfterSelect
        private void tvSettingList_AfterSelect(object sender, TreeViewEventArgs e)
        {
            // store the usercontrol name in the Node.Tag attribute
            if (e.Node.Tag != null)
            {
                Assembly currentAMB = Assembly.GetExecutingAssembly();
                string ucName = "GLTc.QuickNote.CustomControl.Options." + e.Node.Tag.ToString();
                IOption settingControl = (IOption)(currentAMB.CreateInstance(ucName.ToLower(), true,
                                                BindingFlags.CreateInstance, null, new object[] { MainForm },null,null));
                this.pnlSettingControl.Controls.Clear();
                this.pnlSettingControl.Controls.Add(((UserControl)settingControl));
                settingControl.LoadSettings();
            }

        }
        #endregion 

        #region btnOK_Click
        private void btnOK_Click(object sender, EventArgs e)
        {
            // save the settings
            ((IOption)this.pnlSettingControl.Controls[0]).SaveSettings();
            this.Close();

        }
        #endregion 

        private void pnlSettingControl_Paint(object sender, PaintEventArgs e)
        {
            using (Pen p = new Pen(Brushes.Gray, 1))
            {
                e.Graphics.DrawLine(p, new Point(0, 219), new Point(284, 219));
            }
           

        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            // refresh the selected textbox , if any
            if (((GLTc.QuickNote.MainForm)this.MainForm).CurrentContextOperator.SelectedRichTextBox != null)
            {
                ((GLTc.QuickNote.MainForm)this.MainForm).CurrentContextOperator.SelectedRichTextBox.Refresh();
            }
        }

    }
}