using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using GLTc.QuickNote.Command;
using GLTc.QuickNote.Command.ViewSourceCode.RPG;
using System.Configuration;

namespace GLTc.QuickNote.CustomControl
{
    public partial class RPGTool : UserControl,ILanguageToolBar
    {
        /// <summary>
        /// store the subroutine information
        /// key subroutine Name
        /// value  SubroutineItem
        /// </summary>
        private Hashtable HashTableSubroutine = new Hashtable();

        #region SelectedTabPage
        private TabPage selectedTabPage;
        /// <summary>
        /// the selected Tabpage  which is the parent control of richtextbox
        /// </summary>
        public  TabPage SelectedTabPage
        {

            get
            {
                return selectedTabPage;
            }
            set
            {
                selectedTabPage = value;
            }
        }
        #endregion

        #region SelectedSplitContainerInTabPage
        /// <summary>
        /// the selected splitContainer in the Tappage
        /// </summary>
        public SplitContainer SelectedSplitContainerInTabPage
        {
            get
            {
                SplitContainer selectedSplitContainer = null;
                TabPage selectedPage = this.selectedTabPage;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        string tabpagePannelID = ContextOperator.GetSplitContainerName(cbi.ContextInfoID);

                        selectedSplitContainer = (SplitContainer)selectedPage.Controls[tabpagePannelID];
                    }
                }

                return selectedSplitContainer;

            }
        }
        #endregion

        #region SelectedRichTextBox
        /// <summary>
        /// Current source code container
        /// </summary>
        public  CustomRichTextBox SelectedRichTextBox
        {
            get
            {
                CustomRichTextBox rtb = null;
                if (SelectedTabPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)SelectedTabPage.Tag;
                    if (cbi != null)
                    {
                        string tabpagePannelID = ContextOperator.GetSplitContainerName(cbi.ContextInfoID);
                        string selectedRichTextBoxId = ContextOperator.ConstructRichTextBoxName(cbi.ContextInfoID);
                        Control[] ctrls = SelectedTabPage.Controls.Find(selectedRichTextBoxId, true);
                        if (ctrls.Length > 0)
                        {
                            rtb = (CustomRichTextBox)ctrls[0];
                        }
                    }
                }

                return rtb;
            }
        }
        #endregion 

        
        #region SelectedContextInfoID
        public string SelectedContextInfoID
        {
            get
            {
                string ContextID = null;
                TabPage selectedPage = this.SelectedTabPage;
                if (selectedPage != null)
                {
                    ContextBaseInfo cbi = (ContextBaseInfo)selectedPage.Tag;
                    if (cbi != null)
                    {
                        ContextID = cbi.ContextInfoID;
                    }
                }

                return ContextID;
            }


        }
        #endregion 


        public RPGTool(TabPage currentTabPage)
        {
            
            InitializeComponent();

           

            this.SelectedTabPage = currentTabPage;
            this.RPGViewer = new RPGLanguageViewer(currentTabPage);
            this.Name = this.SelectedContextInfoID;
            // Inital selectRichtextbox
            this.SelectedRichTextBox.SelectionChanged += new EventHandler(SelectedRichTextBox_SelectionChanged);
            this.SelectedRichTextBox.GotFocus += new EventHandler(SelectedRichTextBox_GotFocus);
            this.SelectedRichTextBox.SizeChanged += new EventHandler(SelectedRichTextBox_SizeChanged);
            this.SelectedRichTextBox.ClientSizeChanged += new EventHandler(SelectedRichTextBox_ClientSizeChanged);
            this.SelectedRichTextBox.VScroll += new EventHandler(SelectedRichTextBox_VScroll);
            
        }
        private RPGLanguageViewer rpgViewer;

        public RPGLanguageViewer RPGViewer
        {
            get { return rpgViewer; }
            set { rpgViewer = value; }
        }

        private string selectedSubroutine;
        /// <summary>
        /// Set the selected subroutine 
        /// </summary>
        public string SelectedSubroutine
        {
            get
            {
                return this.RPGViewer.GetCurrentSubroutine();
            }
            set
            {
                selectedSubroutine = value;
                this.tbSelectedSubroutine.Text = string.Empty;
                this.tbSelectedSubroutine.Tag = null;
                foreach (TreeNode tn in this.tvSubroutineList.Nodes)
                {
                    if (selectedSubroutine.ToLower() == tn.Text.ToLower())
                    {
                        this.tvSubroutineList.SelectedNode = tn;
                        this.tbSelectedSubroutine.Text = tn.Text;
                        this.tbSelectedSubroutine.Tag = tn.Tag;
                        break;
                    }
                }
                

            }
        }

        #region SelectRichtext Event 
        void SelectedRichTextBox_ClientSizeChanged(object sender, EventArgs e)
        {
            if (this.RPGViewer.RuleLineStyle.ToLower() != "none")
            {
                this.SelectedRichTextBox.Refresh();
                this.RPGViewer.DrawLine();
            }
        }



        void SelectedRichTextBox_SizeChanged(object sender, EventArgs e)
        {
            if (this.RPGViewer.RuleLineStyle.ToLower() != "none")
            {
                this.SelectedRichTextBox.Refresh();
                this.RPGViewer.DrawLine();
            }
        }

        void SelectedRichTextBox_GotFocus(object sender, EventArgs e)
        {
            if (this.RPGViewer.RuleLineStyle.ToLower() != "none")
            {
                this.SelectedRichTextBox.Refresh();
                this.RPGViewer.DrawLine();
            }
        }

        /// <summary>
        /// when the vscroll moved ,refresh the richtextbox and clear cross line
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void SelectedRichTextBox_VScroll(object sender, EventArgs e)
        {
            if (this.RPGViewer.RuleLineStyle.ToLower() != "none")
            {
                this.SelectedRichTextBox.Refresh();
                this.RPGViewer.DrawLine();
            }

        }

        void SelectedRichTextBox_SelectionChanged(object sender, EventArgs e)
        {
            // int currentLineNum = this.SelectedRichTextBox.GetLineFromCharIndex(this.SelectedRichTextBox.SelectionStart);
            //int currentLineEndPostion  =this.SelectedRichTextBox.GetFirstCharIndexOfCurrentLine() + this.SelectedRichTextBox.Lines[currentLineNum].Length;
            //int nextLineStartPostion = currentLineNum + 1 <= this.SelectedRichTextBox.Lines.Length ?
            //this.SelectedRichTextBox.GetFirstCharIndexFromLine(currentLineNum + 1) : 0;

            // if (currentLineNum != PreviousLineNum || currentLineEndPostion + 1 >= nextLineStartPostion)
            //{
            // this.SelectedRichTextBox.Refresh();

            //}
            this.SelectedSubroutine = this.RPGViewer.GetCurrentSubroutine();
            if (this.RPGViewer.RuleLineStyle.ToLower() != "none")
            {
                this.SelectedRichTextBox.Refresh();
                this.RPGViewer.DrawLine();
            }
            //this.SelectedRichTextBox.Update();
            //PreviousLineNum = currentLineNum;
            //PreviousLineLength = currentLineLength;
        }
        #endregion 
        
        #region ShowToolBar
        /// <summary>
        /// public methor to show the RPG Toolbar
        /// </summary>
        public void ShowToolBar()
        {
            //add the subroutine list for view code
            if (this.SelectedSplitContainerInTabPage.Panel2Collapsed == true)
            {

                this.SelectedSplitContainerInTabPage.Panel2Collapsed = false;
                ArrayList alsubroutineList = this.RPGViewer.GetSubroutineList();
                this.RPGViewer.BuildSubRoutineHashTable(alsubroutineList);
                this.RPGViewer.BindSunRoutineTreeView(this.tvSubroutineFlow);
                this.ShowSubroutineList(alsubroutineList);
                this.SelectedSubroutine = this.RPGViewer.GetCurrentSubroutine();
            }
            else
            {
                this.SelectedSplitContainerInTabPage.Panel2Collapsed = true;
            }
        }
        #endregion 

        #region ShowSubroutineList
        /// <summary>
        /// Show all the subroutine list in the treeview
        /// </summary>
        public void ShowSubroutineList(ArrayList SRList)
        {
            this.tvSubroutineList.Nodes.Clear();
            this.FillHashTableOfSubroutine();
            //band F,D,C spec
            SubroutineItem SpecItem = new SubroutineItem("F-Spec", @"(\n[^\s][\s]{5,6}[F].*)|(\n[\s]{5,7}[F].*)");
            TreeNode SpecNode = this.tvSubroutineList.Nodes.Add("F-Spec");
            SpecNode.Tag = SpecItem;

            SpecItem = new SubroutineItem("D-Spec", @"(\n[^\s][\s]{5,6}[D].*)|(\n[\s]{5,7}[D].*)");
            SpecNode = this.tvSubroutineList.Nodes.Add("D-Spec");
            SpecNode.Tag = SpecItem;

            SpecItem = new SubroutineItem("C-Spec", @"(\n[^\s][\s]{5,6}[C].*)|(\n[\s]{5,7}[C].*)");
            SpecNode = this.tvSubroutineList.Nodes.Add("C-Spec");
            SpecNode.Tag = SpecItem;

            //band subroutine 
            foreach (object obj in SRList)
            {
                SubroutineItem srItem = (SubroutineItem)obj;
                TreeNode srItemNode = new TreeNode(srItem.SubroutineName);
                srItemNode.ToolTipText = srItem.SubroutineName;
                srItemNode.Tag = srItem;
                this.tvSubroutineList.Nodes.Add(srItemNode);
 
            }

        }
        #endregion 

        #region FillHashTableOfSubroutine
        /// <summary>
        /// fill the subroutien hashtable
        /// </summary>
        private void FillHashTableOfSubroutine()
        {
            ArrayList srlist = this.RPGViewer.GetSubroutineList();
            {
                foreach (object obj in srlist)
                {
                    SubroutineItem srItem = (SubroutineItem)obj;
                    this.HashTableSubroutine.Add(srItem.SubroutineName, obj);
                }
            }


        }
        #endregion 

        #region tvSubroutineList_DoubleClick
        /// <summary>
        /// go to the selected subroutine
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tvSubroutineList_DoubleClick(object sender, EventArgs e)
        {
            SubroutineItem srItem = (SubroutineItem)this.tvSubroutineList.SelectedNode.Tag;
            if (this.tvSubroutineList.SelectedNode.Index > 2)
            {   //subroutine find policy
                
                this.RPGViewer.GotoSubtine(srItem.SubRoutineBegainFullName);
            }
            else
            {
                //spect find policy
                this.RPGViewer.GotoPotionByRegularExpression(srItem.SubRoutineBegainFullName);
                    
            }
            this.tbSelectedSubroutine.Text = this.tvSubroutineList.SelectedNode.Text;
            this.tbSelectedSubroutine.Tag = this.tvSubroutineList.SelectedNode.Tag;
            this.SelectedRichTextBox.SelectionLength = 0;
            this.SelectedRichTextBox.Focus();
            //set the selected Subroutine

        }

        #endregion 

        #region tbSelectedSubroutine_DoubleClick
        /// <summary>
        /// go to the selected subroutine
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbSelectedSubroutine_DoubleClick(object sender, EventArgs e)
        {
            SubroutineItem srItem = (SubroutineItem)this.tbSelectedSubroutine.Tag;
            if (srItem != null)
            {   //if not FDC spec
                if (srItem.SubroutineName.Substring(2).ToLower() !="spec")
                {   //subroutine find policy

                    this.RPGViewer.GotoSubtine(srItem.SubRoutineBegainFullName);
                }
                else
                {
                    //spect find policy
                    this.RPGViewer.GotoPotionByRegularExpression(srItem.SubRoutineBegainFullName);

                }
            }
            this.SelectedRichTextBox.Focus();

        }
        #endregion 

        #region btnClose_Click
        /// <summary>
        /// visible RPG Tool 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            CloseToolBar();

        }
        #endregion 

        #region CloseToolBar
        public void CloseToolBar()
        {
            this.SelectedSplitContainerInTabPage.Panel2Collapsed = true;
        }
        #endregion 

        #region DrawCross
        /// <summary>
        /// dross the close window
        /// </summary>
        /// <param name="g"></param>
        public void DrawCross(Graphics g )
        {

            Point startPostion = new Point(tableLayoutPanel2.Right - 17, 2);
            Point endPostion = new Point(tableLayoutPanel2.Right - 6, 14);
            Rectangle crossRect = new Rectangle(tableLayoutPanel2.Right - 17, 2, 15, 15);
            Rectangle crossRectRegionInClient = new Rectangle(this.PointToScreen(startPostion), new Size(15, 15));

            if (crossRectRegionInClient.Contains(Cursor.Position))
            {

                Color fill = new ToolStripProfessionalRenderer().ColorTable.ButtonCheckedGradientBegin;
                Rectangle FillRect = new Rectangle(tableLayoutPanel2.Right - 15, 4, 13, 13);
                g.FillRectangle(new SolidBrush(fill), crossRect);
                g.DrawRectangle(SystemPens.Highlight, crossRect);
                g.DrawRectangle(Pens.Black, crossRect);
               
            }
            using (Pen pen = new Pen(Color.Black, 1.6f))
            {
                g.DrawLine(pen, tableLayoutPanel2.Right - 6, 6,
                   tableLayoutPanel2.Right - 14, 14);

                g.DrawLine(pen, tableLayoutPanel1.Right-14, 6,
                    tableLayoutPanel2.Right - 6, 14);


            }

        }
        #endregion 

        #region tableLayoutPanel2_Paint
        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {
            DrawCross(e.Graphics);

        }
        #endregion 

        #region tableLayoutPanel2_MouseMove
        private void tableLayoutPanel2_MouseMove(object sender, MouseEventArgs e)
        {
            Rectangle crossRect = new Rectangle(tableLayoutPanel2.Right - 18, 1, 20, 20);
            tableLayoutPanel2.Invalidate(crossRect);
        }
        #endregion 

        #region tableLayoutPanel2_MouseClick
        private void tableLayoutPanel2_MouseClick(object sender, MouseEventArgs e)
        {
            Point startPostion = new Point(tableLayoutPanel2.Right - 14, 6);
            Rectangle crossRectRegionInClient = new Rectangle(this.PointToScreen(startPostion), new Size(50, 50));
            if (crossRectRegionInClient.Contains(Cursor.Position))
            {
                CloseToolBar();
            }
        }
        #endregion 

        #region tableLayoutPanel2_MouseLeave
        private void tableLayoutPanel2_MouseLeave(object sender, EventArgs e)
        {
            Rectangle crossRect = new Rectangle(tableLayoutPanel2.Right - 18, 1, 20, 20);
            tableLayoutPanel2.Invalidate(crossRect);

        }
        #endregion 

        #region tvSubroutineFlow_NodeMouseClick
        /// <summary>
        /// node click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tvSubroutineFlow_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                //select current Node
                this.tvSubroutineFlow.SelectedNode = e.Node;

                if (this.tvSubroutineFlow.Nodes[0] != e.Node )
                {
                    this.CMSSRFlow.Show(Cursor.Position);
                }

            }

        }
        #endregion 

        #region GotoDefinition
        /// <summary>
        /// go to SR position
        /// </summary>
        private void GotoDefinition()
        {
            string srName = this.tvSubroutineFlow.SelectedNode.Text;
            object SRInfor =  this.HashTableSubroutine[srName];
            if (SRInfor != null)
            {
                SubroutineItem srItem = (SubroutineItem)SRInfor;
                this.RPGViewer.GotoSubtine(srItem.SubRoutineBegainFullName);
                this.tbSelectedSubroutine.Text = this.tvSubroutineList.SelectedNode.Text;
                this.tbSelectedSubroutine.Tag = this.tvSubroutineList.SelectedNode.Tag;
                this.SelectedRichTextBox.SelectionLength = 0;
            }
            this.SelectedRichTextBox.Focus();
        }
        #endregion 

        #region ShowSRBody
        private void ShowSRBody()
        {
            string srName = this.tvSubroutineFlow.SelectedNode.Text;
            object SRInfor = this.HashTableSubroutine[srName];
            if (SRInfor != null)
            {
                SubroutineItem srItem = (SubroutineItem)SRInfor;
                SubroutineBodyViewer SRBodyViewer = new SubroutineBodyViewer(this.RPGViewer);
                SRBodyViewer.SetCurrentSubroutineBody(srItem.SubroutineBody);
                SRBodyViewer.Show();
            }

        }
        #endregion 

        private void tvSubroutineFlow_NodeMouseClick_1(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.tvSubroutineFlow.SelectedNode = e.Node;
            }
        }

        private void TSMIGOTO_Click(object sender, EventArgs e)
        {
            this.GotoDefinition();
        }

        private void TSMIShowSRBody_Click(object sender, EventArgs e)
        {
            ShowSRBody();
        }

        private void tvSubroutineList_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.tvSubroutineList.SelectedNode = e.Node;
            }
        }



    }
}
