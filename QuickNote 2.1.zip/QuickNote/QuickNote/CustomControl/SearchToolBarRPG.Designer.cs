namespace GLTc.QuickNote.CustomControl
{
    partial class SearchToolBarRPG
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TSMIFindNext = new System.Windows.Forms.ToolStripMenuItem();
            this.CMSSearch = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TSMIFindPrevious = new System.Windows.Forms.ToolStripMenuItem();
            this.Tbcontainer = new System.Windows.Forms.TableLayoutPanel();
            this.TBFormat = new System.Windows.Forms.TableLayoutPanel();
            this.picbPlus = new System.Windows.Forms.PictureBox();
            this.picbSubtract = new System.Windows.Forms.PictureBox();
            this.lbFormatString = new System.Windows.Forms.Label();
            this.CMSSearch.SuspendLayout();
            this.Tbcontainer.SuspendLayout();
            this.TBFormat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbPlus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbSubtract)).BeginInit();
            this.SuspendLayout();
            // 
            // TSMIFindNext
            // 
            this.TSMIFindNext.Name = "TSMIFindNext";
            this.TSMIFindNext.Size = new System.Drawing.Size(164, 22);
            this.TSMIFindNext.Text = "Find Next         Shift+F4";
            // 
            // CMSSearch
            // 
            this.CMSSearch.AutoSize = false;
            this.CMSSearch.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMIFindNext,
            this.toolStripSeparator1,
            this.TSMIFindPrevious});
            this.CMSSearch.Name = "contextMenuStrip1";
            this.CMSSearch.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.CMSSearch.ShowImageMargin = false;
            this.CMSSearch.Size = new System.Drawing.Size(140, 58);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(136, 6);
            // 
            // TSMIFindPrevious
            // 
            this.TSMIFindPrevious.Name = "TSMIFindPrevious";
            this.TSMIFindPrevious.Size = new System.Drawing.Size(164, 22);
            this.TSMIFindPrevious.Text = "Find Previous   Shift+F5";
            // 
            // Tbcontainer
            // 
            this.Tbcontainer.ColumnCount = 1;
            this.Tbcontainer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.Tbcontainer.Controls.Add(this.TBFormat, 0, 1);
            this.Tbcontainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tbcontainer.Location = new System.Drawing.Point(1, 1);
            this.Tbcontainer.Margin = new System.Windows.Forms.Padding(0);
            this.Tbcontainer.Name = "Tbcontainer";
            this.Tbcontainer.RowCount = 2;
            this.Tbcontainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.Tbcontainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.Tbcontainer.Size = new System.Drawing.Size(317, 41);
            this.Tbcontainer.TabIndex = 1;
            // 
            // TBFormat
            // 
            this.TBFormat.ColumnCount = 4;
            this.TBFormat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.TBFormat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.TBFormat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TBFormat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.TBFormat.Controls.Add(this.picbPlus, 3, 0);
            this.TBFormat.Controls.Add(this.picbSubtract, 0, 0);
            this.TBFormat.Controls.Add(this.lbFormatString, 2, 0);
            this.TBFormat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TBFormat.Location = new System.Drawing.Point(0, 24);
            this.TBFormat.Margin = new System.Windows.Forms.Padding(0);
            this.TBFormat.Name = "TBFormat";
            this.TBFormat.RowCount = 1;
            this.TBFormat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TBFormat.Size = new System.Drawing.Size(317, 17);
            this.TBFormat.TabIndex = 11;
            // 
            // picbPlus
            // 
            this.picbPlus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picbPlus.Image = global::GLTc.QuickNote.Properties.Resources.Plus;
            this.picbPlus.Location = new System.Drawing.Point(301, 1);
            this.picbPlus.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.picbPlus.Name = "picbPlus";
            this.picbPlus.Size = new System.Drawing.Size(16, 16);
            this.picbPlus.TabIndex = 2;
            this.picbPlus.TabStop = false;
            this.picbPlus.MouseLeave += new System.EventHandler(this.picbSubtract_MouseLeave);
            this.picbPlus.Click += new System.EventHandler(this.picbPlus_Click);
            this.picbPlus.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picbSubtract_MouseDown);
            this.picbPlus.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picbSubtract_MouseUp);
            // 
            // picbSubtract
            // 
            this.picbSubtract.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picbSubtract.Image = global::GLTc.QuickNote.Properties.Resources.Subtract;
            this.picbSubtract.Location = new System.Drawing.Point(0, 1);
            this.picbSubtract.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.picbSubtract.Name = "picbSubtract";
            this.picbSubtract.Size = new System.Drawing.Size(16, 16);
            this.picbSubtract.TabIndex = 0;
            this.picbSubtract.TabStop = false;
            this.picbSubtract.MouseLeave += new System.EventHandler(this.picbSubtract_MouseLeave);
            this.picbSubtract.Click += new System.EventHandler(this.picbSubtract_Click);
            this.picbSubtract.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picbSubtract_MouseDown);
            this.picbSubtract.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picbSubtract_MouseUp);
            // 
            // lbFormatString
            // 
            this.lbFormatString.AutoSize = true;
            this.lbFormatString.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFormatString.Location = new System.Drawing.Point(23, 0);
            this.lbFormatString.Name = "lbFormatString";
            this.lbFormatString.Size = new System.Drawing.Size(0, 17);
            this.lbFormatString.TabIndex = 1;
            this.lbFormatString.UseCompatibleTextRendering = true;
            this.lbFormatString.UseMnemonic = false;
            // 
            // SearchToolBarRPG
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Tbcontainer);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "SearchToolBarRPG";
            this.Padding = new System.Windows.Forms.Padding(1, 1, 0, 1);
            this.Size = new System.Drawing.Size(318, 43);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.SearchToolBar_Paint);
            this.CMSSearch.ResumeLayout(false);
            this.Tbcontainer.ResumeLayout(false);
            this.TBFormat.ResumeLayout(false);
            this.TBFormat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbPlus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbSubtract)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem TSMIFindNext;
        private System.Windows.Forms.ContextMenuStrip CMSSearch;
        private System.Windows.Forms.ToolStripMenuItem TSMIFindPrevious;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.TableLayoutPanel Tbcontainer;
        private System.Windows.Forms.TableLayoutPanel TBFormat;
        private System.Windows.Forms.PictureBox picbSubtract;
        private System.Windows.Forms.PictureBox picbPlus;
        private System.Windows.Forms.Label lbFormatString;
    }
}
